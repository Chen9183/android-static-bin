#define _POSIX_C_SOURCE 200809L
#define _DEFAULT_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>

#define W 72
#define H 24
#define MAXF 8
#define EXP_LEN 128
#define HIST_SIZE 32
#define IMG_SCALE  256         /* 图片放大倍数 */
#define LINE_WIDTH 6          /* 线条粗细（像素半径） */
#define IMG_W (W * IMG_SCALE)
#define IMG_H (W * IMG_SCALE)
#define VER "calc v2.10.6 (use system mytools magick, pipe)"

static const double PI = 3.141592653589793, E = 2.718281828459045;

char scr[H][W + 1];
int scr_col[H][W];
float sc = 3.0f;
int cxo = 0, cyo = 0;
int nfun = 0;
char exprs[MAXF][EXP_LEN];
int use_color = 1;
int parse_error = 0;
int polar_mode = 0;
float aspect = 0.5f;

double ga = 0.0, gb = 0.0, gc = 0.0;

char history[HIST_SIZE][EXP_LEN];
int hist_count = 0;

static char fun_ch(int i) { char t[] = "#*O@%&$=+"; return t[i % 8]; }
static int  fun_col(int i) { int p[] = {196,46,226,214,118,33,208,51}; return p[i % 8]; }

/* ---------- 终端输入（方向键历史） ---------- */
static int readline(char *buf, int bl) {
    struct termios old, raw;
    tcgetattr(0, &old);
    raw = old;
    raw.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(0, TCSANOW, &raw);
    int len = 0, idx = -1;
    char backup[EXP_LEN] = {0};
    while (1) {
        char c;
        if (read(0, &c, 1) != 1) continue;
        if (c == 27) {
            if (read(0, &c, 1) == 1 && c == '[') {
                if (read(0, &c, 1) == 1) {
                    if (c == 'A') {
                        if (hist_count == 0) continue;
                        if (idx == -1) strcpy(backup, buf);
                        idx = (idx == -1) ? hist_count - 1 : (idx == 0 ? 0 : idx - 1);
                        strcpy(buf, history[idx % HIST_SIZE]);
                        len = strlen(buf);
                        printf("\r\033[K > %s", buf); fflush(stdout);
                    } else if (c == 'B') {
                        if (idx == -1) continue;
                        idx++;
                        if (idx >= hist_count) { idx = -1; strcpy(buf, backup); }
                        else strcpy(buf, history[idx % HIST_SIZE]);
                        len = strlen(buf);
                        printf("\r\033[K > %s", buf); fflush(stdout);
                    }
                }
            }
            continue;
        }
        if (c == '\n' || c == '\r') { buf[len] = 0; putchar('\n'); break; }
        if (c == 127 || c == '\b') { if (len > 0) { buf[--len] = 0; printf("\b \b"); fflush(stdout); } }
        else if (c >= 32 && c < 127 && len < bl - 1) { buf[len++] = c; putchar(c); fflush(stdout); }
    }
    tcsetattr(0, TCSANOW, &old);
    return len;
}
static void hist_add(const char *s) { if (*s) { strcpy(history[hist_count % HIST_SIZE], s); hist_count++; } }

/* ---------- ANSI ---------- */
static void cls(void) { printf("\033[2J\033[H"); }
static void fg(int n) { if (use_color) printf("\033[38;5;%dm", n); }
static void rst(void) { if (use_color) printf("\033[0m"); }

/* ---------- 解析器（x, a, b, c） ---------- */
static double expr(const char **p, double x);

static double primary(const char **p, double x) {
    while (isspace(**p)) (*p)++;
    if (**p == '(') { (*p)++; double v = expr(p, x); if (**p == ')') (*p)++; return v; }
    if (**p == 'x') { (*p)++; return x; }
    if (**p == 'a' && !isalnum((*p)[1])) { (*p)++; return ga; }
    if (**p == 'b' && !isalnum((*p)[1])) { (*p)++; return gb; }
    if (**p == 'c' && !isalnum((*p)[1])) { (*p)++; return gc; }
    if (**p == 'e' && !isalnum((*p)[1])) { (*p)++; return E; }
    if (**p == 'p' && (*p)[1] == 'i') { (*p) += 2; return PI; }
    if (isalpha(**p)) {
        char f[5] = {0}; int i = 0; const char *t = *p;
        while (isalpha(*t) && i < 4) f[i++] = *t++;
        if (!strcmp(f,"sin")||!strcmp(f,"cos")||!strcmp(f,"tan")||
            !strcmp(f,"sqrt")||!strcmp(f,"abs")||!strcmp(f,"ln")) {
            *p = t;
            if (**p == '(') (*p)++;
            double v = expr(p, x);
            if (**p == ')') (*p)++;
            if (!strcmp(f,"sin")) return sin(v);
            if (!strcmp(f,"cos")) return cos(v);
            if (!strcmp(f,"tan")) return tan(v);
            if (!strcmp(f,"sqrt")) return sqrt(v);
            if (!strcmp(f,"abs")) return fabs(v);
            return log(v);
        }
    }
    double v = 0;
    while (isdigit(**p)) v = v * 10 + *(*p)++ - '0';
    if (**p == '.') {
        (*p)++; double f0 = 0.1;
        while (isdigit(**p)) { v += f0 * (*(*p)++ - '0'); f0 *= 0.1; }
    }
    return v;
}
static double power(const char **p, double x) {
    double v = primary(p, x);
    if (**p == '^') { (*p)++; return pow(v, primary(p, x)); }
    return v;
}
static double unary(const char **p, double x) {
    while (isspace(**p)) (*p)++;
    if (**p == '-') { (*p)++; return -unary(p, x); }
    if (**p == '+') { (*p)++; return unary(p, x); }
    return power(p, x);
}
static double term(const char **p, double x) {
    double v = unary(p, x);
    while (**p == '*' || **p == '/') {
        int op = *(*p)++;
        v = (op == '*') ? v * unary(p, x) : v / unary(p, x);
    }
    return v;
}
static double expr(const char **p, double x) {
    double v = term(p, x);
    while (*p && **p && **p != ')') {
        if (**p == '+') { (*p)++; v += term(p, x); }
        else if (**p == '-') { (*p)++; v -= term(p, x); }
        else break;
    }
    return v;
}
static double eval(const char *s, double x) {
    parse_error = 0;
    const char *t = s;
    double r = expr(&t, x);
    if (*t) parse_error = 1;
    return r;
}

/* ---------- 终端绘图 ---------- */
void plot(void) {
    if (sc < 0.1f) sc = 0.1f;
    int cx = W / 2 + cxo, cy = H / 2 + cyo;
    for (int y = 0; y < H; y++) {
        for (int x = 0; x < W; x++) { scr[y][x] = ' '; scr_col[y][x] = -1; }
        scr[y][W] = 0;
    }
    for (int x = 0; x < W; x++) { scr[cy][x] = (x % 5 == 0) ? '+' : '-'; scr_col[cy][x] = -1; }
    for (int y = 0; y < H; y++) { scr[y][cx] = (y % 2 == 0) ? '|' : ' '; scr_col[y][cx] = -1; }
    scr[cy][cx] = '+';

    for (int f = 0; f < nfun; f++) {
        if (polar_mode) {
            const int N = 2000;
            for (int i = 0; i <= N; i++) {
                double theta = 2.0 * PI * i / N;
                double r = eval(exprs[f], theta);
                if (parse_error || !isfinite(r)) continue;
                int px = cx + (int)(r * cos(theta) * sc);
                int py = cy - (int)(r * sin(theta) * sc * aspect);
                if (px >= 0 && px < W && py > 0 && py < H - 1) {
                    scr[py][px] = fun_ch(f); scr_col[py][px] = f;
                }
            }
        } else {
            for (int px = 0; px < W; px++) {
                double yv = eval(exprs[f], (px - cx) / sc);
                int py = cy - (int)(yv * sc * aspect);
                if (!parse_error && isfinite(yv) && py > 0 && py < H - 1) {
                    scr[py][px] = fun_ch(f); scr_col[py][px] = f;
                }
            }
        }
    }
}
void flush(void) {
    for (int y = 0; y < H; y++) {
        for (int x = 0; x < W; x++) {
            char c = scr[y][x];
            if (c == ' ') putchar(' ');
            else if (scr_col[y][x] >= 0) { fg(fun_col(scr_col[y][x])); putchar(c); rst(); }
            else { fg(244); putchar(c); rst(); }
        }
        putchar('\n');
    }
    if (parse_error) printf("\033[31m! 存在语法错误的表达式\033[0m\n");
}

void do_move(const char *a) {
    int s = 1, d = 0; const char *t = a;
    while (isspace(*t)) t++;
    if (*t == 'x' || *t == 'y') t++;
    if (*t == '+') t++;
    else if (*t == '-') { s = -1; t++; }
    while (isdigit(*t)) d = d * 10 + *t++ - '0';
    if (*t == '.') { puts(" /mv 只支持整数"); return; }
    if (strchr(a, 'y') || strchr(a, 'Y')) cyo += s * d; else cxo += s * d;
}

int is_easter_egg(const char *s) {
    char clean[128]; int j = 0;
    for (int i = 0; s[i] && j < 127; i++) if (!isspace(s[i])) clean[j++] = tolower((unsigned char)s[i]);
    clean[j] = 0;
    return !strcmp(clean, "e^(i*pi)");
}

/* ---------- 保存文本 ---------- */
void save_text(const char *fn) {
    FILE *fp = fopen(fn, "w");
    if (!fp) { perror("保存失败"); return; }
    for (int y = 0; y < H; y++) { fputs(scr[y], fp); fputc('\n', fp); }
    fclose(fp);
    printf("文本已保存到 %s\n", fn);
}

/* ---------- 高分辨率图片渲染 ---------- */
static void draw_thick_point(unsigned char *img, int cx, int cy, int r,
                             unsigned char R, unsigned char G, unsigned char B) {
    for (int dy = -r; dy <= r; dy++) {
        int y = cy + dy;
        if (y < 0 || y >= IMG_H) continue;
        for (int dx = -r; dx <= r; dx++) {
            int x = cx + dx;
            if (x < 0 || x >= IMG_W) continue;
            int idx = (y * IMG_W + x) * 3;
            img[idx]   = R;
            img[idx+1] = G;
            img[idx+2] = B;
        }
    }
}

static void render_hires(unsigned char *img) {
    memset(img, 0, IMG_W * IMG_H * 3);
    int cx = IMG_W / 2 + cxo * IMG_SCALE;
    int cy = IMG_H / 2 + cyo * IMG_SCALE;
    double pix_per_unit = sc * IMG_SCALE;
    unsigned char gray = 120;

    /* 加粗 X 轴 */
    int y0 = (cy - LINE_WIDTH) > 0 ? (cy - LINE_WIDTH) : 0;
    int y1 = (cy + LINE_WIDTH) < IMG_H ? (cy + LINE_WIDTH) : IMG_H - 1;
    for (int y = y0; y <= y1; y++) {
        for (int x = 0; x < IMG_W; x++) {
            int idx = (y * IMG_W + x) * 3;
            if (x % (IMG_SCALE * 5) == 0) {
                img[idx] = gray; img[idx+1] = gray; img[idx+2] = gray;
            } else {
                img[idx] = gray; img[idx+1] = gray; img[idx+2] = gray;
            }
        }
    }

    /* 加粗 Y 轴 */
    int x0 = (cx - LINE_WIDTH) > 0 ? (cx - LINE_WIDTH) : 0;
    int x1 = (cx + LINE_WIDTH) < IMG_W ? (cx + LINE_WIDTH) : IMG_W - 1;
    for (int y = 0; y < IMG_H; y++) {
        for (int x = x0; x <= x1; x++) {
            int idx = (y * IMG_W + x) * 3;
            if (y % (IMG_SCALE * 2) == 0) {
                img[idx] = gray; img[idx+1] = gray; img[idx+2] = gray;
            } else {
                img[idx] = gray; img[idx+1] = gray; img[idx+2] = gray;
            }
        }
    }
    draw_thick_point(img, cx, cy, LINE_WIDTH, gray, gray, gray);

    /* 曲线 */
    for (int f = 0; f < nfun; f++) {
        int col = f % 8;
        int pal[8][3] = {{196,0,0},{0,196,0},{226,0,226},{214,214,0},
                         {118,118,118},{33,33,255},{208,100,0},{51,255,255}};
        unsigned char r = pal[col][0], g = pal[col][1], b = pal[col][2];

        if (polar_mode) {
            const int N = 2000 * IMG_SCALE;
            for (int i = 0; i <= N; i++) {
                double theta = 2.0 * PI * i / N;
                double rv = eval(exprs[f], theta);
                if (parse_error || !isfinite(rv)) continue;
                int px = cx + (int)(rv * cos(theta) * pix_per_unit);
                int py = cy - (int)(rv * sin(theta) * pix_per_unit);
                draw_thick_point(img, px, py, LINE_WIDTH, r, g, b);
            }
        } else {
            for (int px = 0; px < IMG_W; px++) {
                double x_val = (px - cx) / pix_per_unit;
                double yv = eval(exprs[f], x_val);
                if (parse_error || !isfinite(yv)) continue;
                int py = cy - (int)(yv * pix_per_unit);
                draw_thick_point(img, px, py, LINE_WIDTH, r, g, b);
            }
        }
    }
}

/* ---------- 通过管道将 PPM 数据传给转换工具 ---------- */
static int save_via_pipe(const char *cmd, unsigned char *img) {
    void (*old_handler)(int) = signal(SIGPIPE, SIG_IGN);   // 忽略 SIGPIPE
    FILE *pipe = popen(cmd, "w");
    if (!pipe) {
        signal(SIGPIPE, old_handler);
        return -1;
    }
    fprintf(pipe, "P6\n%d %d\n255\n", IMG_W, IMG_H);
    for (int y = 0; y < IMG_H; y++)
        fwrite(img + y * IMG_W * 3, 1, IMG_W * 3, pipe);
    int status = pclose(pipe);
    signal(SIGPIPE, old_handler);   // 恢复原处理
    return status;
}
/* ---------- 保存图片（优先 mytools magick，管道传输） ---------- */
void save_image(const char *fn) {
    unsigned char *img = malloc(IMG_W * IMG_H * 3);
    if (!img) { perror("内存不足"); return; }
    render_hires(img);

    char cmd[1024];
    int ret = -1;

    /* 1) 尝试 mytools magick (系统 PATH) */
    snprintf(cmd, sizeof(cmd), "mytools magick ppm:- \"%s\"", fn);
    ret = save_via_pipe(cmd, img);

    /* 2) 尝试 magick (ImageMagick 新版本) */
    if (ret != 0) {
        snprintf(cmd, sizeof(cmd), "magick ppm:- \"%s\"", fn);
        ret = save_via_pipe(cmd, img);
    }

    /* 3) 尝试 convert (ImageMagick 旧版本) */
    if (ret != 0) {
        snprintf(cmd, sizeof(cmd), "convert ppm:- \"%s\"", fn);
        ret = save_via_pipe(cmd, img);
    }

    /* 4) 尝试 vips (需要临时文件) */
    if (ret != 0) {
        char tmp[256];
        snprintf(tmp, sizeof(tmp), "./.calc_temp_%d.ppm", getpid());
        FILE *fp = fopen(tmp, "wb");
        if (fp) {
            fprintf(fp, "P6\n%d %d\n255\n", IMG_W, IMG_H);
            for (int y = 0; y < IMG_H; y++)
                fwrite(img + y * IMG_W * 3, 1, IMG_W * 3, fp);
            fclose(fp);
            snprintf(cmd, sizeof(cmd), "vips copy \"%s\" \"%s\" 2>/dev/null", tmp, fn);
            ret = system(cmd);
            remove(tmp);
        }
    }

    free(img);

    if (ret == 0) {
        printf("高清图片已保存到 %s\n", fn);
        return;
    }

    /* 全部失败，询问是否保存原始 PPM */
    printf("所有图片转换工具均不可用。\n是否保存原始 PPM 文件（%d×%d）？(回车确认 / q 取消): ", IMG_W, IMG_H);
    fflush(stdout);
    char answer[8];
    if (fgets(answer, sizeof(answer), stdin)) {
        answer[strcspn(answer, "\n")] = 0;
        if (answer[0] == 'q' || answer[0] == 'Q') {
            printf("已取消。\n");
            return;
        }
    }

    char ppm_name[256];
    const char *dot = strrchr(fn, '.');
    if (dot && dot != fn)
        snprintf(ppm_name, sizeof(ppm_name), "%.*s.ppm", (int)(dot - fn), fn);
    else
        snprintf(ppm_name, sizeof(ppm_name), "%s.ppm", fn);

    /* 重新渲染一次以便写入文件 */
    img = malloc(IMG_W * IMG_H * 3);
    if (!img) { return; }
    render_hires(img);
    FILE *fp = fopen(ppm_name, "wb");
    if (fp) {
        fprintf(fp, "P6\n%d %d\n255\n", IMG_W, IMG_H);
        for (int y = 0; y < IMG_H; y++)
            fwrite(img + y * IMG_W * 3, 1, IMG_W * 3, fp);
        fclose(fp);
        printf("已保存原始 PPM 文件为 %s\n", ppm_name);
    } else {
        perror("无法保存 PPM");
    }
    free(img);
}

/* ---------- 帮助 ---------- */
void print_help(void) {
    cls();
    puts("\033[1m══════════════════════════════════════════════\033[0m");
    printf(" \033[32m%s\033[0m\n", VER);
    puts(" \033[1mAuthor:\033[0m Yuanbao AI (元宝) && Deepseek AI && @Chen9183");
    puts("\033[1m──────────── 表达式 ────────────\033[0m");
    puts(" 变量: x, a, b, c    常数: e, pi");
    puts(" 函数: sin cos tan ln sqrt abs");
    puts(" 运算: ^(幂) * / + - (一元负号)");
    puts(" 可使用 /a 值  /b 值  /c 值 给变量赋值 (初始为0)");
    puts("\033[1m──────────── 命令 ────────────\033[0m");
    puts(" /add 表达式   添加曲线");
    puts(" /kill n       删除第n条");
    puts(" /+  /-        放大/缩小");
    puts(" /zoom N       设缩放值");
    puts(" /mv x+5       右移5格 (仅整数)");
    puts(" /mv y-3       上移3格");
    puts(" /aspect R     设宽高比 (0.1~2.0)");
    puts(" /a 1.5        设置 a = 1.5");
    puts(" /b -2         设置 b = -2");
    puts(" /c 0.001      设置 c = 0.001");
    puts(" /clear        清空所有 (不重置变量)");
    puts(" /color off/on 开关颜色");
    puts(" /polar        极坐标模式");
    puts(" /save 0 路径  保存为高清图片 (优先 mytools magick，管道传输)");
    puts(" /save 1 路径  保存为文本");
    puts(" ↑↓            历史命令浏览");
    puts(" /help         本帮助");
    puts(" /q  /exit     退出");
    puts("\033[1m══════════════════════════════════════════════\033[0m");
    printf(" 按回车继续...");
    fflush(stdout);
    char c; while (read(0, &c, 1) != 1 || c != '\n') {}
}

/* ---------- 主循环 ---------- */
int main(void) {
    char b[256];
    while (1) {
        cls(); plot(); flush();
        printf("\n zoom=%.2f pan=(%d,%d) | %d/%d 条 | %s",
               sc, cxo, cyo, nfun, MAXF, use_color ? "[color ON]" : "[color OFF]");
        if (polar_mode) printf(" \033[35m[极坐标]\033[0m");
        printf(" | aspect=%.2f", aspect);
        printf(" | a=%.2f b=%.2f c=%.2f", ga, gb, gc);
        putchar('\n');
        for (int i = 0; i < nfun; i++) {
            fg(fun_col(i)); printf(" [%d]%c %s", i, fun_ch(i), exprs[i]); rst();
        }
        puts("");
        puts(" /add /+ /- /mv /kill /polar /save /help /q");
        printf(" > "); fflush(stdout);

        int len = readline(b, sizeof(b));
        if (len == 0 && b[0] == 0) continue;

        if (is_easter_egg(b)) {
            printf("\033[35m 复数运算暂不支持，送你一颗数学之心 ❤️\033[0m\n");
            printf(" （心形线 r = 1 - cosθ）\n"); fflush(stdout);
            sleep(2);
            nfun = 0; polar_mode = 1;
            snprintf(exprs[nfun++], EXP_LEN, "1-cos(x)");
            sc = 8.0f; cxo = cyo = 0;
            hist_add(b);
            continue;
        }

        if (b[0] != '/' || strncmp(b, "/add ", 5) == 0) hist_add(b);

        if (b[0] == '/') {
            if (!strcmp(b, "/q") || !strcmp(b, "/exit")) { printf("\n bye.\n"); break; }
            if (!strcmp(b, "/help")) { print_help(); continue; }
            if (!strcmp(b, "/+")) { sc = sc / 2.0f; if (sc < 0.1f) sc = 0.1f; }
            if (!strcmp(b, "/-")) sc = sc * 2.0f;
            if (!strncmp(b, "/zoom ", 6)) { sc = (float)fabs(atof(b + 6)); if (sc < 0.1f) sc = 0.1f; }
            if (!strncmp(b, "/mv ", 4)) do_move(b + 4);
            if (!strcmp(b, "/clear")) {
                nfun = 0; cxo = cyo = 0; sc = 3.0f; polar_mode = 0; aspect = 0.5f;
            }
            if (!strcmp(b, "/color off")) use_color = 0;
            if (!strcmp(b, "/color on"))  use_color = 1;
            if (!strcmp(b, "/polar")) { polar_mode = !polar_mode; }
            if (!strncmp(b, "/aspect ", 8)) {
                float v = (float)atof(b + 8);
                if (v >= 0.1f && v <= 2.0f) aspect = v;
                else { puts("宽高比 0.1~2.0"); sleep(1); }
            }
            if (!strncmp(b, "/a ", 3)) { ga = atof(b + 3); continue; }
            if (!strncmp(b, "/b ", 3)) { gb = atof(b + 3); continue; }
            if (!strncmp(b, "/c ", 3)) { gc = atof(b + 3); continue; }
            if (!strncmp(b, "/save ", 6)) {
                char mode[4], fname[256];
                if (sscanf(b + 6, "%3s %255s", mode, fname) == 2) {
                    if (strcmp(mode, "0") == 0) save_image(fname);
                    else if (strcmp(mode, "1") == 0) save_text(fname);
                    else puts("用法: /save 0|1 路径");
                } else puts("用法: /save 0|1 路径");
                sleep(1);
            }
            if (!strncmp(b, "/kill ", 6)) {
              int k = atoi(b + 6);
              if (k >= 0 && k < nfun) {
               int remaining = nfun - k - 1;          // 计算要移动的元素个数
               memmove(exprs + k, exprs + k + 1, remaining * EXP_LEN);
               nfun--;                                 // 最后再减总数
              }
            }
            if (!strncmp(b, "/add ", 5) && nfun < MAXF) {
                const char *e = b + 5;
                if (strlen(e) < EXP_LEN - 1) snprintf(exprs[nfun++], EXP_LEN, "%s", e);
                else puts("太长");
            }
        } else if (b[0] && nfun < MAXF) {
            if (strlen(b) < EXP_LEN - 1) snprintf(exprs[nfun++], EXP_LEN, "%s", b);
            else puts("太长");
        }
    }
    return 0;
}