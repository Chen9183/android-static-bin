#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/utsname.h>
#include <errno.h>
#include <strings.h>

/* ── ANSI colors ── */
#define C_RESET  "\033[0m"
#define C_BOLD   "\033[1m"
#define C_RED    "\033[31m"
#define C_GREEN  "\033[32m"
#define C_YELLOW "\033[33m"
#define C_CYAN   "\033[36m"

/* ── globals ── */
static int  g_is_android = 0;
static int  g_is_root    = 0;
static char g_arch[64];
static char g_kernel[128];
static char g_android_ver[128];
static char g_device[128];
static char g_distro[256];

static char g_ca_path[256];
static char g_dns_path[256];
static char g_nss_path[256];

/* ── helpers ── */
static void stripnl(char *s) {
    size_t len = strlen(s);
    while (len > 0 && (s[len-1]=='\n'||s[len-1]=='\r')) s[--len] = 0;
}

static int file_exists(const char *path) { return access(path, F_OK) == 0; }

static int read_file_str(const char *path, char *buf, int max) {
    int fd = open(path, O_RDONLY);
    if (fd < 0) return -1;
    int n = (int)read(fd, buf, max-1);
    close(fd);
    if (n <= 0) return -1;
    buf[n] = 0;
    return n;
}

static int write_file_str(const char *path, const char *data) {
    int fd = open(path, O_WRONLY|O_CREAT|O_TRUNC, 0644);
    if (fd < 0) return -1;
    int len = (int)strlen(data);
    int n = (int)write(fd, data, len);
    close(fd);
    return (n == len) ? 0 : -1;
}

static int append_file(const char *path, const char *data, int len) {
    int fd = open(path, O_WRONLY|O_CREAT|O_APPEND, 0644);
    if (fd < 0) return -1;
    int n = (int)write(fd, data, len);
    close(fd);
    return (n == len) ? 0 : -1;
}

static char* read_all(int fd, int *out_len) {
    char *buf = NULL;
    int   cap = 0, len = 0;
    char  tmp[8192];
    int   n;
    while ((n = (int)read(fd, tmp, sizeof(tmp))) > 0) {
        if (len + n > cap) {
            cap = cap ? cap*2 : 32768;
            buf = realloc(buf, cap);
            if (!buf) return NULL;
        }
        memcpy(buf+len, tmp, n);
        len += n;
    }
    if (out_len) *out_len = len;
    if (len == 0) { free(buf); return NULL; }
    buf = realloc(buf, len+1);
    if (buf) buf[len] = 0;
    return buf;
}

/* ── detection ── */
static int detect_android(void) {
    if (file_exists("/system/build.prop"))  return 1;
    if (file_exists("/system/bin/getprop")) return 1;

    struct stat st;
    if (stat("/system", &st) == 0 && S_ISDIR(st.st_mode)) {
        char cmd[256] = {0};
        if (read_file_str("/proc/1/cmdline", cmd, sizeof(cmd)) > 0) {
            for (char *p=cmd; p<cmd+254; p+=strlen(p)+1) {
                if (!strcmp(p,"init")||!strcmp(p,"ueventd")||!strcmp(p,"watchdogd"))
                    return 1;
            }
        }
    }

    char ver[4096] = {0};
    if (read_file_str("/proc/version", ver, sizeof(ver)) > 0) {
        if (strstr(ver, "Android")) return 1;
    }

    if (!file_exists("/etc/os-release")) {
        struct utsname u;
        if (uname(&u) == 0 && !strcmp(u.sysname, "Linux")) return 1;
    }
    return 0;
}

static void gather_info(void) {
    struct utsname u;
    if (uname(&u) == 0) {
        snprintf(g_arch,   sizeof(g_arch),   "%s", u.machine);
        snprintf(g_kernel, sizeof(g_kernel), "%s %s", u.sysname, u.release);
    }

    if (g_is_android) {
        char buf[4096];
        int n = read_file_str("/system/build.prop", buf, sizeof(buf));
        if (n > 0) {
            char *saveptr, *line;
            line = strtok_r(buf, "\n", &saveptr);
            while (line) {
                /* trim trailing \r */
                char *e = line + strlen(line) - 1;
                while (e >= line && *e == '\r') { *e = 0; e--; }
                /* skip leading whitespace */
                while (*line == ' ' || *line == '\t') line++;
                if (strncmp(line, "ro.product.model=", 17) == 0 && !g_device[0])
                    snprintf(g_device, sizeof(g_device), "%s", line+17);
                if (strncmp(line, "ro.build.version.release=", 25) == 0 && !g_android_ver[0])
                    snprintf(g_android_ver, sizeof(g_android_ver), "%s", line+25);
                line = strtok_r(NULL, "\n", &saveptr);
            }
        }
        if (!g_android_ver[0]) snprintf(g_android_ver, sizeof(g_android_ver), "unknown");
        if (!g_device[0])      snprintf(g_device, sizeof(g_device), "unknown");
    } else {
        char buf[4096];
        int n = read_file_str("/etc/os-release", buf, sizeof(buf));
        if (n > 0) {
            char *saveptr, *line;
            line = strtok_r(buf, "\n", &saveptr);
            while (line) {
                char *e = line + strlen(line) - 1;
                while (e >= line && *e == '\r') { *e = 0; e--; }
                if (strncmp(line, "PRETTY_NAME=", 12) == 0) {
                    char *v = line+12;
                    if (*v=='"'||*v=='\'') { v++; v[strlen(v)-1]=0; }
                    snprintf(g_distro, sizeof(g_distro), "%s", v);
                    break;
                }
                line = strtok_r(NULL, "\n", &saveptr);
            }
        }
        if (!g_distro[0]) {
            FILE *fp = popen("lsb_release -d 2>/dev/null", "r");
            if (fp) {
                char lb[256];
                if (fgets(lb, sizeof(lb), fp)) {
                    char *c = strchr(lb, ':');
                    if (c) { c++; while(*c==' ') c++; stripnl(c); snprintf(g_distro,sizeof(g_distro),"%s",c); }
                    else { stripnl(lb); snprintf(g_distro,sizeof(g_distro),"%s",lb); }
                }
                pclose(fp);
            }
        }
        if (!g_distro[0]) snprintf(g_distro, sizeof(g_distro), "Linux");
    }
}

/* ── Linux mode ── */
static void linux_mode(void) {
    printf(C_BOLD C_CYAN "\n  ▸ System Information  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" C_RESET "\n\n");
    printf("     " C_BOLD "OS" C_RESET "       %s\n", g_distro);
    printf("     " C_BOLD "Kernel" C_RESET "   %s\n", g_kernel);
    printf("     " C_BOLD "Arch" C_RESET "     %s\n", g_arch);
    printf("\n  " C_GREEN "✓ 环境正常，所有工具应该可以正常工作" C_RESET "\n\n");
}

/* ── Android interactive ── */
static int ask_yn(const char *prompt, int default_no) {
    printf("%s [%s/%s]: ", prompt, default_no ? "y" : "Y", default_no ? "N" : "n");
    fflush(stdout);
    char buf[16];
    if (!fgets(buf, sizeof(buf), stdin)) return 0;
    stripnl(buf);
    if (buf[0]==0) return default_no ? 0 : 1;
    if (!strcasecmp(buf,"y")||!strcasecmp(buf,"yes"))  return 1;
    if (!strcasecmp(buf,"n")||!strcasecmp(buf,"no"))   return 0;
    return default_no ? 0 : 1;
}

static int do_backup(const char *path) {
    if (!file_exists(path)) return 0;
    char bak[300];
    snprintf(bak, sizeof(bak), "%s.bak", path);
    if (file_exists(bak)) { unlink(bak); }
    if (rename(path, bak) < 0) {
        fprintf(stderr, C_RED "  ✗ 备份失败: %s (%s)" C_RESET "\n", path, strerror(errno));
        return -1;
    }
    printf("  ↻ 已备份: %s → %s\n", path, bak);
    return 0;
}

static int setup_ca(void) {
    printf("  ↻ 提取 CA 证书...\n");
    const char *cacerts = "/system/etc/security/cacerts";
    DIR *d = opendir(cacerts);
    if (!d) {
        fprintf(stderr, C_RED "  ✗ 无法打开 %s (%s)" C_RESET "\n", cacerts, strerror(errno));
        return -1;
    }

    int fd = open(g_ca_path, O_WRONLY|O_CREAT|O_TRUNC, 0644);
    if (fd < 0) { closedir(d); return -1; }
    close(fd);

    int count = 0;
    struct dirent *de;
    while ((de = readdir(d))) {
        if (de->d_name[0] == '.') continue;
        char fpath[512];
        snprintf(fpath, sizeof(fpath), "%s/%s", cacerts, de->d_name);
        int fd2 = open(fpath, O_RDONLY);
        if (fd2 < 0) continue;
        char *data = NULL;
        int   len  = 0;
        data = read_all(fd2, &len);
        close(fd2);
        if (!data || len == 0) { free(data); continue; }
        char *start = data;
        while (start < data+len && (*start=='\n'||*start=='\r'||*start==' '||*start=='\t')) start++;
        if (strncmp(start, "-----BEGIN", 10) == 0) {
            struct stat st;
            if (stat(g_ca_path, &st) == 0 && st.st_size > 0)
                append_file(g_ca_path, "\n", 1);
            append_file(g_ca_path, start, len - (start-data));
            count++;
        }
        free(data);
    }
    closedir(d);
    printf("  ✓ 已写入 %d 个证书 → %s\n", count, g_ca_path);
    return 0;
}

static int setup_dns(void) {
    printf("  ↻ 获取 DNS 配置...\n");
    char dns1[64] = {0};
    char dns2[64] = {0};

    FILE *fp = popen("getprop net.dns1 2>/dev/null", "r");
    if (fp) {
        if (fgets(dns1, sizeof(dns1), fp)) stripnl(dns1);
        pclose(fp);
    }
    fp = popen("getprop net.dns2 2>/dev/null", "r");
    if (fp) {
        if (fgets(dns2, sizeof(dns2), fp)) stripnl(dns2);
        pclose(fp);
    }

    if (!dns1[0]) {
        char tmp[256];
        if (read_file_str("/proc/net/dns", tmp, sizeof(tmp)) > 0) {
            char *saveptr;
            char *p = strtok_r(tmp, " \t\n", &saveptr);
            if (p) { snprintf(dns1, sizeof(dns1), "%s", p); p = strtok_r(NULL, " \t\n", &saveptr); }
            if (p)   snprintf(dns2, sizeof(dns2), "%s", p);
        }
    }
    if (!dns1[0]) snprintf(dns1, sizeof(dns1), "8.8.8.8");
    if (!dns2[0]) snprintf(dns2, sizeof(dns2), "8.8.4.4");

    char buf[256];
    int len = snprintf(buf, sizeof(buf),
        "# DNS config — auto-generated by Setup\n"
        "nameserver %s\n"
        "nameserver %s\n", dns1, dns2);
    (void)len;
    if (write_file_str(g_dns_path, buf) < 0) {
        fprintf(stderr, C_RED "  ✗ 写入 %s 失败" C_RESET "\n", g_dns_path);
        return -1;
    }
    printf("  ✓ DNS 配置已写入 → %s (%s, %s)\n", g_dns_path, dns1, dns2);
    return 0;
}

static int setup_nss(void) {
    const char *nss =
        "# NSS config — auto-generated by Setup\n"
        "passwd: files\n"
        "group:  files\n"
        "hosts:  files dns\n";
    if (write_file_str(g_nss_path, nss) < 0) {
        fprintf(stderr, C_RED "  ✗ 写入 %s 失败" C_RESET "\n", g_nss_path);
        return -1;
    }
    printf("  ✓ NSS 配置已写入 → %s\n", g_nss_path);
    return 0;
}

static void android_mode(void) {
    printf(C_BOLD C_CYAN "\n  ━━━  Step 1: System Info  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" C_RESET "\n\n");
    printf("     " C_BOLD "OS" C_RESET "       Android %s\n", g_android_ver);
    printf("     " C_BOLD "Device" C_RESET "   %s\n", g_device);
    printf("     " C_BOLD "Kernel" C_RESET "   %s\n", g_kernel);
    printf("     " C_BOLD "Arch" C_RESET "     %s\n", g_arch);

    printf(C_BOLD C_CYAN "\n  ━━━  Step 2: Config Status  ━━━━━━━━━━━━━━━━━━━━━━━━━━━" C_RESET "\n\n");
    int ca_ok  = file_exists(g_ca_path);
    int dns_ok = file_exists(g_dns_path);
    int nss_ok = file_exists(g_nss_path);
    printf("     %s  %s\n", ca_ok ?C_GREEN "✓":C_RED "✗", g_ca_path);
    printf("     %s  %s\n", dns_ok?C_GREEN "✓":C_RED "✗", g_dns_path);
    printf("     %s  %s\n", nss_ok?C_GREEN "✓":C_RED "✗", g_nss_path);

    if (dns_ok) {
        char buf[64];
        if (read_file_str(g_dns_path, buf, sizeof(buf)) > 0 && strlen(buf) > 0) {
            printf(C_YELLOW "\n  ⚠ 可能运行在容器环境中，是否仍要配置?" C_RESET);
            if (!ask_yn("", 1)) {
                printf(C_YELLOW "  ↻ 已取消" C_RESET "\n");
                exit(0);
            }
        }
    }

    printf(C_BOLD C_YELLOW "\n  ━━━  Step 4: Confirm  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" C_RESET "\n\n");
    printf("  将执行:\n\n"
           "    1. 提取 CA 证书 → %s\n"
           "    2. 写入 DNS 配置 → %s\n"
           "    3. 生成 NSS 配置 → %s\n\n", g_ca_path, g_dns_path, g_nss_path);
    printf(C_YELLOW "  ⚠ recovery 环境安全，已 root 的正常系统可能覆盖现有配置\n" C_RESET);
    if (!g_is_root)
        printf(C_RED "  ⚠ 需要 root 权限" C_RESET "\n");

    if (!ask_yn("\n  是否继续?", 1)) {
        printf(C_YELLOW "  ↻ 用户取消" C_RESET "\n");
        exit(1);
    }

    if (!g_is_root) {
        fprintf(stderr, C_RED "\n  ✗ 权限不足 — 需要 root 才能写入 /etc\n" C_RESET "\n");
        exit(2);
    }

    printf(C_BOLD "\n  ━━━  Step 5: Backup  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" C_RESET "\n\n");
    if (ca_ok)  do_backup(g_ca_path);
    if (dns_ok) do_backup(g_dns_path);
    if (nss_ok) do_backup(g_nss_path);

    printf(C_BOLD "\n  ━━━  Step 6: Configure  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" C_RESET "\n\n");
    int ok = 1;
    if (setup_ca()  < 0) { ok = 0; fprintf(stderr, C_RED "  ✗ CA 证书提取失败" C_RESET "\n"); }
    if (setup_dns() < 0) { ok = 0; fprintf(stderr, C_RED "  ✗ DNS 配置写入失败" C_RESET "\n"); }
    if (setup_nss() < 0) { ok = 0; fprintf(stderr, C_RED "  ✗ NSS 配置写入失败" C_RESET "\n"); }

    if (ok) {
        printf(C_BOLD C_GREEN "\n  ━━━  Step 7: Done  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" C_RESET "\n\n");
        printf(C_GREEN "  ✓ 配置完成" C_RESET "\n\n");
        printf("     %s → %s\n", g_ca_path,  file_exists(g_ca_path) ?C_GREEN "OK":C_RED "FAIL");
        printf("     %s → %s\n", g_dns_path, file_exists(g_dns_path)?C_GREEN "OK":C_RED "FAIL");
        printf("     %s → %s\n", g_nss_path, file_exists(g_nss_path)?C_GREEN "OK":C_RED "FAIL");
        printf("\n  " C_BOLD "测试" C_RESET ":\n");
        printf("     mytools curl https://example.com\n");
        printf("     mytools wget https://example.com\n");
        exit(0);
    } else {
        printf(C_BOLD C_RED "\n  ✗ 配置失败" C_RESET "\n\n");
        printf("  手动操作:\n");
        printf("    cp /system/etc/security/cacerts/* %s\n", g_ca_path);
        printf("    echo 'nameserver 8.8.8.8' > %s\n", g_dns_path);
        printf("    echo -e 'passwd: files\\ngroup: files\\nhosts: files dns' > %s\n", g_nss_path);
        exit(3);
    }
}

int main(int argc __attribute__((unused)), char **argv __attribute__((unused))) {
    printf(C_BOLD "\n  ███████╗███████╗████████╗██╗   ██╗██████╗ \n"
           "  ██╔════╝██╔════╝╚══██╔══╝██║   ██║██╔══██╗\n"
           "  ███████╗█████╗     ██║   ██║   ██║██████╔╝\n"
           "  ╚════██║██╔══╝     ██║   ██║   ██║██╔═══╝\n"
           "  ███████║███████╗   ██║   ╚██████╔╝██║\n"
           "  ╚══════╝╚══════╝   ╚═╝    ╚═════╝ ╚═╝\n\n"
           "   Environment Setup — CA / DNS / NSS\n" C_RESET "\n");

    g_is_root = (geteuid() == 0);
    if (!g_is_root) {
        printf(C_YELLOW "  ⚠ 警告: 非 root 运行，仅检测，不写入" C_RESET "\n\n");
    }

    snprintf(g_ca_path,  sizeof(g_ca_path),  "/etc/ssl/certs/ca-certificates.crt");
    snprintf(g_dns_path, sizeof(g_dns_path), "/etc/resolv.conf");
    snprintf(g_nss_path, sizeof(g_nss_path), "/etc/nsswitch.conf");

    printf("  ↻ 检测环境...\n");
    g_is_android = detect_android();
    gather_info();

    printf("  ✓ 检测完成: %s\n\n", g_is_android ? "Android" : "Linux");

    if (!g_is_android) {
        linux_mode();
        return 0;
    }

    android_mode();
    return 0;
}
