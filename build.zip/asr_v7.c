#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdint.h>
#include <errno.h>
#include "whisper.h"

// ------------------- 嵌入的资源数据 -------------------
extern const unsigned char _binary_emb_toybox_start[], _binary_emb_toybox_end[];
extern const unsigned char _binary_ffmpeg_static_start[], _binary_ffmpeg_static_end[];
extern const unsigned char _binary_whisper_build_ggml_model_bin_start[], _binary_whisper_build_ggml_model_bin_end[];

// 作者信息（Base64 编码）
static const char *auth_b64 = "ZGVlcHNlZWsgdjQgZmxhc2ggJiBAQ2hlbjkxODMgKGdpdGh1Yik=";

// ------------------- Base64 解码函数 -------------------
static void b64_decode(char *out, size_t *out_len, const char *in) {
    static int T[256];
    static int init_done = 0;
    if (!init_done) {
        init_done = 1;
        T['A']=0;T['B']=1;T['C']=2;T['D']=3;T['E']=4;T['F']=5;T['G']=6;T['H']=7;T['I']=8;T['J']=9;
        T['K']=10;T['L']=11;T['M']=12;T['N']=13;T['O']=14;T['P']=15;T['Q']=16;T['R']=17;T['S']=18;T['T']=19;
        T['U']=20;T['V']=21;T['W']=22;T['X']=23;T['Y']=24;T['Z']=25;
        T['a']=26;T['b']=27;T['c']=28;T['d']=29;T['e']=30;T['f']=31;T['g']=32;T['h']=33;T['i']=34;T['j']=35;
        T['k']=36;T['l']=37;T['m']=38;T['n']=39;T['o']=40;T['p']=41;T['q']=42;T['r']=43;T['s']=44;T['t']=45;
        T['u']=46;T['v']=47;T['w']=48;T['x']=49;T['y']=50;T['z']=51;
        T['0']=52;T['1']=53;T['2']=54;T['3']=55;T['4']=56;T['5']=57;T['6']=58;T['7']=59;T['8']=60;T['9']=61;
        T['+']=62;T['/']=63;
    }
    size_t len = 0;
    for (size_t i = 0; in[i] && in[i] != '='; i += 4) {
        uint32_t v = (T[(unsigned char)in[i]] << 18) | (T[(unsigned char)in[i+1]] << 12);
        if (in[i+2] != '=') v |= (T[(unsigned char)in[i+2]] << 6);
        if (in[i+3] != '=') v |= T[(unsigned char)in[i+3]];
        out[len++] = (v >> 16) & 0xFF;
        if (len < *out_len && in[i+2] != '=') out[len++] = (v >> 8) & 0xFF;
        if (len < *out_len && in[i+3] != '=') out[len++] = v & 0xFF;
    }
    *out_len = len;
}

// ------------------- 帮助信息 -------------------
static void show_help(const char *prog) {
    char author[128]; size_t al = sizeof(author);
    b64_decode(author, &al, auth_b64);
    author[al] = '\0';
    fprintf(stderr,
        "asr - speech recognition (whisper.cpp ggml-small, self-contained)\n"
        "Author: %s\n"
        "\n"
        "Usage: %s <audio> [output.txt]\n"
        "\n"
        "  %s --help  or  %s -h    show this help\n"
        "\n"
        "Arguments:\n"
        "  <audio>       input audio file (any ffmpeg-supported format)\n"
        "  [output.txt]  optional output text file (default: stdout)\n"
        "\n"
        "Supported formats: mp3 wav flac ogg opus aac m4a mp4 ...\n"
        "Model: whisper.cpp ggml-small (487 MB, embedded)\n"
        "Decoder: ffmpeg 7.0.2 (embedded)\n"
        "Language: auto-detect (99 languages)\n"
        "\n"
        "Examples:\n"
        "  %s recording.m4a\n"
        "  %s speech.mp3 transcript.txt\n"
        "\n"
        "Embedded assets:\n"
        "  whisper ggml-small model  487 MB\n"
        "  ffmpeg static              49 MB\n"
        "  toybox (cleanup tool)      ~800 KB\n"
        "  Total binary size         ~518 MB\n",
        author, prog, prog, prog, prog, prog);
}

// ------------------- 全局临时目录路径（用于清理） -------------------
static char g_tmp_dir[320] = {0};
static char g_toybox_path[320] = {0};

// ------------------- 清理函数（由 atexit 注册） -------------------
static void cleanup(void) {
    if (g_tmp_dir[0] == '\0') return;
    if (g_toybox_path[0] != '\0' && access(g_toybox_path, X_OK) == 0) {
        pid_t p = fork();
        if (p == 0) {
            execl(g_toybox_path, "toybox", "rm", "-rf", g_tmp_dir, NULL);
            _exit(1);
        }
        int st;
        while (waitpid(p, &st, 0) == -1 && errno == EINTR);
    } else {
        char cmd[512];
        snprintf(cmd, sizeof(cmd), "rm -rf %s", g_tmp_dir);
        system(cmd);
    }
}

// ------------------- 主函数 -------------------
int main(int argc, char **argv) {
    // 1. 参数处理
    if (argc < 2 || !strcmp(argv[1], "--help") || !strcmp(argv[1], "-h")) {
        show_help(argv[0]);
        return (argc < 2) ? 1 : 0;
    }
    if (argc > 3) {
        fprintf(stderr, "Warning: extra arguments ignored.\n");
    }

    // 2. 检查 /tmp 可用性
    if (access("/tmp", W_OK | X_OK) != 0) {
        fprintf(stderr, "Fatal: /tmp is not writable and/or executable. Abort.\n");
        return 1;
    }

    // 3. 创建安全临时目录
    char tmp_template[] = "/tmp/asr_XXXXXX";
    char *tmp_dir = mkdtemp(tmp_template);
    if (!tmp_dir) {
        perror("mkdtemp");
        return 2;
    }
    strncpy(g_tmp_dir, tmp_dir, sizeof(g_tmp_dir) - 1);
    g_tmp_dir[sizeof(g_tmp_dir) - 1] = '\0';

    char toybox_path[320], ffmpeg_path[320], wav_path[320];
    snprintf(toybox_path, sizeof(toybox_path), "%s/toybox", g_tmp_dir);
    snprintf(ffmpeg_path, sizeof(ffmpeg_path), "%s/ffmpeg", g_tmp_dir);
    snprintf(wav_path, sizeof(wav_path), "%s/audio.wav", g_tmp_dir);
    strncpy(g_toybox_path, toybox_path, sizeof(g_toybox_path) - 1);
    g_toybox_path[sizeof(g_toybox_path) - 1] = '\0';

    atexit(cleanup);

    // 4. 解压 toybox 和 ffmpeg
    int fd;
    ssize_t wr;
    fd = open(toybox_path, O_WRONLY | O_CREAT | O_TRUNC, 0755);
    if (fd < 0) { perror("open toybox"); return 3; }
    wr = write(fd, _binary_emb_toybox_start, _binary_emb_toybox_end - _binary_emb_toybox_start);
    close(fd);
    if (wr != (ssize_t)(_binary_emb_toybox_end - _binary_emb_toybox_start)) {
        fprintf(stderr, "Failed to write toybox completely\n");
        return 3;
    }

    fd = open(ffmpeg_path, O_WRONLY | O_CREAT | O_TRUNC, 0755);
    if (fd < 0) { perror("open ffmpeg"); return 3; }
    wr = write(fd, _binary_ffmpeg_static_start, _binary_ffmpeg_static_end - _binary_ffmpeg_static_start);
    close(fd);
    if (wr != (ssize_t)(_binary_ffmpeg_static_end - _binary_ffmpeg_static_start)) {
        fprintf(stderr, "Failed to write ffmpeg completely\n");
        return 3;
    }

    // 5. ffmpeg 转码
    fprintf(stderr, "Converting audio...\n");
    pid_t p = fork();
    if (p == 0) {
        char *av[] = {
            ffmpeg_path,
            "-loglevel", "error",
            "-y",
            "-i", argv[1],
            "-ac", "1",
            "-ar", "16000",
            "-f", "wav",
            wav_path,
            NULL
        };
        execv(ffmpeg_path, av);
        _exit(1);
    }
    int st;
    while (waitpid(p, &st, 0) == -1 && errno == EINTR);
    if (!WIFEXITED(st) || WEXITSTATUS(st) != 0) {
        fprintf(stderr, "ERROR: ffmpeg conversion failed.\n");
        return 4;
    }

    // 6. 读取 WAV 文件
    struct stat wst;
    if (stat(wav_path, &wst) != 0) {
        perror("stat wav");
        return 5;
    }
    fd = open(wav_path, O_RDONLY);
    if (fd < 0) {
        perror("open wav");
        return 5;
    }
    unsigned char *wbuf = (unsigned char*)malloc(wst.st_size);
    if (!wbuf) {
        fprintf(stderr, "Out of memory\n");
        close(fd);
        return 5;
    }
    ssize_t nread = read(fd, wbuf, wst.st_size);
    close(fd);
    if (nread != (ssize_t)wst.st_size) {
        fprintf(stderr, "Failed to read whole wav file\n");
        free(wbuf);
        return 5;
    }
    unlink(wav_path);

    // 7. 解析 WAV 头部
    typedef struct {
        char r[4];      // "RIFF"
        uint32_t sz;
        char w[4];      // "WAVE"
        char f[4];      // "fmt "
        uint32_t fsz;
        uint16_t af;    // audio format
        uint16_t nc;    // channels
        uint32_t sr;    // sample rate
        uint32_t br;    // byte rate
        uint16_t ba;    // block align
        uint16_t bps;   // bits per sample
    } __attribute__((packed)) WavHeader;

    WavHeader *h = (WavHeader*)wbuf;
    if (memcmp(h->r, "RIFF", 4) || memcmp(h->w, "WAVE", 4) || memcmp(h->f, "fmt ", 4)) {
        fprintf(stderr, "Invalid WAV file\n");
        free(wbuf);
        return 6;
    }
    uint32_t off = 12 + 8 + h->fsz;
    while (off + 8 <= (uint32_t)wst.st_size) {
        if (wbuf[off] == 'd' && wbuf[off+1] == 'a' && wbuf[off+2] == 't' && wbuf[off+3] == 'a') {
            off += 8;
            break;
        }
        uint32_t chunk_size = *(uint32_t*)(wbuf + off + 4);
        off += 8 + chunk_size;
    }
    if (off + 8 > (uint32_t)wst.st_size) {
        fprintf(stderr, "No data chunk found\n");
        free(wbuf);
        return 6;
    }
    uint32_t data_bytes = wst.st_size - off;
    int num_samples = data_bytes / (h->bps / 8);
    if (num_samples == 0) {
        fprintf(stderr, "No audio data\n");
        free(wbuf);
        return 6;
    }

    // 8. 转换为 float
    float *samples = (float*)malloc(num_samples * sizeof(float));
    if (!samples) {
        fprintf(stderr, "Out of memory for samples\n");
        free(wbuf);
        return 6;
    }
    if (h->bps == 16) {
        int16_t *p16 = (int16_t*)(wbuf + off);
        for (int i = 0; i < num_samples; i++) {
            samples[i] = p16[i] / 32768.0f;
        }
    } else if (h->bps == 8) {
        uint8_t *p8 = (uint8_t*)(wbuf + off);
        for (int i = 0; i < num_samples; i++) {
            samples[i] = (p8[i] - 128) / 128.0f;
        }
    } else {
        fprintf(stderr, "Unsupported bits per sample: %d\n", h->bps);
        free(wbuf); free(samples);
        return 6;
    }
    free(wbuf);

    // 9. 加载模型
    size_t model_size = _binary_whisper_build_ggml_model_bin_end - _binary_whisper_build_ggml_model_bin_start;
    fprintf(stderr, "Loading model (%zu MB)...\n", model_size / (1024*1024));
    struct whisper_context_params cparams = whisper_context_default_params();
    cparams.use_gpu = false;
    struct whisper_context *ctx = whisper_init_from_buffer_with_params_no_state(
        (void*)_binary_whisper_build_ggml_model_bin_start, model_size, cparams);
    if (!ctx) {
        fprintf(stderr, "ERROR: failed to initialize whisper context\n");
        free(samples);
        return 7;
    }
    struct whisper_state *state = whisper_init_state(ctx);
    if (!state) {
        fprintf(stderr, "ERROR: failed to initialize whisper state\n");
        whisper_free(ctx);
        free(samples);
        return 7;
    }

    // 10. 执行转录
    struct whisper_full_params wparams = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    wparams.print_progress = false;
    wparams.translate = false;
    wparams.language = (char*)"auto";
    wparams.n_threads = 4;
    wparams.no_context = true;

    fprintf(stderr, "Transcribing...\n");
    int ret = whisper_full_with_state(ctx, state, wparams, samples, num_samples);
    free(samples);  // 样本已不再需要

    // ⚠️ 关键：必须在释放 state 之前读取 segment 数据！
    if (ret == 0) {
        int nseg = whisper_full_n_segments_from_state(state);
        if (argc >= 3) {
            int out_fd = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0644);
            if (out_fd < 0) {
                perror("open output file");
                ret = 8;
            } else {
                for (int i = 0; i < nseg; i++) {
                    const char *text = whisper_full_get_segment_text_from_state(state, i);
                    if (text) {
                        write(out_fd, text, strlen(text));
                    }
                }
                write(out_fd, "\n", 1);
                close(out_fd);
                fprintf(stderr, "Done -> %s (%d segments)\n", argv[2], nseg);
            }
        } else {
            for (int i = 0; i < nseg; i++) {
                const char *text = whisper_full_get_segment_text_from_state(state, i);
                if (text) {
                    fwrite(text, 1, strlen(text), stdout);
                }
            }
            printf("\n");
        }
    } else {
        fprintf(stderr, "ERROR: transcription failed (code %d)\n", ret);
    }

    // 11. 释放资源（此时 state 已不再使用）
    whisper_free_state(state);
    whisper_free(ctx);

    // atexit 会自动删除临时目录
    return (ret == 0) ? 0 : 8;
}