.section .text.start,"ax"
.globl _start
_start:
    /* On aarch64 Linux, at _start stack layout is:
     * sp+0: argc
     * sp+8: argv[0], argv[1], ..., NULL
     * after argv NULL: envp[0], envp[1], ..., NULL
     */
    ldr x0, [sp]         /* x0 = argc */
    add x1, sp, #8       /* x1 = argv */

    /* Find envp: scan past NULL terminator of argv */
    mov x2, x1
0:  ldr x3, [x2], #8
    cbnz x3, 0b
    mov x2, x2           /* x2 = envp (past the NULL) */

    b main_entry
