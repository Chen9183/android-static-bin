/*
 * ai.c — 纯 C 单二进制 AI 对话客户端 (arm64 Linux/Android)
 * 内嵌 curl + jq + busybox，通过 memfd_create+execveat 从内存执行
 * 支持多提供商，按平台自动选择配置目录
 *   Linux   : /var/tmp/ai.conf/
 *   Android : /data/local/tmp/ai.conf/
 *
 * 构建:
 *   ld -r -b binary -o curl_embed.o curl
 *   ld -r -b binary -o jq_embed.o jq
 *   ld -r -b binary -o busybox_embed.o busybox
 *   aarch64-linux-musl-gcc -static -O2 -Wno-format-truncation -o ai ai.c curl_embed.o jq_embed.o busybox_embed.o
 */
#define _GNU_SOURCE
#define __USE_GNU
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdarg.h>
#include <errno.h>
#include <sys/syscall.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <ctype.h>
#include <signal.h>
#include <termios.h>
#include <time.h>
#include <locale.h>
#include <wchar.h>
#include <wctype.h>

/* ============ 最大缓冲区定义 ============ */
#define MAX_PATH      262144
#define MAX_LINE      262144
#define MAX_STR       262144
#define MAX_KEY       262144
#define MAX_PROMPT    524288
#define MAX_BIG       262144

extern const unsigned char _binary_curl_start[];
extern const unsigned char _binary_curl_end[];
extern const unsigned char _binary_jq_start[];
extern const unsigned char _binary_jq_end[];
extern const unsigned char _binary_busybox_start[];
extern const unsigned char _binary_busybox_end[];

/* ============ 平台检测与配置路径 ============ */
static int is_android(void) {
    struct stat st;
    if (access("/system/build.prop", F_OK) == 0) return 1;
    if (access("/data/local/tmp", F_OK) == 0) return 1;
    if (access("/system/bin", F_OK) == 0) return 1;
    return 0;
}

static void get_conf_dir(char *buf, size_t bufsz) {
    if (is_android()) {
        snprintf(buf, bufsz, "/data/local/tmp/ai.conf");
    } else {
        snprintf(buf, bufsz, "/var/tmp/ai.conf");
    }
}

static void get_conf_file(char *buf, size_t bufsz, const char *name) {
    char dir[MAX_PATH];
    get_conf_dir(dir, sizeof(dir));
    snprintf(buf, bufsz, "%s/%s.conf", dir, name);
}

static void ensure_conf_dir(void) {
    char dir[MAX_PATH];
    get_conf_dir(dir, sizeof(dir));
    char *argv[] = {"mkdir", "-p", dir, NULL};
    pid_t pid = fork();
    if (pid == 0) {
        execv("/bin/mkdir", argv);
        execv("/data/local/tmp/ai.conf/../mkdir", argv);
        _exit(127);
    }
    if (pid > 0) waitpid(pid, NULL, 0);
    mkdir(dir, 0755);
}

#define HIST_MAX 100

/* 流式中断 */
volatile sig_atomic_t g_interrupt = 0;
volatile sig_atomic_t g_in_request = 0;
int g_stream_interrupted = 0;

#define GC  "\033[32m"
#define CY  "\033[36m"
#define YL  "\033[33m"
#define MG  "\033[35m"
#define RS  "\033[0m"

/* ============ AI 多提供商系统 ============ */
typedef struct {
    const char *name;
    const char *conf_key;
    const char *base;
    const char *model;
    const char *description;
} Provider;

static Provider providers[] = {
    {"OpenAI",          "openai",     "https://api.openai.com/v1",                       "gpt-4o-mini",          "OpenAI GPT 系列"},
    {"DeepSeek",        "deepseek",   "https://api.deepseek.com/v1",                     "deepseek-chat",        "DeepSeek 深度求索"},
    {"Kimi/Moonshot",   "moonshot",   "https://api.moonshot.cn/v1",                    "moonshot-v1-8k",      "月之暗面 Kimi"},
    {"Google Gemini",   "gemini",     "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-2.0-flash",  "Google Gemini"},
    {"Anthropic Claude","anthropic",  "https://api.anthropic.com/v1",                  "claude-3-haiku-20240307","Anthropic Claude"},
    {"阿里通义千问",    "aliyun",     "https://dashscope.aliyuncs.com/compatible-mode/v1", "qwen-turbo",       "阿里云通义千问"},
    {"智谱 GLM",       "zhipu",      "https://open.bigmodel.cn/api/paas/v4",          "glm-4-flash",         "智谱 AI GLM"},
    {"Groq",           "groq",       "https://api.groq.com/openai/v1",                 "llama-3.3-70b-versatile","Groq 高速推理"},
    {"Mistral",        "mistral",    "https://api.mistral.ai/v1",                     "mistral-small-latest", "Mistral AI"},
    {"自定义",         "custom",     "",                                            "",                     "手动输入地址和模型"},
};
#define NPROV ((int)(sizeof(providers)/sizeof(providers[0])))

/* AI 提供商的运行时配置 */
#define MAX_KEYS_PER_PROV 5
typedef struct {
    char api_base[MAX_STR];
    char api_keys[MAX_KEYS_PER_PROV][MAX_KEY];
    int  num_keys;
    int  active_key;
    char model[MAX_STR];
    int  enabled;
} ProvConf;

static ProvConf prov_conf[NPROV];
static int current_provider = -1;
static int has_any_config = 0;

/* ============ 搜索提供商系统 ============ */
typedef struct {
    const char *name;
    const char *id;
    const char *default_api_url;
    const char *auth_header_template;  // 如 "X-API-KEY: %s" 或 "Ocp-Apim-Subscription-Key: %s"
    const char *description;
} SearchProviderDef;

static SearchProviderDef search_provider_defs[] = {
    {"Serper.dev",      "serper",   "https://google.serper.dev/search",        "X-API-KEY: %s",          "Google 搜索结果（便宜）"},
    {"Tavily",          "tavily",   "https://api.tavily.com/search",            "Authorization: Bearer %s","专为 AI 设计（有免费额度）"},
    {"Bing 官方 API",   "bing",     "https://api.bing.microsoft.com/v7.0/search","Ocp-Apim-Subscription-Key: %s", "微软官方（每月1000次免费）"},
    {"自定义",          "custom",   "",                                        "X-API-KEY: %s",          "手动输入地址和 Key"},
};
#define NSEARCHPROV ((int)(sizeof(search_provider_defs)/sizeof(search_provider_defs[0])))

/* 搜索提供商的运行时配置 */
#define MAX_SEARCH_KEYS 5
typedef struct {
    char api_base[MAX_STR];
    char api_keys[MAX_SEARCH_KEYS][MAX_KEY];
    int  num_keys;
    int  active_key;
    int  enabled;
} SearchConf;

static SearchConf search_conf[NSEARCHPROV];
static int current_search_provider = 0;  // 默认 Serper
static int search_modified = 0;

/* ============ 全局设置 ============ */
static char SYSTEM_PROMPT[MAX_PROMPT] = "你是一个乐于助人的助手";
static char CA_BUNDLE[MAX_PATH] = "";
static int  THINK = 1;
static int  SHOWTHINK = 1;
static int  TOOLS_ENABLED = 0;

/* 历史 */
typedef struct { char role[16]; char *content; } Msg;
static Msg hist[HIST_MAX];
static int hist_n = 0;

/* 前向声明 */
static char *read_line(void);
static char *jq_query(const char *filter, const char *json);
static int  extract_json_val(const char *str, const char *key, char *buf, size_t bufsz);

/* ============ memfd + 嵌入二进制执行 ============ */
static long sc_memfd_create(const char *name, unsigned int flags) {
    return syscall(SYS_memfd_create, name, flags);
}

static long exec_embedded(const unsigned char *bs, const unsigned char *be,
                          const char *arg0, char **argv,
                          const char *stdin_data, ssize_t stdin_len, char **out) {
    size_t cap = 65536, len = 0;
    char *buf = malloc(cap);
    int inpipe[2] = {-1,-1}, outpipe[2] = {-1,-1};
    if (!buf) return -1;
    if (pipe(outpipe) != 0) { free(buf); return -1; }
    if (stdin_data) {
        if (pipe(inpipe) != 0) { close(outpipe[0]); close(outpipe[1]); free(buf); return -1; }
    }
    long fd = sc_memfd_create(arg0, 0);
    if (fd < 0) { close(outpipe[0]); close(outpipe[1]); if(stdin_data){close(inpipe[0]);close(inpipe[1]);} free(buf); return -1; }
    {
        size_t sz = (size_t)(be - bs), off = 0;
        while (off < sz) {
            ssize_t w = write((int)fd, bs + off, sz - off);
            if (w <= 0) { close((int)fd); close(outpipe[0]); close(outpipe[1]); if(stdin_data){close(inpipe[0]);close(inpipe[1]);} free(buf); return -1; }
            off += (size_t)w;
        }
    }
    pid_t pid = fork();
    if (pid < 0) { close((int)fd); close(outpipe[0]); close(outpipe[1]); if(stdin_data){close(inpipe[0]);close(inpipe[1]);} free(buf); return -1; }
    if (pid == 0) {
        if (stdin_data) { dup2(inpipe[0], 0); close(inpipe[0]); close(inpipe[1]); }
        else { int dn = open("/dev/null", O_RDONLY); if(dn>=0){ dup2(dn,0); close(dn); } }
        dup2(outpipe[1], 1);
        dup2(outpipe[1], 2);
        close(outpipe[0]); close(outpipe[1]);
        char *nargv[64];
        int i, n = 0;
        nargv[n++] = (char*)arg0;
        for (i = 0; argv && argv[i] && n < 62; i++) nargv[n++] = argv[i];
        nargv[n] = NULL;
        const char *envp[] = {
            "PATH=/system/bin:/data/bin:/usr/bin:/bin",
            "HOME=/data/local/tmp",
            "SSL_CERT_FILE=",
            "LANG=C", "LC_ALL=C", NULL
        };
        syscall(SYS_execveat, (int)fd, "", nargv, envp, AT_EMPTY_PATH);
        _exit(127);
    }
    if (stdin_data) {
        close(inpipe[0]);
        ssize_t total = 0;
        while (total < stdin_len) {
            ssize_t w = write(inpipe[1], stdin_data + total, stdin_len - total);
            if (w <= 0) break;
            total += w;
        }
        close(inpipe[1]);
    }
    close(outpipe[1]);
    {
        ssize_t r;
        while ((r = read(outpipe[0], buf + len, cap - len - 1)) > 0) {
            len += r;
            if (len + 4096 >= cap) { cap *= 2; char *nb = realloc(buf, cap); if (!nb) { close(outpipe[0]); close((int)fd); while(waitpid(pid,NULL,0)!=-1){} free(buf); return -1; } buf = nb; }
        }
    }
    close(outpipe[0]);
    close((int)fd);
    while (waitpid(pid, NULL, 0) != -1) {}
    buf[len] = 0;
    *out = buf;
    return (long)len;
}

#define exec_curl(argv,out)    exec_embedded(_binary_curl_start,_binary_curl_end,"curl",(argv),NULL,0,(out))
#define exec_jq_stdin(argv,json,out) exec_embedded(_binary_jq_start,_binary_jq_end,"jq",(argv),(json),(ssize_t)strlen(json),(out))
#define exec_busybox(argv,out) exec_embedded(_binary_busybox_start,_binary_busybox_end,"busybox",(argv),NULL,0,(out))

/* ============ 工具系统 ============ */
static char *g_toolcache = NULL;
static char g_cut_name[MAX_STR] = {0}, g_cut_args[MAX_STR] = {0};
static char *PEND_ARG = NULL;

static char *run_shell_timed(const char *cmd, long timeout_ms, long out_cap) {
    char *argv[] = {"sh", "-c", (char*)cmd, NULL};
    char *raw = NULL;
    long n = exec_busybox(argv, &raw);
    if (n < 0 || !raw) return NULL;
    if (out_cap > 0 && n > (long)out_cap) { raw[out_cap - 1] = 0; }
    return raw;
}

static char *tool_time_now(void) {
    char *argv[] = {"date", "+%Y-%m-%d %H:%M:%S %Z (Asia/Shanghai)", NULL};
    char *raw = NULL;
    if (exec_busybox(argv, &raw) < 0 || !raw) return strdup("(无法读取本地时间)");
    size_t l = strlen(raw); while (l && (raw[l-1]=='\n'||raw[l-1]=='\r')) raw[--l] = 0;
    char *r = strdup(raw); free(raw);
    return r ? r : strdup("(时间错误)");
}

static void html_decode(char *s) {
    char *r = s, *w = s;
    while (*r) {
        if (*r == '&') {
            if (!strncmp(r, "&amp;", 5)) { *w++ = '&'; r += 5; continue; }
            if (!strncmp(r, "&lt;", 4)) { *w++ = '<'; r += 4; continue; }
            if (!strncmp(r, "&gt;", 4)) { *w++ = '>'; r += 4; continue; }
            if (!strncmp(r, "&quot;", 6)) { *w++ = '"'; r += 6; continue; }
            if (!strncmp(r, "&#39;", 5)) { *w++ = '\''; r += 5; continue; }
            if (!strncmp(r, "&nbsp;", 6)) { *w++ = ' '; r += 6; continue; }
        }
        *w++ = *r++;
    }
    *w = 0;
}

static void strip_tags(char *s) {
    char *r = s, *w = s; int in = 0;
    while (*r) { if (*r == '<') { in = 1; r++; continue; } if (*r == '>') { in = 0; r++; continue; } if (!in) { *w++ = *r; } r++; }
    *w = 0;
    char *a = s, *b = s; int spc = 0;
    while (*a) { if (*a==' '||*a=='\t'||*a=='\n'||*a=='\r') { if (!spc) { *b++ = ' '; spc = 1; } } else { spc = 0; *b++ = *a; } a++; }
    *b = 0;
    while (b > s && (*(b-1) == ' ')) { *(--b) = 0; }
}

static void urlencode(const char *in, char *out, size_t outsz) {
    size_t o = 0;
    for (const char *p = in; *p && o + 4 < outsz; p++) {
        unsigned char c = (unsigned char)*p;
        if ((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='-'||c=='_'||c=='.'||c=='~') { out[o++] = c; }
        else if (c == ' ') { out[o++] = '+'; }
        else { out[o++] = '%'; const char *h = "0123456789ABCDEF"; out[o++] = h[(c>>4)&15]; out[o++] = h[c&15]; }
    }
    out[o] = 0;
}
/* ===== Base64 Codec ===== */
static const char b64t[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
static int b64enc(const unsigned char *s, size_t n, char *d, size_t dz) {
    size_t i,j=0;
    for(i=0;i<n;i+=3){
        unsigned a=s[i],b=(i+1<n)?s[i+1]:0,c=(i+2<n)?s[i+2]:0,t=(a<<16)|(b<<8)|c;
        if(j+4>=dz)return -1;
        d[j++]=b64t[(t>>18)&63];d[j++]=b64t[(t>>12)&63];
        d[j++]=(i+1<n)?b64t[(t>>6)&63]:'=';d[j++]=(i+2<n)?b64t[t&63]:'=';
    }
    d[j]=0;return (int)j;
}
static int b64dec(const char *s, unsigned char *d, size_t dz) {
    size_t i,j=0;unsigned char rv[256]={0};
    for(int k=0;k<64;k++) rv[(unsigned char)b64t[k]]=(unsigned char)k;
    for(i=0;s[i]&&s[i]!='=';i+=4){
        unsigned t=(rv[(unsigned char)s[i]]<<18)|(rv[(unsigned char)s[i+1]]<<12);
        if(s[i+2]&&s[i+2]!='=')t|=(rv[(unsigned char)s[i+2]]<<6);
        if(s[i+3]&&s[i+3]!='=')t|=rv[(unsigned char)s[i+3]];
        if(j<dz)d[j++]=(t>>16)&255;
        if(j<dz&&s[i+2]&&s[i+2]!='=')d[j++]=(t>>8)&255;
        if(j<dz&&s[i+3]&&s[i+3]!='=')d[j++]=t&255;
    }
    if(j<dz)d[j]=0;return (int)j;
}
static char *getkey(int pi) {
    if(pi<0||pi>=NPROV||prov_conf[pi].num_keys==0)return strdup("");
    int ak=prov_conf[pi].active_key;
    if(ak<0||ak>=prov_conf[pi].num_keys)ak=0;
    unsigned char b[MAX_KEY];
    b64dec(prov_conf[pi].api_keys[ak], b, sizeof(b));
    return strdup((char*)b);
}
static int addkey(int pi, const char *pk) {
    if(pi<0||pi>=NPROV)return -1;
    int n=prov_conf[pi].num_keys;
    if(n>=MAX_KEYS_PER_PROV)return -1;
    char e[MAX_KEY];
    if(b64enc((unsigned char*)pk,strlen(pk),e,sizeof(e))<0)return -1;
    snprintf(prov_conf[pi].api_keys[n],sizeof(prov_conf[pi].api_keys[0]),"%s",e);
    prov_conf[pi].num_keys=n+1;
    return n;
}

static void init_prov_conf(void) {
    for (int i = 0; i < NPROV; i++) {
        prov_conf[i].api_base[0] = 0;
        for (int k = 0; k < MAX_KEYS_PER_PROV; k++) prov_conf[i].api_keys[k][0] = 0;
        prov_conf[i].num_keys = 0;
        prov_conf[i].active_key = 0;
        prov_conf[i].model[0] = 0;
        prov_conf[i].enabled = 0;
        if (providers[i].base[0]) snprintf(prov_conf[i].api_base, sizeof(prov_conf[i].api_base), "%s", providers[i].base);
        if (providers[i].model[0]) snprintf(prov_conf[i].model, sizeof(prov_conf[i].model), "%s", providers[i].model);
    }
}

/* ============ 搜索提供商配置管理 ============ */
static void load_search_provider_conf(int idx) {
    char fname[MAX_PATH];
    get_conf_file(fname, sizeof(fname), search_provider_defs[idx].id);
    FILE *f = fopen(fname, "r");
    if (!f) return;
    char line[MAX_LINE];
    while (fgets(line, sizeof(line), f)) {
        line[strcspn(line, "\r\n")] = 0;
        if (!line[0] || line[0] == '#') continue;
        if (!strncmp(line, "api_base=", 9)) snprintf(search_conf[idx].api_base, sizeof(search_conf[idx].api_base), "%s", line + 9);
        else if (!strncmp(line, "active_key=", 11)) search_conf[idx].active_key = atoi(line + 11);
        else if (!strncmp(line, "api_key_", 8)) {
            int kn = atoi(line + 8);
            const char *v = strchr(line + 8, '=');
            if (v && kn >= 0 && kn < MAX_SEARCH_KEYS) {
                v++;
                snprintf(search_conf[idx].api_keys[kn], sizeof(search_conf[idx].api_keys[0]), "%s", v);
                if (kn + 1 > search_conf[idx].num_keys) search_conf[idx].num_keys = kn + 1;
            }
        }
    }
    fclose(f);
    if (search_conf[idx].num_keys > 0 && (search_conf[idx].api_base[0] || idx != NSEARCHPROV - 1)) {
        search_conf[idx].enabled = 1;
    }
    if (idx != NSEARCHPROV - 1 && !search_conf[idx].api_base[0]) {
        snprintf(search_conf[idx].api_base, sizeof(search_conf[idx].api_base), "%s", search_provider_defs[idx].default_api_url);
    }
}

static int save_search_provider_conf(int idx) {
    char fname[MAX_PATH];
    get_conf_file(fname, sizeof(fname), search_provider_defs[idx].id);
    FILE *f = fopen(fname, "w");
    if (!f) return -1;
    fprintf(f, "# 搜索提供商配置 - %s\n", search_provider_defs[idx].name);
    fprintf(f, "api_base=%s\n", search_conf[idx].api_base);
    fprintf(f, "active_key=%d\n", search_conf[idx].active_key);
    for (int k = 0; k < search_conf[idx].num_keys; k++)
        fprintf(f, "api_key_%d=%s\n", k, search_conf[idx].api_keys[k]);
    fclose(f);
    chmod(fname, 0600);
    return 0;
}

static char *get_search_key(int idx) {
    if (idx < 0 || idx >= NSEARCHPROV || search_conf[idx].num_keys == 0) return strdup("");
    int ak = search_conf[idx].active_key;
    if (ak < 0 || ak >= search_conf[idx].num_keys) ak = 0;
    unsigned char b[MAX_KEY];
    b64dec(search_conf[idx].api_keys[ak], b, sizeof(b));
    return strdup((char*)b);
}

static int add_search_key(int idx, const char *pk) {
    if (idx < 0 || idx >= NSEARCHPROV) return -1;
    int n = search_conf[idx].num_keys;
    if (n >= MAX_SEARCH_KEYS) return -1;
    char e[MAX_KEY];
    if (b64enc((unsigned char*)pk, strlen(pk), e, sizeof(e)) < 0) return -1;
    snprintf(search_conf[idx].api_keys[n], sizeof(search_conf[idx].api_keys[0]), "%s", e);
    search_conf[idx].num_keys = n + 1;
    search_conf[idx].enabled = 1;
    return n;
}

/* ============ tool_bing_search（API优先 + 网页抓取回退） ============ */
static char *tool_bing_search(const char *q) {
    char *result = NULL;
    int idx = current_search_provider;

    /* ---- 尝试 API 调用 ---- */
    if (search_conf[idx].num_keys > 0) {
        char *key = get_search_key(idx);
        if (key && *key) {
            static char api_url[MAX_STR];
            char auth_header[512];
            const char *base_url;
            if (idx == NSEARCHPROV - 1 && search_conf[idx].api_base[0]) {
                base_url = search_conf[idx].api_base;
            } else if (search_conf[idx].api_base[0]) {
                base_url = search_conf[idx].api_base;
            } else {
                base_url = search_provider_defs[idx].default_api_url;
            }
            char qe[4096]; urlencode(q, qe, sizeof(qe));
            snprintf(api_url, sizeof(api_url), "%s?q=%s", base_url, qe);
            
            const char *tmpl = search_provider_defs[idx].auth_header_template;
            snprintf(auth_header, sizeof(auth_header), tmpl, key);
            
            char *args[64];
            int n = 0;
            args[n++] = "-s"; args[n++] = "-S";
            if (CA_BUNDLE[0]) {
                args[n++] = "--cacert"; args[n++] = (char*)CA_BUNDLE;
            } else {
                args[n++] = "-k";
            }
            args[n++] = "-H"; args[n++] = auth_header;
            args[n++] = (char*)api_url; args[n++] = NULL;
            
            char *resp = NULL;
            long len = exec_curl(args, &resp);
            if (len >= 0 && resp && *resp) {
                char *items = NULL;
                if (idx == 0) {
                    items = jq_query(".organic[] | \"\\(.title)|\\(.link)|\\(.snippet)\"", resp);
                } else if (idx == 1) {
                    items = jq_query(".results[] | \"\\(.title)|\\(.url)|\\(.content)\"", resp);
                } else if (idx == 2) {
                    items = jq_query(".webPages.value[] | \"\\(.name)|\\(.url)|\\(.snippet)\"", resp);
                } else {
                    items = jq_query(".[]? | \"\\(.title)|\\(.link)|\\(.snippet)\"", resp);
                }
                if (items && *items) {
                    size_t bl = 0, cap = 8192;
                    char *buf = malloc(cap);
                    if (buf) {
                        int cnt = 0;
                        char *line = strtok(items, "\n");
                        while (line && cnt < 6) {
                            char *title = line;
                            char *link = strchr(line, '|');
                            char *snippet = NULL;
                            if (link) { *link = '\0'; link++; snippet = strchr(link, '|'); if (snippet) { *snippet = '\0'; snippet++; } }
                            int used = snprintf(buf + bl, cap - bl,
                                "%d. %s%s%s%s%s\n", cnt + 1,
                                title && *title ? title : "(无标题)",
                                link && *link ? "\n   链接: " : "", link && *link ? link : "",
                                snippet && *snippet ? "\n   摘要: " : "", snippet && *snippet ? snippet : "");
                            if (used > 0 && (size_t)used < cap - bl) bl += used;
                            cnt++;
                            line = strtok(NULL, "\n");
                        }
                        if (bl > 0) {
                            char *out = realloc(buf, bl + 1);
                            if (out) { out[bl] = 0; result = out; }
                            else free(buf);
                        } else free(buf);
                    }
                    free(items);
                }
                free(resp);
                if (result) {
                    free(key);
                    return result;
                }
            }
            free(resp);
        }
        free(key);
    }

    /* ---- API 失败或无 Key，回退到网页抓取 ---- */
    static const char *uas[200] = {
        /* Windows Chrome */
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
        /* Windows Edge */
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36 Edg/125.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36 Edg/129.0.0.0",
        /* Windows Firefox */
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:124.0) Gecko/20100101 Firefox/124.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:129.0) Gecko/20100101 Firefox/129.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:130.0) Gecko/20100101 Firefox/130.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:131.0) Gecko/20100101 Firefox/131.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0",
        /* macOS Safari */
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Safari/605.1.15",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.2 Safari/605.1.15",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.3 Safari/605.1.15",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/19.0 Safari/605.1.15",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/19.1 Safari/605.1.15",
        /* macOS Chrome */
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
        /* macOS Firefox */
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:123.0) Gecko/20100101 Firefox/123.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:124.0) Gecko/20100101 Firefox/124.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:125.0) Gecko/20100101 Firefox/125.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:126.0) Gecko/20100101 Firefox/126.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:127.0) Gecko/20100101 Firefox/127.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:128.0) Gecko/20100101 Firefox/128.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:129.0) Gecko/20100101 Firefox/129.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:130.0) Gecko/20100101 Firefox/130.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:131.0) Gecko/20100101 Firefox/131.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:132.0) Gecko/20100101 Firefox/132.0",
        /* Linux Firefox */
        "Mozilla/5.0 (X11; Linux x86_64; rv:123.0) Gecko/20100101 Firefox/123.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:124.0) Gecko/20100101 Firefox/124.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:125.0) Gecko/20100101 Firefox/125.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:126.0) Gecko/20100101 Firefox/126.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:127.0) Gecko/20100101 Firefox/127.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:129.0) Gecko/20100101 Firefox/129.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:130.0) Gecko/20100101 Firefox/130.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:131.0) Gecko/20100101 Firefox/131.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:132.0) Gecko/20100101 Firefox/132.0",
        /* Linux Chrome */
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36",
        /* Android Chrome */
        "Mozilla/5.0 (Linux; Android 13; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 13; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 13; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 13; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6167.164 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6167.164 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6167.164 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.6167.164 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 13; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 13; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6099.230 Mobile Safari/537.36",
        /* Android Firefox */
        "Mozilla/5.0 (Android 13; Mobile; rv:123.0) Gecko/123.0 Firefox/123.0",
        "Mozilla/5.0 (Android 13; Mobile; rv:124.0) Gecko/124.0 Firefox/124.0",
        "Mozilla/5.0 (Android 13; Mobile; rv:125.0) Gecko/125.0 Firefox/125.0",
        "Mozilla/5.0 (Android 14; Mobile; rv:123.0) Gecko/123.0 Firefox/123.0",
        "Mozilla/5.0 (Android 14; Mobile; rv:124.0) Gecko/124.0 Firefox/124.0",
        "Mozilla/5.0 (Android 14; Mobile; rv:125.0) Gecko/125.0 Firefox/125.0",
        "Mozilla/5.0 (Android 13; Mobile; rv:126.0) Gecko/126.0 Firefox/126.0",
        "Mozilla/5.0 (Android 13; Mobile; rv:127.0) Gecko/127.0 Firefox/127.0",
        "Mozilla/5.0 (Android 13; Mobile; rv:128.0) Gecko/128.0 Firefox/128.0",
        "Mozilla/5.0 (Android 13; Mobile; rv:129.0) Gecko/129.0 Firefox/129.0",
        /* Android Samsung Internet */
        "Mozilla/5.0 (Linux; Android 13; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/120.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 13; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/24.0 Chrome/121.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 13; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/25.0 Chrome/122.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/120.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/24.0 Chrome/121.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/25.0 Chrome/122.0.6099.230 Mobile Safari/537.36",
        /* Android Opera */
        "Mozilla/5.0 (Linux; Android 13; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.230 Safari/537.36 OPR/76.2.4027.73374",
        "Mozilla/5.0 (Linux; Android 13; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6099.230 Safari/537.36 OPR/77.0.4027.73374",
        "Mozilla/5.0 (Linux; Android 13; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6099.230 Safari/537.36 OPR/78.0.4027.73374",
        "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6167.164 Safari/537.36 OPR/76.2.4027.73374",
        "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6167.164 Safari/537.36 OPR/77.0.4027.73374",
        /* iOS Safari */
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 18_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.2 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (iPad; CPU OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (iPad; CPU OS 17_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (iPad; CPU OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1",
        /* iOS Chrome */
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/120.0.6099.119 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/121.0.6167.164 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/122.0.6167.164 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/123.0.6167.164 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (iPad; CPU OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/120.0.6099.119 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (iPad; CPU OS 17_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/121.0.6167.164 Mobile/15E148 Safari/604.1",
        /* Windows 其他 */
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 OPR/106.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 OPR/107.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 OPR/108.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 QQBrowser/13.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 QQBrowser/14.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 QQBrowser/15.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 UCBrowser/13.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 UCBrowser/14.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 UCBrowser/15.0.0.0",
        /* 更多移动设备 */
        "Mozilla/5.0 (Linux; Android 13; V2219A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 13; V2219A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 14; 2211133C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 14; 2211133C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 13; M2102J20SG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 13; M2102J20SG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 14; CPH2449) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 14; CPH2449) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 13; Pixel 6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 13; Pixel 6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6099.230 Mobile Safari/537.36",
        /* 桌面更多 */
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Vivaldi/6.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Vivaldi/6.1.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Brave/1.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Brave/1.1.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Opera GX/106.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Opera GX/107.0.0.0",
        /* macOS 其他版本 */
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        /* Windows 旧版本 */
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:124.0) Gecko/20100101 Firefox/124.0",
        /* Android 平板 */
        "Mozilla/5.0 (Linux; Android 13; SM-T970) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.230 Safari/537.36",
        "Mozilla/5.0 (Linux; Android 13; SM-T970) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6099.230 Safari/537.36",
        "Mozilla/5.0 (Linux; Android 14; SM-X800) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.230 Safari/537.36",
        "Mozilla/5.0 (Linux; Android 14; SM-X800) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6099.230 Safari/537.36",
        /* iOS 其他版本 */
        "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 16_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.7 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 15_8 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.8 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 15_9 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.9 Mobile/15E148 Safari/604.1",
        /* Linux 其他 */
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        /* Yandex */
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Yandex/23.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Yandex/24.0.0.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Yandex/23.0.0.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Yandex/24.0.0.0",
        /* 补充更多 */
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Linux; Android 13; SM-G990B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 13; SM-G990B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 14; SM-S911B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 14; SM-S911B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6099.230 Mobile Safari/537.36",
        /* 通用移动端 */
        "Mozilla/5.0 (Linux; Android 12; SM-A525F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 12; SM-A525F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 13; Redmi Note 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 13; Redmi Note 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 14; OnePlus 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.230 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 14; OnePlus 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6099.230 Mobile Safari/537.36"
    };

    static const char *cookies[20] = {
        "SRCHHPGUSR=SRCHLANG=zh-Hans&SRCHD=AF=NOFORM&SRCHUID=V=2&GUID=&dmemc=1; _EDGE_S=mkt=zh-cn",
        "SRCHHPGUSR=SRCHLANG=en&SRCHD=AF=NOFORM&SRCHUID=V=3&GUID=&dmemc=0; _EDGE_S=mkt=en-us",
        "SRCHHPGUSR=SRCHLANG=ja&SRCHD=AF=NOFORM&SRCHUID=V=4&GUID=&dmemc=1; _EDGE_S=mkt=ja-jp",
        "SRCHHPGUSR=SRCHLANG=ko&SRCHD=AF=NOFORM&SRCHUID=V=5&GUID=&dmemc=0; _EDGE_S=mkt=ko-kr",
        "SRCHHPGUSR=SRCHLANG=zh-Hans&SRCHD=AF=NOFORM&SRCHUID=V=6&GUID=&dmemc=1; _EDGE_S=mkt=zh-cn",
        "SRCHHPGUSR=SRCHLANG=en&SRCHD=AF=NOFORM&SRCHUID=V=7&GUID=&dmemc=0; _EDGE_S=mkt=en-us",
        "SRCHHPGUSR=SRCHLANG=zh-Hant&SRCHD=AF=NOFORM&SRCHUID=V=8&GUID=&dmemc=1; _EDGE_S=mkt=zh-tw",
        "SRCHHPGUSR=SRCHLANG=fr&SRCHD=AF=NOFORM&SRCHUID=V=9&GUID=&dmemc=0; _EDGE_S=mkt=fr-fr",
        "SRCHHPGUSR=SRCHLANG=de&SRCHD=AF=NOFORM&SRCHUID=V=10&GUID=&dmemc=1; _EDGE_S=mkt=de-de",
        "SRCHHPGUSR=SRCHLANG=es&SRCHD=AF=NOFORM&SRCHUID=V=11&GUID=&dmemc=0; _EDGE_S=mkt=es-es",
        "SRCHHPGUSR=SRCHLANG=it&SRCHD=AF=NOFORM&SRCHUID=V=12&GUID=&dmemc=1; _EDGE_S=mkt=it-it",
        "SRCHHPGUSR=SRCHLANG=pt&SRCHD=AF=NOFORM&SRCHUID=V=13&GUID=&dmemc=0; _EDGE_S=mkt=pt-br",
        "SRCHHPGUSR=SRCHLANG=ru&SRCHD=AF=NOFORM&SRCHUID=V=14&GUID=&dmemc=1; _EDGE_S=mkt=ru-ru",
        "SRCHHPGUSR=SRCHLANG=ar&SRCHD=AF=NOFORM&SRCHUID=V=15&GUID=&dmemc=0; _EDGE_S=mkt=ar-sa",
        "SRCHHPGUSR=SRCHLANG=hi&SRCHD=AF=NOFORM&SRCHUID=V=16&GUID=&dmemc=1; _EDGE_S=mkt=hi-in",
        "SRCHHPGUSR=SRCHLANG=zh-Hans&SRCHD=AF=NOFORM&SRCHUID=V=17&GUID=&dmemc=0; _EDGE_S=mkt=zh-cn",
        "SRCHHPGUSR=SRCHLANG=en&SRCHD=AF=NOFORM&SRCHUID=V=18&GUID=&dmemc=1; _EDGE_S=mkt=en-gb",
        "SRCHHPGUSR=SRCHLANG=zh-Hans&SRCHD=AF=NOFORM&SRCHUID=V=19&GUID=&dmemc=0; _EDGE_S=mkt=zh-cn",
        "SRCHHPGUSR=SRCHLANG=en&SRCHD=AF=NOFORM&SRCHUID=V=20&GUID=&dmemc=1; _EDGE_S=mkt=en-us",
        "SRCHHPGUSR=SRCHLANG=zh-Hans&SRCHD=AF=NOFORM&SRCHUID=V=21&GUID=&dmemc=0; _EDGE_S=mkt=zh-cn"
    };

    int idx_ua = rand() % 200;
    int idx_cookie = rand() % 20;
    const char *ua = uas[idx_ua];
    const char *cookie = cookies[idx_cookie];

    static char url_buf[MAX_BIG + 64];
    { char qe[MAX_BIG]; urlencode(q, qe, sizeof(qe)); snprintf(url_buf, sizeof(url_buf),
        "https://cn.bing.com/search?setlang=zh-CN&q=%s", qe); }

    char *ard[64];
    int n = 0;
    ard[n++] = "-s"; ard[n++] = "-L"; ard[n++] = "-m"; ard[n++] = "15";
    if (CA_BUNDLE[0]) {
        ard[n++] = "--cacert"; ard[n++] = (char*)CA_BUNDLE;
    } else {
        ard[n++] = "-k";
    }
    ard[n++] = "-A"; ard[n++] = (char*)ua;
    ard[n++] = "-H"; ard[n++] = "Accept-Language: zh-CN,zh;q=0.9,en;q=0.8";
    ard[n++] = "-H"; ard[n++] = "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8";
    ard[n++] = "--cookie"; ard[n++] = (char*)cookie;
    ard[n++] = (char*)url_buf; ard[n++] = NULL;

    char *html = NULL;
    if (exec_curl(ard, &html) < 0 || !html) { if (html) free(html); return strdup("(搜索失败: 无法访问必应搜索)"); }
    size_t hl = strlen(html);
    char *buf = malloc(hl + 4096); if (!buf) { free(html); return strdup("(内存不足)"); }
    size_t bl = 0; int cnt = 0;
    const char *p = html;
    while (cnt < 6) {
        const char *li = strstr(p, "<li class=\"b_algo\"");
        if (!li) break;
        const char *lie = strstr(li, "</li>");
        if (!lie) break;
        const char *h2 = strstr(li, "<h2");
        static char url_out[MAX_PATH] = "", title_out[MAX_STR] = "";
        if (h2 && h2 < lie) {
            const char *href = strstr(h2, "href=\"");
            if (href && href < lie) { href += 6; const char *he = strchr(href, '"'); if (he && he < lie) { size_t u = he - href; if (u > MAX_PATH-1) u = MAX_PATH-1; memcpy(url_out, href, u); url_out[u] = 0; } }
            const char *aclose = strstr(h2, "</a>");
            if (aclose && aclose < lie) { const char *nh2 = strchr(h2, '>'); if (nh2) { const char *t0 = nh2 + 1; if (t0 < aclose) { size_t t = aclose - t0; if (t > MAX_STR-1) t = MAX_STR-1; char *tmp = malloc(t + 1); if (tmp) { memcpy(tmp, t0, t); tmp[t] = 0; strip_tags(tmp); html_decode(tmp); strip_tags(tmp); snprintf(title_out, sizeof(title_out), "%s", tmp); free(tmp); } } } }
        }
        static char snip[MAX_STR] = "";
        const char *cap = strstr(li, "b_caption");
        if (cap && cap < lie) {
            const char *sp = strstr(cap, "<p");
            if (sp && sp < lie) { const char *sclose = strstr(sp, "</p>"); if (sclose && sclose < lie + 6000) { const char *gt = strchr(sp, '>'); if (gt && gt < sclose) { size_t t = sclose - gt - 1; if (t > MAX_STR-1) t = MAX_STR-1; char *tmp = malloc(t + 1); if (tmp) { memcpy(tmp, gt + 1, t); tmp[t] = 0; strip_tags(tmp); html_decode(tmp); strip_tags(tmp); snprintf(snip, sizeof(snip), "%s", tmp); free(tmp); } } } }
        }
        int used = snprintf(buf + bl, hl + 4096 - bl,
                   "%d. %s%s%s%s%s\n", cnt + 1, title_out[0] ? title_out : "(无标题)",
                   url_out[0] ? "\n   链接: " : "", url_out,
                   snip[0] ? "\n   摘要: " : "", snip);
        if (used > 0 && (size_t)used < hl + 4096 - bl) bl += (size_t)used;
        cnt++;
        p = lie + 5;
    }
    free(html);
    if (!bl) { free(buf); return strdup("(搜索无结果, 或页面被拦截)"); }
    char *out = realloc(buf, bl + 1); if (!out) { free(buf); return strdup("(合并失败)"); }
    out[bl] = 0;
    return out;
}

/* ============ 其他工具函数 ============ */
static char *tool_curl_download(const char *url, const char *path) {
    char *argv[64];
    int n = 0;
    argv[n++] = "-s"; argv[n++] = "-L";
    if (CA_BUNDLE[0]) {
        argv[n++] = "--cacert"; argv[n++] = (char*)CA_BUNDLE;
    } else {
        argv[n++] = "-k";
    }
    argv[n++] = "--connect-timeout"; argv[n++] = "15";
    argv[n++] = "-m"; argv[n++] = "60";
    argv[n++] = "-o"; argv[n++] = (char*)path;
    argv[n++] = (char*)url; argv[n++] = NULL;

    char *out = NULL;
    long nbytes = exec_curl(argv, &out);
    if (nbytes < 0 || !out) { if (out) free(out); return strdup("(下载失败: 无法访问该地址)"); }
    free(out);
    char szcmd[MAX_PATH]; snprintf(szcmd, sizeof(szcmd), "wc -c < '%s' 2>/dev/null", path);
    char *argv2[] = {"sh","-c",szcmd,NULL};
    char *sz = NULL;
    if (exec_busybox(argv2, &sz) < 0 || !sz) { if (sz) free(sz); return strdup("(下载完成但无法读取大小)"); }
    size_t l = strlen(sz); while (l && (sz[l-1] < ' ')) sz[--l] = 0;
    char *r = malloc(strlen(path) + 64); if (!r) { free(sz); return strdup("(内存)"); }
    snprintf(r, strlen(path) + 64, "(已下载到 %s, 大小 %s 字节)", path, sz[0] ? sz : "?");
    free(sz);
    return r;
}

static char *run_tool(const char *name, const char *args_json) {
    char *res = NULL;
    if (!strcmp(name, "bing_search")) {
        char q[MAX_BIG] = {0};
        extract_json_val(args_json, "\"query\":", q, sizeof(q));
        if (!q[0]) extract_json_val(args_json, "\"q\":", q, sizeof(q));
        if (!q[0]) strncpy(q, "(空查询)", sizeof(q) - 1);
        res = tool_bing_search(q);
    } else if (!strcmp(name, "run_shell")) {
        char cmd[MAX_BIG] = {0};
        extract_json_val(args_json, "\"cmd\":", cmd, sizeof(cmd));
        if (!cmd[0]) return strdup("(run_shell 缺少 cmd 参数)");
        long ms = 15000, cap = 6000;
        char tv[64];
        if (extract_json_val(args_json, "\"timeout\":", tv, sizeof(tv))) ms = strtol(tv, NULL, 10);
        char cv[64];
        if (extract_json_val(args_json, "\"timeout\":", cv, sizeof(cv))) cap = strtol(cv, NULL, 10);
        res = run_shell_timed(cmd, ms, cap);
        if (!res) res = strdup("(命令执行失败)");
    } else if (!strcmp(name, "curl_download")) {
        char url[MAX_PATH] = {0}, path[MAX_PATH] = {0};
        extract_json_val(args_json, "\"url\":", url, sizeof(url));
        extract_json_val(args_json, "\"path\":", path, sizeof(path));
        if (!url[0]) return strdup("(curl_download 缺少 url)");
        if (!path[0]) snprintf(path, sizeof(path), "%s/download.bin", "/data/local/tmp/ai_work");
        res = tool_curl_download(url, path);
    } else if (!strcmp(name, "time_now")) {
        res = tool_time_now();
    } else {
        char tmp[128]; snprintf(tmp, sizeof(tmp), "(未知工具: %s)", name);
        res = strdup(tmp);
    }
    return res;
}

/* ============ 工具调用解析 ============ */
#define MAX_TOOL_RESULT 1200

static char *build_tools_usage_text(void) {
    return strdup(
        "⚠️ 重要规则：你可以通过特定格式请求系统执行工具，但请严格遵守以下约定。\n"
        "\n"
        "【工具调用格式（仅当真正需要调用时才输出）】\n"
        "如果你确实需要获取实时信息或执行系统操作，请严格按照以下格式输出，不要附加任何其他内容：\n"
        "\n"
        "[[TOOL]]\n"
        "{\"name\":\"工具名\",\"args\":{...}}\n"
        "[[/TOOL]]\n"
        "\n"
        "工具列表：\n"
        "- bing_search   → 联网搜索，args: {\"query\":\"搜索词\"}\n"
        "- run_shell     → 执行shell命令，args: {\"cmd\":\"命令\",\"timeout\":毫秒（可选）}\n"
        "- curl_download → 下载文件，args: {\"url\":\"地址\",\"path\":\"保存路径（可选）\"}\n"
        "- time_now      → 获取当前时间，args: {}（空对象）\n"
        "\n"
        "【执行流程】\n"
        "1. 你输出工具调用标记 → 这一轮回答立即结束，不再输出任何其他文字。\n"
        "2. 系统执行工具，并将结果以用户消息发回给你。\n"
        "3. 你收到结果后，基于结果组织最终回答。\n"
        "\n"
        "【硬性约束】\n"
        "- 一次只能调用一个工具。\n"
        "- 得到结果后，除非用户明确要求，不要重复调用同一个工具。\n"
        "- 不要自己模拟工具结果。\n"
        "\n"
        "【关于举例说明】\n"
        "当你需要向用户解释调用格式，但**并不真正调用工具**时，请用普通文字说明，例如：\n"
        "\"调用格式是：双中括号 + TOOL + 换行 + JSON + 换行 + 双中括号 + /TOOL\"\n"
        "绝对不要输出实际的 [[TOOL]] 标记，否则系统会误认为你要执行工具，导致出错。\n"
        "\n"
        "简单来说：\n"
        "- 真正调用 → 输出 [[TOOL]] ... [[/TOOL]]\n"
        "- 举例说明 → 用自然语言描述，不要输出 [[TOOL]] 标记 也不要输出具体的json内容\n"
    );
}

static char *tool_result_trim(const char *name, const char *args, const char *r) {
    if (!r) return NULL;
    size_t l = strlen(r);
    if (l <= MAX_TOOL_RESULT) return strdup(r);
    int repeat = g_cut_name[0] && name && !strcmp(name, g_cut_name)
                 && (!g_cut_args[0] || (args && !strcmp(args, g_cut_args)));
    if (repeat) {
        g_cut_name[0] = 0; g_cut_args[0] = 0;
        return strdup(r);
    }
    if (name) snprintf(g_cut_name, sizeof(g_cut_name), "%s", name);
    if (args) snprintf(g_cut_args, sizeof(g_cut_args), "%s", args);
    char *out = malloc(MAX_TOOL_RESULT + 200);
    if (!out) return NULL;
    memcpy(out, r, MAX_TOOL_RESULT);
    snprintf(out + MAX_TOOL_RESULT, 200, "\n...(结果已截断 %zu 字节; 再次调用获取完整内容)", l);
    return out;
}

static int has_tool_marker(const char *c) {
    static const char *mk[] = {"[[TOOL]]","[[tool]]","[[Tool]]","[TOOL]","[tool]","(TOOL)","<<TOOL>>",0};
    if (!c) return 0;
    for (int i = 0; mk[i]; i++) if (strstr(c, mk[i])) return 1;
    if (strstr(c,"run_shell")||strstr(c,"bing_search")||strstr(c,"curl_download")||strstr(c,"\"name\":\"time_now\""))
        if (strstr(c,"\"name\":") && strstr(c,"\"args\":")) return 1;
    return 0;
}

static char *find_tool_call(const char *content) {
    const char *op = NULL;
    if (content) {
        static const char *mk[] = {"[[TOOL]]","[[tool]]","[[Tool]]","[TOOL]","[tool]","(TOOL)","<<TOOL>>",0};
        const char *best = NULL;
        for (int i = 0; mk[i]; i++) { const char *h = strstr(content, mk[i]); if (h && (!best || h < best)) best = h; }
        op = best;
    }
    const char *open_brace;
    if (op) {
        open_brace = strchr(op, '{');
    } else {
        if (!has_tool_marker(content)) return NULL;
        open_brace = strchr(content, '{');
    }
    if (!open_brace) return NULL;
    const char *cl = open_brace;
    int depth = 0;
    while (*cl) { if (*cl == '{') depth++; else if (*cl == '}') { depth--; if (depth == 0) { cl++; break; } } cl++; }
    if (depth != 0) return NULL;
    size_t L = (size_t)(cl - open_brace);
    if (L < 4 || L > 4000) return NULL;
    char *t = malloc(L + 1); if (!t) return NULL;
    memcpy(t, open_brace, L); t[L] = 0;
    if (!op) {
        char nm[MAX_STR];
        if (!extract_json_val(t, "\"name\":", nm, sizeof(nm)) || !nm[0]) { free(t); return NULL; }
    }
    return t;
}

/* ===== UTF-8 清理函数 ===== */
static char *sanitize_utf8(const char *in) {
    if (!in) return strdup("");
    size_t len = 0, cap = 256;
    char *out = malloc(cap);
    if (!out) return strdup("");
    const unsigned char *p = (const unsigned char*)in;
    while (*p) {
        unsigned char c = *p;
        size_t need = 0;
        if (c < 0x80) {
            need = 1;
        } else if (c >= 0xC2 && c < 0xE0) {
            need = 2;
        } else if (c >= 0xE0 && c < 0xF0) {
            need = 3;
        } else if (c >= 0xF0 && c < 0xF5) {
            need = 4;
        } else {
            if (len + 4 >= cap) { cap *= 2; char *nb = realloc(out, cap); if (!nb) { free(out); return strdup(""); } out = nb; }
            out[len++] = 0xEF;
            out[len++] = 0xBF;
            out[len++] = 0xBD;
            p++;
            continue;
        }
        int valid = 1;
        for (size_t i = 1; i < need; i++) {
            if (!(p[i] >= 0x80 && p[i] < 0xC0)) { valid = 0; break; }
        }
        if (!valid) {
            if (len + 4 >= cap) { cap *= 2; char *nb = realloc(out, cap); if (!nb) { free(out); return strdup(""); } out = nb; }
            out[len++] = 0xEF;
            out[len++] = 0xBF;
            out[len++] = 0xBD;
            p++;
            continue;
        }
        if (len + need >= cap) { cap *= 2; char *nb = realloc(out, cap); if (!nb) { free(out); return strdup(""); } out = nb; }
        for (size_t i = 0; i < need; i++) out[len++] = *p++;
    }
    out[len] = 0;
    return out;
}

static char *execute_tool_call(const char *tool_json) {
    if (!TOOLS_ENABLED) return strdup("(工具已被 /tools off 禁用)");
    char name[MAX_STR] = {0};
    extract_json_val(tool_json, "\"name\":", name, sizeof(name));
    if (!name[0]) return strdup("(工具解析失败: 无 name 字段)");
    char *args_json = NULL;
    const char *args = strstr(tool_json, "\"args\"");
    if (args) { const char *ab = strchr(args, '{'); if (ab) { const char *ae = ab; int d = 0;
        while (*ae) { if (*ae == '{') d++; else if (*ae == '}') { d--; if (d == 0) { ae++; break; } } ae++; }
        if (d == 0 && ae > ab) { args_json = malloc((size_t)(ae - ab) + 1); if (args_json) { memcpy(args_json, ab, (size_t)(ae - ab)); args_json[ae - ab] = 0; } }
    } }
    char *raw = run_tool(name, args_json ? args_json : "{}");
    char *clean_raw = raw ? sanitize_utf8(raw) : strdup("(工具执行返回空)");
    free(raw);
    char *r = tool_result_trim(name, args_json ? args_json : "", clean_raw);
    free(clean_raw);
    free(args_json);
    return r;
}

/* ============ jq 查询 ============ */
static char *jq_query(const char *filter, const char *json) {
    char *args[8]; int n = 0;
    args[n++] = "-r"; args[n++] = (char*)filter; args[n++] = NULL;
    char *out = NULL;
    long rc = exec_jq_stdin(args, json, &out);
    if (rc < 0) { free(out); return NULL; }
    if (out && *out) { char *p = out + strlen(out); while (p > out && (p[-1]=='\n'||p[-1]=='\r')) *--p = 0; }
    return out;
}

/* ============ HTTP 请求（支持 CA） ============ */
static int http_post_json(const char *url, const char *auth, const char *body, char **out) {
    char *args[64]; int n = 0;
    args[n++] = "-s"; args[n++] = "-S";
    if (CA_BUNDLE[0]) {
        args[n++] = "--cacert"; args[n++] = (char*)CA_BUNDLE;
    } else {
        args[n++] = "-k";
    }
    args[n++] = "--dns-servers"; args[n++] = "223.5.5.5,119.29.29.29,114.114.114.114,8.8.8.8,1.1.1.1";
    args[n++] = "--max-time"; args[n++] = "300";
    args[n++] = "-X"; args[n++] = "POST";
    args[n++] = "-H"; { static char h1[700]; snprintf(h1,sizeof(h1),"Content-Type: application/json"); args[n++] = h1; }
    args[n++] = "-H"; { static char h2[700]; snprintf(h2,sizeof(h2),"Authorization: Bearer %s", auth); args[n++] = h2; }
    args[n++] = "--data"; args[n++] = (char*)body;
    args[n++] = (char*)url; args[n++] = NULL;
    char *resp = NULL;
    long len = exec_curl(args, &resp);
    if (len < 0) { *out = NULL; return -1; }
    *out = resp;
    const char *trim = resp;
    while (*trim == ' ' || *trim == '\t' || *trim == '\n' || *trim == '\r') trim++;
    if (*trim != '{' && *trim != '[') {
        fprintf(stderr, "\n[DEBUG] HTTP POST 返回非 JSON 响应，开头 200 字符如下：\n%.200s\n\n", resp);
    }
    return 0;
}

static int http_get_json(const char *url, const char *auth, char **out) {
    char *args[64]; int n = 0;
    args[n++] = "-s"; args[n++] = "-S";
    if (CA_BUNDLE[0]) {
        args[n++] = "--cacert"; args[n++] = (char*)CA_BUNDLE;
    } else {
        args[n++] = "-k";
    }
    args[n++] = "--dns-servers"; args[n++] = "223.5.5.5,119.29.29.29,114.114.114.114,8.8.8.8,1.1.1.1";
    args[n++] = "--max-time"; args[n++] = "60";
    args[n++] = "-H"; { static char h2[700]; snprintf(h2,sizeof(h2),"Authorization: Bearer %s", auth); args[n++] = h2; }
    args[n++] = (char*)url; args[n++] = NULL;
    char *resp = NULL;
    long len = exec_curl(args, &resp);
    if (len < 0) { *out = NULL; return -1; }
    *out = resp; return 0;
}

/* ============ 模型选择 ============ */
static int pick_model_for(const char *auth, const char *api_base, char *model_out, size_t model_out_sz) {
    if (!auth || !*auth) { printf("%s[!] 无 Key, 无法拉取模型列表%s\n", YL, RS); return -1; }
    char url[MAX_PATH];
    size_t bl = strlen(api_base);
    if (bl && api_base[bl-1] == '/') snprintf(url, sizeof(url), "%smodels", api_base);
    else snprintf(url, sizeof(url), "%s/models", api_base);

    char *resp = NULL;
    printf("%s[拉取模型列表…]%s ", CY, RS); fflush(stdout);
    if (http_get_json(url, auth, &resp) != 0 || !resp) {
        printf("\n%s[!] 拉取模型失败%s\n", YL, RS); free(resp); return -1;
    }
    printf("\n");
    char *err = jq_query(".error.message", resp);
    if (err && *err && strcmp(err, "null")) {
        printf("%s[!] API错误: %s%s\n", YL, err, RS); free(err); free(resp); return -1;
    }
    free(err);
    char *list = jq_query(".data[].id", resp);
    if (!list || !*list) {
        printf("%s[!] 未解析到模型%s\n", YL, RS); free(list); free(resp); return -1;
    }
    size_t cap = 32, cnt = 0;
    char **id = malloc(cap * sizeof(char*)); if (!id) { free(list); free(resp); return -1; }
    char *tok = strtok(list, "\n");
    while (tok && cnt < 64) {
        if (cnt + 1 >= cap) { cap *= 2; char **ni = realloc(id, cap * sizeof(char*)); if (!ni) break; id = ni; }
        id[cnt++] = strdup(tok);
        tok = strtok(NULL, "\n");
    }
    if (cnt == 0) { printf("%s[!] 模型列表为空%s\n", YL, RS); free(list); free(resp); free(id); return -1; }
    printf("%s请选择模型 (共%d个):%s\n", CY, (int)cnt, RS);
    int show = cnt < 40 ? (int)cnt : 40;
    for (int i = 0; i < show; i++) printf("  %s%d%s  %s\n", MG, i + 1, RS, id[i]);
    if (cnt > show) printf("  ... 目前显示前 %d 个\n", show);
    printf("输入数字 [1-%d] (0=跳过)> ", (int)cnt); fflush(stdout);
    char *in = read_line();
    if (in && *in) {
        int sel = atoi(in) - 1;
        if (sel >= 0 && sel < (int)cnt) {
            snprintf(model_out, model_out_sz, "%s", id[sel]);
            printf("%s已选择模型: %s%s\n", GC, model_out, RS);
        } else if (sel == -1) {
            printf("%s[跳过]%s\n", YL, RS);
        } else {
            printf("%s[!] 输入无效%s\n", YL, RS);
        }
    } else {
        printf("%s[跳过]%s\n", YL, RS);
    }
    free(in);
    for (int i = 0; i < (int)cnt; i++) free(id[i]);
    free(id); free(list); free(resp);
    return 0;
}

/* ============ JSON 工具 ============ */
static void json_unescape(const char *in, char *out, size_t outsz) {
    size_t o = 0;
    for (; *in && o + 1 < outsz; in++) {
        if (*in == '\\') {
            in++;
            switch (*in) {
                case 'n': out[o++] = '\n'; break;
                case 'r': out[o++] = '\r'; break;
                case 't': out[o++] = '\t'; break;
                case 'b': out[o++] = '\b'; break;
                case 'f': out[o++] = '\f'; break;
                case '\\': out[o++] = '\\'; break;
                case '"': out[o++] = '"'; break;
                case '/': out[o++] = '/'; break;
                case 'u': {
                    unsigned v = 0; int k;
                    for (k = 1; k <= 4 && in[k]; k++) {
                        char c = in[k]; unsigned d = 0;
                        if (c >= '0' && c <= '9') d = c - '0';
                        else if (c >= 'a' && c <= 'f') d = c - 'a' + 10;
                        else if (c >= 'A' && c <= 'F') d = c - 'A' + 10;
                        else break;
                        v = (v << 4) | d;
                    }
                    if (k > 4) {
                        if (v < 0x80) out[o++] = (char)v;
                        else if (v < 0x800) { out[o++] = (char)(0xC0|(v>>6)); out[o++] = (char)(0x80|(v&0x3F)); }
                        else { out[o++] = (char)(0xE0|(v>>12)); out[o++] = (char)(0x80|((v>>6)&0x3F)); out[o++] = (char)(0x80|(v&0x3F)); }
                        in += 3;
                    }
                    break;
                }
                default: out[o++] = '\\'; break;
            }
        } else {
            out[o++] = *in;
        }
    }
    out[o] = 0;
}

/* ============ 终端格式化（美化输出） ============ */

/* 行内 Markdown 转换：**粗体** *斜体* `代码` ~~删除线~~ */
static char *inline_markdown(const char *line, char *out, size_t outsz) {
    size_t o = 0;
    const char *p = line;
    while (*p && o + 20 < outsz) {
        if (p[0] == '*' && p[1] == '*' && p[2] && strstr(p+2, "**")) {
            const char *end = strstr(p+2, "**");
            size_t len = end - (p+2);
            if (len > 0 && o + 8 + len + 4 < outsz) {
                out[o++] = '\033'; out[o++] = '['; out[o++] = '1'; out[o++] = 'm';
                memcpy(out + o, p+2, len); o += len;
                out[o++] = '\033'; out[o++] = '['; out[o++] = '0'; out[o++] = 'm';
                p = end + 2;
                continue;
            }
        }
        else if (p[0] == '*' && p[1] && strstr(p+1, "*") && !(p[0]=='*' && p[1]=='*')) {
            const char *end = strstr(p+1, "*");
            size_t len = end - (p+1);
            if (len > 0 && o + 8 + len + 4 < outsz) {
                out[o++] = '\033'; out[o++] = '['; out[o++] = '3'; out[o++] = 'm';
                memcpy(out + o, p+1, len); o += len;
                out[o++] = '\033'; out[o++] = '['; out[o++] = '0'; out[o++] = 'm';
                p = end + 1;
                continue;
            }
        }
        else if (p[0] == '`' && strchr(p+1, '`')) {
            const char *end = strchr(p+1, '`');
            size_t len = end - (p+1);
            if (len > 0 && o + 8 + len + 4 < outsz) {
                out[o++] = '\033'; out[o++] = '['; out[o++] = '3'; out[o++] = '2'; out[o++] = 'm';
                memcpy(out + o, p+1, len); o += len;
                out[o++] = '\033'; out[o++] = '['; out[o++] = '0'; out[o++] = 'm';
                p = end + 1;
                continue;
            }
        }
        else if (p[0] == '~' && p[1] == '~' && strstr(p+2, "~~")) {
            const char *end = strstr(p+2, "~~");
            size_t len = end - (p+2);
            if (len > 0 && o + 8 + len + 4 < outsz) {
                out[o++] = '\033'; out[o++] = '['; out[o++] = '9'; out[o++] = 'm';
                memcpy(out + o, p+2, len); o += len;
                out[o++] = '\033'; out[o++] = '['; out[o++] = '0'; out[o++] = 'm';
                p = end + 2;
                continue;
            }
        }
        out[o++] = *p++;
    }
    out[o] = 0;
    return out;
}

/* 对单行进行格式化，返回带 ANSI 转义的新字符串 */
static char *format_line(const char *line) {
    static char formatted[32768];
    static char inline_buf[32768];
    inline_markdown(line, inline_buf, sizeof(inline_buf));

    const char *trimmed = inline_buf;
    while (*trimmed == ' ' || *trimmed == '\t') trimmed++;

    if (strncmp(trimmed, "# ", 2) == 0) {
        snprintf(formatted, sizeof(formatted), "\033[1;36m%s\033[0m", inline_buf);
    } else if (strncmp(trimmed, "## ", 3) == 0) {
        snprintf(formatted, sizeof(formatted), "\033[1;34m%s\033[0m", inline_buf);
    } else if (strncmp(trimmed, "### ", 4) == 0) {
        snprintf(formatted, sizeof(formatted), "\033[1;32m%s\033[0m", inline_buf);
    } else if (strncmp(trimmed, "---", 3) == 0 || strncmp(trimmed, "===", 3) == 0 ||
               strncmp(trimmed, "***", 3) == 0 || strncmp(trimmed, "___", 3) == 0) {
        snprintf(formatted, sizeof(formatted), "\033[33m%s\033[0m", inline_buf);
    } else if (inline_buf[0] == '|' && inline_buf[strlen(inline_buf)-1] == '|') {
        snprintf(formatted, sizeof(formatted), "\033[36m%s\033[0m", inline_buf);
    } else if (inline_buf[0] == '>') {
        snprintf(formatted, sizeof(formatted), "\033[3;90m%s\033[0m", inline_buf);
    } else {
        snprintf(formatted, sizeof(formatted), "%s", inline_buf);
    }
    return formatted;
}

/* 跨调用行缓冲（全局静态，用于流式累积） */
static char g_line_buf[8192];
static size_t g_line_len = 0;

/* 对增量文本 `dec` 逐行格式化并打印，支持跨调用累积 */
static void print_formatted_dec(const char *dec) {
    const char *p = dec;
    while (*p) {
        if (*p == '\n') {
            g_line_buf[g_line_len] = '\0';
            if (g_line_len > 0) {
                char *formatted = format_line(g_line_buf);
                printf("%s\n", formatted);
                fflush(stdout);
            } else {
                printf("\n");
                fflush(stdout);
            }
            g_line_len = 0;
        } else {
            if (g_line_len < sizeof(g_line_buf) - 1) {
                g_line_buf[g_line_len++] = *p;
            }
        }
        p++;
    }
}

/* 强制刷新剩余未完成的行（在流式结束时调用） */
static void flush_formatted(void) {
    if (g_line_len > 0) {
        g_line_buf[g_line_len] = '\0';
        char *formatted = format_line(g_line_buf);
        printf("%s", formatted);
        fflush(stdout);
        g_line_len = 0;
    }
}

static int extract_json_val(const char *str, const char *key, char *buf, size_t bufsz) {
    if (!str || !key || !buf || bufsz == 0) { if (buf && bufsz) buf[0] = 0; return 0; }
    buf[0] = 0;
    const char *kk = key;
    while (*kk == ' ' || *kk == '"') kk++;
    const char *fstart = kk;
    while (*kk && *kk != '"' && *kk != ':' && *kk != ' ') kk++;
    size_t fnlen = (size_t)(kk - fstart);
    while (fnlen > 0 && (fstart[fnlen-1] == ' ' || fstart[fnlen-1] == '"')) fnlen--;
    if (fnlen == 0 || fnlen > 120) return 0;
    const char *p = str;
    while ((p = strchr(p, fstart[0]))) {
        if (strncmp(p, fstart, fnlen) != 0) { p++; continue; }
        if (p > str) { char c0 = p[-1]; if ((c0>='a'&&c0<='z')||(c0>='A'&&c0<='Z')||(c0>='0'&&c0<='9')||c0=='_') { p++; continue; } }
        const char *q = p + fnlen;
        if (*q == '"') q++;
        while (*q == ' ' || *q == '\t') q++;
        if (*q != ':') { p++; continue; }
        q++;
        while (*q == ' ' || *q == '\t') q++;
        size_t o = 0;
        if (*q == '"') {
            q++;
            while (*q && o + 1 < bufsz) {
                if (*q == '\\') {
                    q++;
                    if (*q == 'n') { buf[o++] = '\n'; q++; }
                    else if (*q == 't') { buf[o++] = '\t'; q++; }
                    else if (*q == 'r') { buf[o++] = '\r'; q++; }
                    else if (*q == 'u') { q++; if(*q)q++; if(*q)q++; if(*q)q++; if(*q)q++; }
                    else if (o + 1 < bufsz && *q) { buf[o++] = *q; q++; }
                } else if (*q == '"') { buf[o] = 0; return 1; }
                else { buf[o++] = *q++; }
            }
            buf[o] = 0; return 1;
        } else if (*q == '\'') {
            q++;
            while (*q && o + 1 < bufsz) {
                if (*q == '\\') { if (o + 2 < bufsz) { buf[o++] = *q++; if (*q) buf[o++] = *q++; } else break; }
                else if (*q == '\'') { buf[o] = 0; return 1; }
                else { buf[o++] = *q++; }
            }
            buf[o] = 0; return 1;
        } else {
            while (*q && *q != ',' && *q != '}' && *q != ' ' && *q != '\t' && *q != '\n' && o + 1 < bufsz) {
                if (*q == '\\') { if (o + 2 < bufsz) { buf[o++] = *q++; if (*q) buf[o++] = *q++; } else break; }
                else buf[o++] = *q++;
            }
            buf[o] = 0; return 1;
        }
    }
    return 0;
}

static char *buf_append(char *b, size_t *len, size_t *cap, const char *s) {
    size_t add = strlen(s);
    if (*len + add + 1 >= *cap) { while (*len + add + 1 >= *cap) (*cap) *= 2; char *n = realloc(b, *cap); if (!n) return b; b = n; }
    memcpy(b + *len, s, add); *len += add; b[*len] = 0;
    return b;
}

static char *json_escape(const char *s) {
    size_t cap = strlen(s) * 2 + 64, len = 0;
    char *b = malloc(cap); if (!b) return NULL;
    while (*s) {
        if (len + 8 >= cap) { cap *= 2; char *nb = realloc(b, cap); if (!nb) return b; b = nb; }
        unsigned char c = (unsigned char)*s;
        if (c == '"') { b[len++] = '\\'; b[len++] = '"'; }
        else if (c == '\\') { b[len++] = '\\'; b[len++] = '\\'; }
        else if (c == '/') { b[len++] = '\\'; b[len++] = '/'; }
        else if (c == '\b') { b[len++] = '\\'; b[len++] = 'b'; }
        else if (c == '\f') { b[len++] = '\\'; b[len++] = 'f'; }
        else if (c == '\n') { b[len++] = '\\'; b[len++] = 'n'; }
        else if (c == '\r') { b[len++] = '\\'; b[len++] = 'r'; }
        else if (c == '\t') { b[len++] = '\\'; b[len++] = 't'; }
        else if (c < 0x20) {
            int n = len;
            len += snprintf(b + len, cap - len, "\\u%04x", c);
            if (len >= cap) { len = n; }
        }
        else b[len++] = c;
        s++;
    }
    b[len] = 0; return b;
}

/* ============ 流式对话（支持 CA） ============ */
static char *chat_stream(const char *url, const char *auth, const char *body) {
    char *args[64]; int n = 0;
    args[n++] = "-s"; args[n++] = "-S";
    if (CA_BUNDLE[0]) {
        args[n++] = "--cacert"; args[n++] = (char*)CA_BUNDLE;
    } else {
        args[n++] = "-k";
    }
    args[n++] = "--dns-servers"; args[n++] = "223.5.5.5,119.29.29.29,114.114.114.114,8.8.8.8,1.1.1.1";
    args[n++] = "-N"; args[n++] = "--no-buffer";
    if (strstr(body, "\"stream\":true")) { args[n++] = "--max-time"; args[n++] = "600"; }
    else { args[n++] = "--max-time"; args[n++] = "300"; }
    args[n++] = "-X"; args[n++] = "POST";
    args[n++] = "-H"; { static char h1[700]; snprintf(h1,sizeof(h1),"Content-Type: application/json"); args[n++] = h1; }
    args[n++] = "-H"; { static char h2[700]; snprintf(h2,sizeof(h2),"Authorization: Bearer %s", auth); args[n++] = h2; }
    args[n++] = "--data"; args[n++] = (char*)body;
    args[n++] = (char*)url; args[n++] = NULL;

    int outpipe[2];
    if (pipe(outpipe) != 0) return NULL;
    long fd = sc_memfd_create("curl", 0);
    if (fd < 0) { close(outpipe[0]); close(outpipe[1]); return NULL; }
    {
        const unsigned char *bs = _binary_curl_start, *be = _binary_curl_end;
        size_t sz = (size_t)(be - bs), off = 0;
        while (off < sz) {
            ssize_t w = write((int)fd, bs + off, sz - off);
            if (w <= 0) { close((int)fd); close(outpipe[0]); close(outpipe[1]); return NULL; }
            off += (size_t)w;
        }
    }
    pid_t pid = fork();
    if (pid < 0) { close((int)fd); close(outpipe[0]); close(outpipe[1]); return NULL; }
    if (pid == 0) {
        int dn = open("/dev/null", O_RDONLY); if (dn >= 0) { dup2(dn, 0); close(dn); }
        dup2(outpipe[1], 1); dup2(outpipe[1], 2);
        close(outpipe[0]); close(outpipe[1]);
        char *nargv[64]; int i, c = 0;
        nargv[c++] = (char*)"curl";
        for (i = 0; args && args[i] && c < 62; i++) nargv[c++] = args[i];
        nargv[c] = NULL;
        const char *envp[] = {"PATH=/system/bin:/data/bin:/usr/bin:/bin","HOME=/data/local/tmp","SSL_CERT_FILE=","LANG=C","LC_ALL=C",NULL};
        syscall(SYS_execveat, (int)fd, "", nargv, envp, AT_EMPTY_PATH);
        _exit(127);
    }
    close(outpipe[1]);

    size_t linelen = 0, linecap = 8192;
    char *line = malloc(linecap); if (!line) { close(outpipe[0]); close((int)fd); while(waitpid(pid,NULL,0)!=-1){} return NULL; }
    size_t ccap = 32768, clen = 0;
    char *content = malloc(ccap); if (!content) { free(line); close(outpipe[0]); close((int)fd); while(waitpid(pid,NULL,0)!=-1){} return NULL; } content[0] = 0;
    size_t rcap = 32768, rlen = 0;
    char *reason = malloc(rcap); if (!reason) { free(content); free(line); close(outpipe[0]); close((int)fd); while(waitpid(pid,NULL,0)!=-1){} return NULL; } reason[0] = 0;

    int printed_any = 0, content_started = 0, rblock = 0;
    const char *spin = "/-\\|"; int spin_i = 0, spin_shown = 0;
    char tmp[8192];
    ssize_t r; int interrupted = 0;

    while (1) {
        if (g_interrupt) {
            interrupted = 1;
            break;
        }
        r = read(outpipe[0], tmp, sizeof(tmp));
        if (r < 0) {
            if (errno == EINTR) {
                if (g_interrupt) {
                    interrupted = 1;
                    break;
                }
                continue;
            }
            break;
        }
        if (r == 0) break;
        for (size_t i = 0; i < (size_t)r; i++) {
            char ch = tmp[i];
            if (ch == '\n') {
                line[linelen] = 0;
                if (strncmp(line, "data:", 5) == 0) {
                    const char *js = line + 5;
                    while (*js == ' ') js++;
                    if (strncmp(js, "[DONE]", 6) != 0) {
                        char v[MAX_BIG];
                        if (extract_json_val(js, "\"reasoning_content\":", v, sizeof(v))) {
                            char dec[MAX_BIG]; json_unescape(v, dec, sizeof(dec));
                            if (dec[0]=='n' && strcmp(dec,"null")==0) dec[0]=0;
                            else if (dec[0]=='{'&&dec[1]=='}') dec[0]=0;
                            else if (dec[0]=='['&&dec[1]==']') dec[0]=0;
                            if (!rblock && SHOWTHINK && *dec) {
                                if (spin_shown) { printf("\r\x1b[K"); fflush(stdout); spin_shown = 0; }
                                printf("%s┬─ 思考 %s\n", MG, RS); fflush(stdout); rblock = 1;
                            }
                            if (rblock && *dec && !content_started) {
                                if (spin_shown) { printf("\r\x1b[K"); fflush(stdout); spin_shown = 0; }
                                printf("%s%s", MG, dec); fflush(stdout);
                            } else if (!content_started) {
                                if (!spin_shown) { printf("%s[思考中 ]%s", YL, RS); fflush(stdout); spin_shown = 1; }
                                else { printf("\b%c", spin[spin_i++ & 3]); fflush(stdout); }
                            }
                            char *du = strdup(dec); if (du) { reason = buf_append(reason, &rlen, &rcap, du); free(du); }
                        }
                        if (extract_json_val(js, "\"content\":", v, sizeof(v))) {
                            char dec[MAX_BIG]; json_unescape(v, dec, sizeof(dec));
                            if (dec[0]=='n'&&strcmp(dec,"null")==0) dec[0]=0;
                            else if (dec[0]=='{'&&dec[1]=='}') dec[0]=0;
                            else if (dec[0]=='['&&dec[1]==']') dec[0]=0;
                            if (*dec) {
                                if (spin_shown && !content_started) {
                                    printf("\r\x1b[K");
                                    fflush(stdout);
                                    spin_shown = 0;
                                }
                                if (rblock && !content_started) {
                                    printf("%s└─%s\n", MG, RS);
                                    rblock = 0;
                                }
                                if (!content_started) {
                                    printf("%sAI> %s", GC, RS);
                                    fflush(stdout);
                                    content_started = 1;
                                }
                                print_formatted_dec(dec);
                                printed_any = 1;
                                char *du = strdup(dec);
                                if (du) {
                                    content = buf_append(content, &clen, &ccap, du);
                                    free(du);
                                }
                            }
                        }
                    }
                }
                linelen = 0;
            } else {
                if (linelen + 1 < linecap) line[linelen++] = ch;
            }
        }
    }
    close(outpipe[0]); close((int)fd);

    if (interrupted) {
        if (spin_shown) { printf("\r\x1b[K"); fflush(stdout); }
        printf("%s[已中断]%s\n", YL, RS);
        kill(pid, SIGKILL);
        while(waitpid(pid, NULL, 0) != -1) {}
        free(line); if (reason) free(reason); if (clen) free(content);
        g_stream_interrupted = 1;
        return NULL;
    }
    while (waitpid(pid, NULL, 0) != -1) {}
    if (spin_shown) { printf("\r\x1b[K"); fflush(stdout); }
    if (rblock) printf("%s└─%s\n", MG, RS);
    flush_formatted();
    if (printed_any) printf("%s\n", RS);
    free(line); if (reason) free(reason);
    if (!clen) { free(content); return NULL; }
    return content;
}

/* ============ 构造请求体 ============ */
static char *build_body_tooled(const char *user_input, const char *api_base, const char *model) {
    size_t cap = 262144, len = 0;
    char *b = malloc(cap); if (!b) return NULL; b[0] = 0;

    if (!g_toolcache) g_toolcache = build_tools_usage_text();

    char *sysall = NULL;
    if (TOOLS_ENABLED && g_toolcache) {
        size_t nd = strlen(SYSTEM_PROMPT) + strlen(g_toolcache) + 64;
        sysall = malloc(nd); if (sysall) snprintf(sysall, nd, "%s\n\n[系统工具能力]\n%s", SYSTEM_PROMPT, g_toolcache);
    } else {
        sysall = strdup(SYSTEM_PROMPT);
    }
    char *sp = sysall ? json_escape(sysall) : json_escape(SYSTEM_PROMPT);

    int need = snprintf(b, cap, "{\"model\":\"%s\",\"messages\":[{\"role\":\"system\",\"content\":\"%s\"}", model, sp ? sp : "");
    if (need > 0) len = (size_t)need;
    free(sp); free(sysall);

    for (int i = 0; i < hist_n; i++) {
        char *esc = json_escape(hist[i].content);
        while (len + strlen(esc) + 128 >= cap) { cap *= 2; char *nb = realloc(b, cap); if (!nb) { free(esc); return b; } b = nb; }
        int n2 = snprintf(b + len, cap - len, ",{\"role\":\"%s\",\"content\":\"%s\"}", hist[i].role, esc ? esc : "");
        if (n2 > 0) len += (size_t)n2;
        free(esc);
    }
    char *ue = json_escape(user_input);
    while (len + strlen(ue) + 128 >= cap) { cap *= 2; char *nb = realloc(b, cap); if (!nb) { free(ue); return b; } b = nb; }
    int n3 = snprintf(b + len, cap - len, ",{\"role\":\"user\",\"content\":\"%s\"}]", ue ? ue : "");
    if (n3 > 0) len += (size_t)n3;
    free(ue);
    int n4 = snprintf(b + len, cap - len, ",\"thinking\":{\"type\":\"%s\"},\"stream\":true}", THINK ? "enabled" : "disabled");
    if (n4 > 0) len += (size_t)n4;
    return b;
}

/* ============ 历史管理 ============ */
static void hist_add(const char *role, const char *content) {
    if (!content || !*content) return;
    int has_non_space = 0;
    for (const char *p = content; *p; p++) {
        if (*p != ' ' && *p != '\t' && *p != '\n' && *p != '\r') {
            has_non_space = 1;
            break;
        }
    }
    if (!has_non_space) return;

    if (hist_n >= HIST_MAX) {
        free(hist[0].content);
        memmove(&hist[0], &hist[1], (HIST_MAX - 1) * sizeof(Msg));
        hist_n = HIST_MAX - 1;
    }
    hist[hist_n].role[0] = 0;
    strncpy(hist[hist_n].role, role, sizeof(hist[hist_n].role) - 1);
    char *cleaned = sanitize_utf8(content);
    hist[hist_n].content = cleaned;
    hist_n++;
}

/* ============ 会话持久化 ============ */
static void get_session_file(char *buf, size_t bufsz) {
    char dir[MAX_PATH];
    get_conf_dir(dir, sizeof(dir));
    snprintf(buf, bufsz, "%s/session.log", dir);
}

static void save_session(void) {
    char fname[MAX_PATH];
    get_session_file(fname, sizeof(fname));
    FILE *f = fopen(fname, "w");
    if (!f) return;
    for (int i = 0; i < hist_n; i++) {
        char *esc = json_escape(hist[i].content);
        fprintf(f, "%s:%s\n", hist[i].role, esc ? esc : "");
        free(esc);
    }
    fclose(f);
    printf("%s[会话已保存]%s\n", GC, RS);
}

static void load_session(void) {
    char fname[MAX_PATH];
    get_session_file(fname, sizeof(fname));
    FILE *f = fopen(fname, "r");
    if (!f) return;
    char *line = malloc(MAX_LINE);   // MAX_LINE 你本来就定义成 262144
    if (!line) {
        fclose(f);
        return;
    }
    int loaded = 0;
    while (fgets(line, sizeof(line), f)) {
        line[strcspn(line, "\r\n")] = 0;
        char *sep = strchr(line, ':');
        if (!sep) continue;
        *sep = '\0';
        char *role = line;
        char *content_esc = sep + 1;
        if (strlen(role) == 0 || strlen(content_esc) == 0) continue;
        char content_dec[32768];
        json_unescape(content_esc, content_dec, sizeof(content_dec));
        int has_non_space = 0;
        for (const char *p = content_dec; *p; p++) {
            if (*p != ' ' && *p != '\t' && *p != '\n' && *p != '\r') {
                has_non_space = 1;
                break;
            }
        }
        if (!has_non_space) continue;
        char *cleaned = sanitize_utf8(content_dec);
        if (hist_n >= HIST_MAX) break;
        strncpy(hist[hist_n].role, role, sizeof(hist[hist_n].role)-1);
        hist[hist_n].content = cleaned;
        hist_n++;
        loaded++;
    }
    fclose(f);
    free(line);
    if (loaded > 0) printf("%s[已恢复 %d 条会话记录]%s\n", GC, loaded, RS);
}

/* ============ AI 提供商配置管理 ============ */


/* 加载所有提供商的配置 */
static void load_all_conf(void) {
    ensure_conf_dir();
    init_prov_conf();

    for (int i = 0; i < NPROV; i++) {
        char fname[MAX_PATH];
        get_conf_file(fname, sizeof(fname), providers[i].conf_key);
        FILE *f = fopen(fname, "r");
        if (!f) continue;
        has_any_config = 1;
        char line[MAX_LINE];
        while (fgets(line, sizeof(line), f)) {
            line[strcspn(line, "\r\n")] = 0;
            if (!line[0] || line[0] == '#') continue;
            if (!strncmp(line, "api_base=", 9)) snprintf(prov_conf[i].api_base, sizeof(prov_conf[i].api_base), "%s", line + 9);
            else if (!strncmp(line, "active_key=", 11)) prov_conf[i].active_key = atoi(line + 11);
            else if (!strncmp(line, "model=", 6)) snprintf(prov_conf[i].model, sizeof(prov_conf[i].model), "%s", line + 6);
            else if (!strncmp(line, "api_key_", 8)) {
                int kn=atoi(line+8); const char *v=strchr(line+8,'=');
                if(v&&kn>=0&&kn<MAX_KEYS_PER_PROV){v++;snprintf(prov_conf[i].api_keys[kn],sizeof(prov_conf[i].api_keys[0]),"%s",v);if(kn+1>prov_conf[i].num_keys)prov_conf[i].num_keys=kn+1;}
            }
        }
        fclose(f);
        if (prov_conf[i].num_keys > 0 && prov_conf[i].api_base[0] && prov_conf[i].model[0]) {
            prov_conf[i].enabled = 1;
        }
        if (!prov_conf[i].api_base[0] && providers[i].base[0])
            snprintf(prov_conf[i].api_base, sizeof(prov_conf[i].api_base), "%s", providers[i].base);
        if (!prov_conf[i].model[0] && providers[i].model[0])
            snprintf(prov_conf[i].model, sizeof(prov_conf[i].model), "%s", providers[i].model);
    }

    /* 加载全局设置（含 ca_bundle） */
    char gf[MAX_PATH];
    get_conf_file(gf, sizeof(gf), "global");
    FILE *gfptr = fopen(gf, "r");
    if (gfptr) {
        char line[MAX_LINE];
        while (fgets(line, sizeof(line), gfptr)) {
            line[strcspn(line, "\r\n")] = 0;
            if (!line[0] || line[0] == '#') continue;
            if (!strncmp(line, "system_prompt=", 14)) snprintf(SYSTEM_PROMPT, sizeof(SYSTEM_PROMPT), "%s", line + 14);
            else if (!strncmp(line, "ca_bundle=", 10)) snprintf(CA_BUNDLE, sizeof(CA_BUNDLE), "%s", line + 10);
            else if (!strncmp(line, "think=", 6)) THINK = (line[6]=='o' && line[7]=='n');
            else if (!strncmp(line, "showthink=", 10)) SHOWTHINK = (line[10]=='o' && line[11]=='n');
            else if (!strncmp(line, "tools_enabled=", 14)) TOOLS_ENABLED = (line[14]=='o' && line[15]=='n');
            else if (!strncmp(line, "current_provider=", 17)) {
                const char *val = line + 17;
                int idx = atoi(val) - 1;
                if (idx >= 0 && idx < NPROV && val[0] >= '0' && val[0] <= '9')
                    current_provider = idx;
                else
                    for (int p = 0; p < NPROV; p++)
                        if (!strcmp(val, providers[p].conf_key)) { current_provider = p; break; }
            }
            else if (!strncmp(line, "current_search_provider=", 24)) {
                int idx = atoi(line + 24) - 1;
                if (idx >= 0 && idx < NSEARCHPROV) current_search_provider = idx;
            }
        }
        fclose(gfptr);
    }

    /* 加载搜索提供商配置 */
    for (int i = 0; i < NSEARCHPROV; i++) {
        load_search_provider_conf(i);
    }

    if (current_provider < 0) {
        for (int i = 0; i < NPROV; i++) {
            if (prov_conf[i].enabled) { current_provider = i; break; }
        }
    }
}

/* 保存单个提供商配置 */
static int save_provider_conf(int idx) {
    ensure_conf_dir();
    char fname[MAX_PATH];
    get_conf_file(fname, sizeof(fname), providers[idx].conf_key);
    FILE *f = fopen(fname, "w");
    if (!f) return -1;
    fprintf(f, "# AI CLI 配置 - %s\n", providers[idx].name);
    fprintf(f, "api_base=%s\n", prov_conf[idx].api_base);
    fprintf(f, "model=%s\n", prov_conf[idx].model);
    fprintf(f, "active_key=%d\n", prov_conf[idx].active_key);
    for (int k = 0; k < prov_conf[idx].num_keys; k++)
        fprintf(f, "api_key_%d=%s\n", k, prov_conf[idx].api_keys[k]);
    fclose(f);
    chmod(fname, 0600);
    return 0;
}

/* 保存全局设置（含 ca_bundle 和搜索配置） */
static int save_global_conf(void) {
    ensure_conf_dir();
    char fname[MAX_PATH];
    get_conf_file(fname, sizeof(fname), "global");
    FILE *f = fopen(fname, "w");
    if (!f) return -1;
    fprintf(f, "# AI CLI 全局配置\n");
    fprintf(f, "system_prompt=%s\n", SYSTEM_PROMPT);
    fprintf(f, "ca_bundle=%s\n", CA_BUNDLE);
    fprintf(f, "think=%s\n", THINK ? "on" : "off");
    fprintf(f, "showthink=%s\n", SHOWTHINK ? "on" : "off");
    fprintf(f, "tools_enabled=%s\n", TOOLS_ENABLED ? "on" : "off");
    if (current_provider >= 0 && current_provider < NPROV)
        fprintf(f, "current_provider=%s\n", providers[current_provider].conf_key);
    else
        fprintf(f, "current_provider=none\n");
    fprintf(f, "current_search_provider=%d\n", current_search_provider + 1);
    fclose(f);
    chmod(fname, 0600);
    return 0;
}

/* 保存所有配置 */
static int save_all_conf(void) {
    int rc = 0;
    for (int i = 0; i < NPROV; i++) {
        if (prov_conf[i].enabled || prov_conf[i].num_keys > 0) {
            if (save_provider_conf(i) != 0) rc = -1;
        }
    }
    for (int i = 0; i < NSEARCHPROV; i++) {
        if (search_conf[i].enabled || search_conf[i].num_keys > 0) {
            if (save_search_provider_conf(i) != 0) rc = -1;
        }
    }
    if (save_global_conf() != 0) rc = -1;
    return rc;
}

/* ============ 命令处理 ============ */
static int known_cmd(const char *s) {
    static const char *known[] = {
        "/exit","/quit","/model","/key","/keys","/set","/provider","/providers",
        "/system","/conf","/confs","/new","/tools","/help","/h","/think","/showthink",
        "/ca","/save","/load",
        "/searchprovider","/searchkey","/searchkeys","/searchcustom",
        0
    };
    for (int i = 0; known[i]; i++) if (!strcmp(s, known[i])) return 1;
    return 0;
}

/* 行读取 (支持方向键/退格/Ctrl+C) */
static char *read_line_prompt(const char *prompt) {
    if (PEND_ARG) { char *r = PEND_ARG; PEND_ARG = NULL; return r; }

    struct termios old, raw;
    tcgetattr(0, &old);
    raw = old;
    raw.c_lflag &= ~(ICANON | ECHO);
    raw.c_cc[VMIN] = 1; raw.c_cc[VTIME] = 0;
    tcsetattr(0, TCSANOW, &raw);

    printf("%s", prompt); fflush(stdout);

    char *buf = NULL;
    size_t cap = 0, len = 0;
    int pos = 0;
    int eof = 0;

    int get_display_col(const char *s, int byte_len) {
        int col = 0;
        const char *p = s;
        int remaining = byte_len;
        while (remaining > 0 && *p) {
            wchar_t wc;
            int n = mbtowc(&wc, p, MB_CUR_MAX);
            if (n <= 0) break;
            int w = wcwidth(wc);
            if (w < 0) w = 1;
            col += w;
            p += n;
            remaining -= n;
        }
        return col;
    }

    #define REDRAW() do { \
        printf("\r\x1b[K%s%s", prompt, buf ? buf : ""); \
        int cursor_col = get_display_col(buf, pos); \
        if (cursor_col > 0) printf("\x1b[%dG", cursor_col + 1); \
        fflush(stdout); \
    } while(0)

    unsigned char ch;
    while (1) {
        ssize_t got = read(0, &ch, 1);
        if (got < 0) {
            if (errno == EINTR) {
                pos = 0; len = 0; if (buf) buf[0] = 0;
                REDRAW();
                continue;
            }
            eof = 1; break;
        }
        if (got == 0) { eof = 1; break; }

        if (ch == 27) {
            unsigned char s1, s2;
            if (read(0, &s1, 1) != 1) { eof = 1; break; }
            if (s1 == '[' && read(0, &s2, 1) == 1) {
                if (s2 == 'D') {
                    if (pos > 0) {
                        int ks = pos - 1;
                        while (ks > 0 && ((unsigned char)buf[ks] & 0xC0) == 0x80) ks--;
                        pos = ks;
                        REDRAW();
                    }
                } else if (s2 == 'C') {
                    if (pos < (int)len) {
                        int end = pos + 1;
                        while (end < (int)len && ((unsigned char)buf[end] & 0xC0) == 0x80) end++;
                        pos = end;
                        REDRAW();
                    }
                }
            }
            continue;
        }

        if (ch == '\n' || ch == '\r') break;

        if (ch == 3) {
            pos = 0; len = 0; if (buf) buf[0] = 0;
            REDRAW();
            continue;
        }

        if (ch == 127 || ch == 8) {
            if (pos > 0) {
                int ks = pos - 1;
                while (ks > 0 && ((unsigned char)buf[ks] & 0xC0) == 0x80) ks--;
                int d = pos - ks;
                if (pos == (int)len) {
                    len -= d;
                    pos = ks;
                    if (buf) buf[len] = 0;
                } else {
                    memmove(buf + ks, buf + pos, len - pos);
                    len -= d;
                    buf[len] = 0;
                    pos = ks;
                }
                REDRAW();
            }
            continue;
        }

        if (len + 2 >= cap) {
            cap = cap ? cap * 2 : 256;
            char *nb = realloc(buf, cap);
            if (!nb) { eof = 1; break; }
            buf = nb;
        }
        if (pos == (int)len) {
            buf[len++] = ch;
            pos = len;
            buf[len] = 0;
        } else {
            memmove(buf + pos + 1, buf + pos, len - pos);
            buf[pos] = ch;
            len++;
            pos++;
            buf[len] = 0;
        }
        REDRAW();
    }

    printf("\r\x1b[K");
    tcsetattr(0, TCSANOW, &old);

    if (eof && len == 0) { free(buf); return NULL; }
    if (!buf) buf = strdup("");
    else { buf = realloc(buf, len + 1); if (buf) buf[len] = 0; }
    if (!buf) buf = strdup("");
    return buf;
}

static char *read_line(void) { return read_line_prompt(""); }

/* 列出所有提供商 */
static void list_providers(void) {
    printf("%s=== 已配置的 AI 提供商 ===%s\n", CY, RS);
    int found = 0;
    for (int i = 0; i < NPROV; i++) {
        if (prov_conf[i].enabled || prov_conf[i].num_keys > 0) {
            found = 1;
            printf("  %s%d%s [%s] %s 模型:%s%s%s\n",
                (i == current_provider) ? GC : "",
                i + 1,
                (i == current_provider) ? "*" : " ",
                providers[i].conf_key,
                providers[i].name,
                MG, prov_conf[i].model, RS);
        }
    }
    if (!found) printf("  (无已配置的提供商)\n");
    printf("\n%s所有可用提供商:%s\n", CY, RS);
    for (int i = 0; i < NPROV; i++) {
        printf("  %s%d%s  %-20s %s\n", MG, i + 1, RS, providers[i].conf_key, providers[i].name);
    }
}

/* 选择/设置当前提供商 */
static void pick_provider(void) {
    printf("%s请选择 AI 服务提供商:%s\n", CY, RS);
    for (int i = 0; i < NPROV; i++) {
        printf("  %s%d%s  %-20s %s%s%s\n", MG, i + 1, RS, providers[i].conf_key, providers[i].name,
               prov_conf[i].enabled ? GC : "", prov_conf[i].enabled ? " [已配置]" : "");
    }
    printf("输入数字 [1-%d]> ", NPROV); fflush(stdout);
    char *in = read_line();
    if (in && *in) {
        int sel = atoi(in) - 1;
        if (sel >= 0 && sel < NPROV) {
            current_provider = sel;
            printf("%s已选择: %s%s\n", GC, providers[sel].name, RS);
            if (sel == NPROV - 1 && !prov_conf[sel].api_base[0]) {
                printf("AI服务地址 (含 /v1)> "); fflush(stdout);
                char *ci = read_line(); if (ci && *ci) snprintf(prov_conf[sel].api_base, sizeof(prov_conf[sel].api_base), "%s", ci); free(ci);
            }
            if (prov_conf[sel].num_keys == 0) {
                printf("API Key> "); fflush(stdout);
                char *ki = read_line(); if (ki && *ki) {
                    addkey(sel, ki);
                    prov_conf[sel].enabled = 1;
                }
                free(ki);
            }
            if (prov_conf[sel].enabled && !prov_conf[sel].model[0]) {
                char *_tk = getkey(sel);
                pick_model_for(_tk, prov_conf[sel].api_base, prov_conf[sel].model, sizeof(prov_conf[sel].model));
                free(_tk);
            }
        } else {
            printf("%s[!] 输入无效%s\n", YL, RS);
        }
    }
    free(in);
}

/* 列出所有搜索提供商并切换 */
static void list_search_providers(void) {
    printf("%s=== 已配置的搜索提供商 ===%s\n", CY, RS);
    int found = 0;
    for (int i = 0; i < NSEARCHPROV; i++) {
        if (search_conf[i].enabled || search_conf[i].num_keys > 0) {
            found = 1;
            printf("  %s%d%s [%s] %s%s%s\n",
                (i == current_search_provider) ? GC : "",
                i + 1,
                (i == current_search_provider) ? "*" : " ",
                search_provider_defs[i].id,
                search_provider_defs[i].name,
                " (已配置)", RS);
        }
    }
    if (!found) printf("  (无已配置的搜索提供商)\n");
    printf("\n%s所有可用搜索提供商:%s\n", CY, RS);
    for (int i = 0; i < NSEARCHPROV; i++) {
        printf("  %s%d%s  %-20s %s\n", MG, i + 1, RS, search_provider_defs[i].id, search_provider_defs[i].description);
    }
}

/* 显示当前配置（含搜索配置） */
static void show_conf(void) {
    char dir[MAX_PATH]; get_conf_dir(dir, sizeof(dir));
    printf("%s=== 当前配置 ===%s\n", CY, RS);
    printf("平台: %s%s%s\n", MG, is_android() ? "Android" : "Linux", RS);
    printf("配置目录: %s%s%s\n", MG, dir, RS);
    if (current_provider >= 0 && current_provider < NPROV) {
        int i = current_provider;
        printf("当前 AI 提供商: %s%s%s (%s)\n", GC, providers[i].name, RS, providers[i].conf_key);
        printf("  API Base: %s\n", prov_conf[i].api_base[0] ? prov_conf[i].api_base : "(空)");
        printf("  API Key:  %s (%d个, 活跃#%d)\n", prov_conf[i].num_keys > 0 ? "****(已设置)" : "(空)", prov_conf[i].num_keys, prov_conf[i].active_key + 1);
        printf("  Model:    %s\n", prov_conf[i].model[0] ? prov_conf[i].model : "(空)");
    } else {
        printf("当前 AI 提供商: %s(未选择)%s\n", YL, RS);
    }
    if (search_conf[current_search_provider].num_keys > 0) {
    printf("当前搜索提供商: %s%s%s\n", GC, search_provider_defs[current_search_provider].name, RS);
} else {
    printf("当前搜索提供商: %s%s (未配置)%s\n", YL, search_provider_defs[current_search_provider].name, RS);
}
    printf("  API Key: %s (%d个, 活跃#%d)\n",
        search_conf[current_search_provider].num_keys > 0 ? "****(已设置)" : "(空)",
        search_conf[current_search_provider].num_keys,
        search_conf[current_search_provider].active_key + 1);
    if (current_search_provider == NSEARCHPROV - 1 && search_conf[current_search_provider].api_base[0]) {
        printf("  自定义 API 地址: %s\n", search_conf[current_search_provider].api_base);
    }
    printf("CA 证书:   %s%s%s\n", CA_BUNDLE[0] ? GC : YL, CA_BUNDLE[0] ? CA_BUNDLE : "(未设置，使用 -k 跳过验证)", RS);
    printf("系统提示词: %s\n", SYSTEM_PROMPT);
    printf("思考: %s  显示思考: %s  工具: %s\n",
           THINK ? "on" : "off", SHOWTHINK ? "on" : "off", TOOLS_ENABLED ? "on" : "off");
}

/* 显示所有搜索提供商详细配置 */
static void show_all_search_confs(void) {
    printf("%s=== 所有搜索提供商配置 ===%s\n", CY, RS);
    for (int i = 0; i < NSEARCHPROV; i++) {
        printf("\n--- %s (%s) %s%s%s ---\n", search_provider_defs[i].name, search_provider_defs[i].id,
               search_conf[i].enabled ? GC : YL,
               search_conf[i].enabled ? "[已启用]" : "[未配置]", RS);
        printf("  api_base = %s\n", search_conf[i].api_base);
        printf("  api_keys = %d个 (活跃#%d)\n", search_conf[i].num_keys, search_conf[i].active_key + 1);
    }
}

/* y/n 确认 */
static int ask_yn(const char *msg) {
    for (;;) {
        printf("%s%s [y/N]: %s", YL, msg, RS); fflush(stdout);
        char *a = read_line();
        int r;
        if (!a) r = 0;
        else if (a[0] == 'y' || a[0] == 'Y') r = 1;
        else if (a[0] == 0 || a[0] == 'n' || a[0] == 'N') r = 0;
        else { free(a); printf("%s只能输入 y 或 n%s\n", YL, RS); continue; }
        free(a); return r;
    }
}

/* ============ 一轮对话 ============ */
static void do_chat(const char *input) {
    if (current_provider < 0 || current_provider >= NPROV) {
        printf("%s[!] 未选择 AI 提供商, 请先 /set 或 /provider%s\n", YL, RS); return;
    }
    int pi = current_provider;
    char *_dk = getkey(pi);
    if (!_dk || !_dk[0]) { printf("%s[!] 未配置 API Key，请用 /key 设置%s\n", YL, RS); if(_dk) free(_dk); return; }
    char *body = build_body_tooled(input, prov_conf[pi].api_base, prov_conf[pi].model);
    if (!body) { printf("%s[!] 内存错误%s\n", YL, RS); return; }

    char url[MAX_PATH + 64];
    size_t bl = strlen(prov_conf[pi].api_base);
    if (bl && prov_conf[pi].api_base[bl - 1] == '/') snprintf(url, sizeof(url), "%schat/completions", prov_conf[pi].api_base);
    else snprintf(url, sizeof(url), "%s/chat/completions", prov_conf[pi].api_base);

    int turn = 0; const int maxturn = 6;
    int user_recorded = 0;

    while (turn < maxturn) {
        turn++;
        g_interrupt = 0; g_stream_interrupted = 0; g_in_request = 1;
        printf("%s[流式…]%s ", CY, RS); fflush(stdout);
        char *content = chat_stream(url, _dk, body);
        free(body); body = NULL;
        g_in_request = 0;

        if (g_stream_interrupted) {
            free(content);
            printf("\n");
            return;
        }

        if (content == NULL || !*content) {
            if (content) free(content);
            printf("%s[!] 流式请求失败或响应为空，尝试非流式回退...%s\n", YL, RS);
            goto fallback;
        }

        if (has_tool_marker(content)) {
            char *tc = find_tool_call(content);
            if (tc) {
                printf("\n%s⟪调用工具…⟫%s ", CY, RS); fflush(stdout);
                char *r = execute_tool_call(tc);
                printf("[%s%d字节%s]\n", GC, r ? (int)strlen(r) : 0, RS);
                if (!user_recorded) { hist_add("user", input); user_recorded = 1; }
                if (r && *r) { char *msg = malloc(strlen(r) + 40); if (msg) { sprintf(msg, "(工具结果)\n%s", r); hist_add("user", msg); free(msg); } }
                free(r); free(tc); free(content);
                printf("%s[工具完成, 组织最终回答…]%s ", YL, RS); fflush(stdout);
                body = build_body_tooled("", prov_conf[pi].api_base, prov_conf[pi].model);
                if (!body) { printf("\n%s[!] 内存错误%s\n", YL, RS); return; }
                continue;
            }
            if (!user_recorded) { hist_add("user", input); user_recorded = 1; }
            hist_add("assistant", content);
            const char *emsg = "(检测到工具调用但格式无法解析。请严格按 [[TOOL]] {\"name\":\"...\",\"args\":{...}} [[/TOOL]] 格式输出)\n";
            hist_add("user", emsg);
            free(content);
            body = build_body_tooled("", prov_conf[pi].api_base, prov_conf[pi].model);
            if (!body) return;
            continue;
        }
        if (!user_recorded) { hist_add("user", input); user_recorded = 1; }
        hist_add("assistant", content);
        free(content);
        return;
    }
    printf("%s[!] 工具循环达到上限%s\n", YL, RS);
    return;

fallback:
    if (!user_recorded) { hist_add("user", input); user_recorded = 1; }
    body = build_body_tooled("", prov_conf[pi].api_base, prov_conf[pi].model);
    if (!body) { printf("%s[!] 内存错误%s\n", YL, RS); return; }
    printf("%s[回退非流式]%s ", YL, RS); fflush(stdout);
    char *resp = NULL;
    int rc = http_post_json(url, _dk, body, &resp);
    free(body); body = NULL;
    printf("\n");
    if (rc != 0 || !resp) {
        printf("%s[!] 非流式请求失败%s\n", YL, RS);
        return;
    }
    const char *trim = resp;
    while (*trim == ' ' || *trim == '\t' || *trim == '\n' || *trim == '\r') trim++;
    if (*trim != '{' && *trim != '[') {
        printf("%s[!] API 返回了非 JSON 响应，开头 200 字符如下：%s\n%s%.200s%s\n", YL, YL, YL, resp, RS);
        free(resp);
        return;
    }
    char *errmsg = jq_query("(.error.message // empty)", resp);
    if (errmsg && *errmsg) { printf("%s[!] API错误: %s%s\n", YL, errmsg, RS); free(errmsg); free(resp); return; }
    free(errmsg);
    if (SHOWTHINK) {
        char *reason = jq_query(".choices[0].message.reasoning_content // empty", resp);
        if (reason && *reason) { printf("%s┬─ 思考 %s\n%s%s%s\n%s└─%s\n", MG, RS, MG, reason, RS, MG, RS); }
        free(reason);
    }
    char *content2 = jq_query(".choices[0].message.content", resp);
    if (!content2 || !*content2) {
        printf("%s[!] 无法解析响应%s\n", YL, RS);
        free(content2); free(resp);
        return;
    }
    printf("%sAI> %s%s\n", GC, content2, RS);
    hist_add("assistant", content2);
    free(content2); free(resp);
}

/* ============ 帮助 ============ */
static void help(void) {
    printf(CY"══════════ AI CLI 终端对话工具 ══════════"RS"\n");
    printf(CY"  支持多提供商 · 内嵌 curl + jq + busybox\n"RS);
    printf(CY"  作者: deepseek v4 flash & @Chen9183 (github)\n"RS);
    printf(CY"  平台自动检测: Linux→/var/tmp/ai.conf/  Android→/data/local/tmp/ai.conf/\n"RS);
    printf("\n");
    printf(MG"AI 提供商命令:"RS"\n");
    printf("  /set <编号>         设置当前 AI 提供商\n");
    printf("  /key <新Key>        添加/更新当前 AI 提供商的 API Key\n");
    printf("  /keys               列出/切换当前 AI 提供商的多个 Key\n");
    printf("  /provider           重新选择/配置 AI 提供商\n");
    printf("  /providers          列出所有 AI 提供商状态\n");
    printf("  /model              切换/拉取模型\n");
    printf("\n");
    printf(MG"搜索 API 命令:"RS"\n");
    printf("  /searchprovider     列出/切换搜索 API 提供商\n");
    printf("  /searchkey <key>    添加/更新当前搜索提供商的 API Key\n");
    printf("  /searchkeys         列出/切换当前搜索提供商的多个 Key\n");
    printf("  /searchcustom <url> 设置自定义搜索 API 地址（自动切换到 custom）\n");
    printf("\n");
    printf(MG"其他命令:"RS"\n");
    printf("  /system             修改系统提示词\n");
    printf("  /ca [path]          设置 CA 证书路径（空则清除）\n");
    printf("  /conf               查看当前配置\n");
    printf("  /confs              查看所有提供商详细配置\n");
    printf("  /new                开启新对话(保留配置)\n");
    printf("  /tools on|off       开启/关闭 AI 工具调用\n");
    printf("  /think on|off       开启/关闭深度思考\n");
    printf("  /showthink on|off   显示/隐藏思考过程\n");
    printf("  /save               手动保存当前会话（退出时自动保存）\n");
    printf("  /load               手动加载上次保存的会话（启动时自动加载）\n");
    printf("  /help | /h          显示本帮助\n");
    printf("  /exit | /quit       退出(退出时询问是否保存)\n");
    printf("\n");
    printf(MG"工具能力:"RS"\n");
    printf("  bing_search   联网搜索   run_shell   执行shell命令\n");
    printf("  curl_download 下载文件   time_now    获取当前时间\n");
    printf("\n");
}

/* ============ 信号 ============ */
static void on_sigint(int s) { (void)s; if (g_in_request) g_interrupt = 1; }

/* ============ 配置向导 ============ */
static void wizard(void) {
    printf("%s=== 首次配置向导 ===%s\n", CY, RS);
    if (current_provider < 0) {
        pick_provider();
    }
    int pi = current_provider;
    if (pi < 0) return;
    char *_dk = getkey(pi);

    if (!_dk || !_dk[0]) {
        printf("API Key for %s> ", providers[pi].name); fflush(stdout);
        char *ki = read_line();
        if (ki && *ki) { addkey(pi, ki); prov_conf[pi].enabled = 1; }
        free(ki);
    }
    if (prov_conf[pi].enabled && !prov_conf[pi].model[0]) {
        pick_model_for(_dk, prov_conf[pi].api_base, prov_conf[pi].model, sizeof(prov_conf[pi].model));
    }
    free(_dk);
}

/* ============ main ============ */
int main(int argc, char **argv) {
    (void)argc; (void)argv;
    setvbuf(stdout, NULL, _IONBF, 0);
    setlocale(LC_ALL, "en_US.UTF-8");
    srand((unsigned)time(NULL) ^ (unsigned)getpid());
    int modified = 0;

    struct sigaction sa; memset(&sa, 0, sizeof(sa));
    sa.sa_handler = on_sigint; sigemptyset(&sa.sa_mask);
    sigaction(SIGINT, &sa, NULL);

    load_all_conf();

    /* 加载会话历史 */
    load_session();

    if (argc > 1) {
        const char *a = argv[1];
        if (!strcmp(a, "-h") || !strcmp(a, "--help") || !strcmp(a, "help") || !strcmp(a, "/h")) {
            help(); return 0;
        }
    }

    if (!has_any_config || current_provider < 0 || prov_conf[current_provider].num_keys == 0) {
        wizard();
    }

    char dir[MAX_PATH]; get_conf_dir(dir, sizeof(dir));
    printf(GC"═══ AI 对话 (输入 /help 查看命令) ═══"RS"\n");
    printf("  平台: %s  配置目录: %s\n", is_android() ? "Android" : "Linux", dir);
    if (current_provider >= 0) {
        printf("  AI 提供商: %s%s%s  模型: %s\n", CY, providers[current_provider].name, RS, prov_conf[current_provider].model);
    }
    if (search_conf[current_search_provider].num_keys > 0) {
    printf("  搜索提供商: %s%s%s\n", CY, search_provider_defs[current_search_provider].name, RS);
} else {
    printf("  搜索提供商: %s%s (未配置，请用 /searchkey 设置)%s\n", YL, search_provider_defs[current_search_provider].name, RS);
}
    printf("\n");

    char *input;
    while (1) {
        printf(GC"你> "RS); fflush(stdout);
        input = read_line();
        if (!input) break;

        if (input[0] == '/') {
            char *sp = strchr(input, ' ');
            if (sp) {
                char saved = *sp; *sp = '\0';
                if (known_cmd(input)) { PEND_ARG = strdup(sp + 1); }
                else *sp = saved;
            }
        }
        if (*input) printf(GC"你> %s"RS"\n", input);

        if (input[0] == '/' && input[1] == 0) { free(input); continue; }

        /* === /exit /quit === */
        if (!strcmp(input, "/exit") || !strcmp(input, "/quit")) {
            save_session();
            free(input); input = NULL;
            if (ask_yn("是否保存配置到配置目录?")) {
                if (save_all_conf() == 0) printf("%s[✓] 配置已保存%s\n", GC, RS);
                else printf("%s[!] 保存失败%s\n", YL, RS);
            } else {
                printf("%s[配置未保存, 已退出]%s\n", YL, RS);
            }
            break;
        }

        /* === /save /load /new /help /h === */
        else if (!strcmp(input, "/save")) { free(input); save_session(); continue; }
        else if (!strcmp(input, "/load")) {
            free(input);
            for (int i = 0; i < hist_n; i++) free(hist[i].content);
            hist_n = 0;
            load_session();
            continue;
        }
        else if (!strcmp(input, "/new")) {
            free(input);
            for (int i = 0; i < hist_n; i++) free(hist[i].content);
            hist_n = 0;
            printf("%s[已开启新对话(配置保留)]%s\n", GC, RS);
            continue;
        }
        else if (!strcmp(input, "/help") || !strcmp(input, "/h") || !strcmp(input, "help")) {
            free(input); help(); continue;
        }

        /* === AI 提供商命令 === */
        else if (!strncmp(input, "/set", 4)) {
            free(input);
            char *arg = PEND_ARG;
            if (!arg) {
                list_providers();
                printf("输入 AI 提供商编号> "); fflush(stdout);
                arg = read_line();
            }
            if (arg && *arg) {
                int sel = atoi(arg) - 1;
                if (sel >= 0 && sel < NPROV) {
                    current_provider = sel;
                    printf("%s已设置当前 AI 提供商: %s%s\n", GC, providers[sel].name, RS);
                    if (prov_conf[sel].num_keys == 0) {
                        printf("API Key> "); fflush(stdout);
                        char *ki = read_line();
                        if (ki && *ki) { addkey(sel, ki); prov_conf[sel].enabled = 1; }
                        free(ki);
                    }
                    if (prov_conf[sel].enabled && !prov_conf[sel].model[0]) {
                        char *_tk = getkey(sel);
                        pick_model_for(_tk, prov_conf[sel].api_base, prov_conf[sel].model, sizeof(prov_conf[sel].model));
                        free(_tk);
                    }
                    modified = 1;
                } else {
                    printf("%s[!] 无效编号%s\n", YL, RS);
                }
            }
            free(arg); PEND_ARG = NULL;
            continue;
        }
        else if (!strcmp(input, "/key")) {
            free(input);
            if (current_provider < 0) { printf("%s[!] 未选择 AI 提供商, 先 /set%s\n", YL, RS); continue; }
            char *arg = PEND_ARG;
            if (!arg) {
                printf("新 API Key for %s> ", providers[current_provider].name); fflush(stdout);
                arg = read_line();
            }
            if (arg && *arg) {
                addkey(current_provider, arg);
                prov_conf[current_provider].enabled = 1;
                printf("%s[✓] AI Key 已更新(退出时保存)%s\n", GC, RS);
                modified = 1;
            }
            free(arg); PEND_ARG = NULL;
            continue;
        }
        else if (!strcmp(input, "/keys")) {
            free(input);
            if (current_provider < 0) { printf("%s[!] 未选择 AI 提供商, 先 /set%s\n", YL, RS); continue; }
            int pi = current_provider;
            printf("%s=== %s 的 API Keys (%d个) ===%s\n", CY, providers[pi].name, prov_conf[pi].num_keys, RS);
            for (int k = 0; k < prov_conf[pi].num_keys; k++) {
                unsigned char b[MAX_KEY];
                b64dec(prov_conf[pi].api_keys[k], b, sizeof(b));
                int slen = (int)strlen((char*)b);
                const char *mark = (k == prov_conf[pi].active_key) ? " *" : "  ";
                if (slen <= 8)
                    printf("  %s%d%s %s****\n", (k == prov_conf[pi].active_key) ? GC : "", k+1, RS, mark);
                else
                    printf("  %s%d%s %s****…%s\n", (k == prov_conf[pi].active_key) ? GC : "", k+1, RS, mark, (char*)b + slen - 4);
            }
            printf("输入 Key 编号切换 (或回车取消)> "); fflush(stdout);
            char *ka = read_line();
            if (ka && *ka) {
                int kn = atoi(ka) - 1;
                if (kn >= 0 && kn < prov_conf[pi].num_keys) {
                    prov_conf[pi].active_key = kn;
                    printf("%s[=] 已切换到 Key #%d%s\n", GC, kn+1, RS);
                    modified = 1;
                } else {
                    printf("%s[!] 无效编号%s\n", YL, RS);
                }
            }
            free(ka);
            continue;
        }
        else if (!strcmp(input, "/provider")) { free(input); pick_provider(); modified = 1; continue; }
        else if (!strcmp(input, "/providers")) { free(input); list_providers(); continue; }
        else if (!strcmp(input, "/model")) {
            free(input);
            if (current_provider < 0) { printf("%s[!] 未选择 AI 提供商%s\n", YL, RS); continue; }
            int pi = current_provider;
            if (prov_conf[pi].num_keys > 0) {
                char *_dk = getkey(pi);
                pick_model_for(_dk, prov_conf[pi].api_base, prov_conf[pi].model, sizeof(prov_conf[pi].model));
                free(_dk);
                modified = 1;
            } else {
                printf("模型名 (直接输入)> "); fflush(stdout);
                char *mi = read_line(); if (mi && *mi) snprintf(prov_conf[pi].model, sizeof(prov_conf[pi].model), "%s", mi); free(mi);
                modified = 1;
            }
            continue;
        }

        /* === 搜索提供商命令 === */
        else if (!strcmp(input, "/searchprovider")) {
            free(input);
            char *arg = PEND_ARG;
            if (!arg) {
                list_search_providers();
                printf("输入搜索提供商编号> "); fflush(stdout);
                arg = read_line();
            }
            if (arg && *arg) {
                int sel = atoi(arg) - 1;
                if (sel >= 0 && sel < NSEARCHPROV) {
                    current_search_provider = sel;
                    printf("%s[✓] 搜索提供商已切换至: %s%s\n", GC, search_provider_defs[sel].name, RS);
                    if (sel == NSEARCHPROV - 1 && !search_conf[sel].api_base[0]) {
                        printf("请输入自定义搜索 API 地址> "); fflush(stdout);
                        char *cu = read_line(); if (cu && *cu) { snprintf(search_conf[sel].api_base, sizeof(search_conf[sel].api_base), "%s", cu); search_conf[sel].enabled = 1; modified = 1; } free(cu);
                    }
                    modified = 1;
                } else {
                    printf("%s[!] 无效编号%s\n", YL, RS);
                }
            }
            free(arg); PEND_ARG = NULL;
            continue;
        }
        else if (!strcmp(input, "/searchkey")) {
            free(input);
            char *arg = PEND_ARG;
            if (!arg) {
                printf("请输入搜索 API Key> "); fflush(stdout);
                arg = read_line();
            }
            if (arg && *arg) {
                if (add_search_key(current_search_provider, arg) >= 0) {
                    printf("%s[✓] 搜索 API Key 已添加/更新%s\n", GC, RS);
                    modified = 1;
                } else {
                    printf("%s[!] 添加失败（可能已满）%s\n", YL, RS);
                }
            }
            free(arg); PEND_ARG = NULL;
            continue;
        }
        else if (!strcmp(input, "/searchkeys")) {
            free(input);
            int idx = current_search_provider;
            printf("%s=== %s 的搜索 API Keys (%d个) ===%s\n", CY, search_provider_defs[idx].name, search_conf[idx].num_keys, RS);
            for (int k = 0; k < search_conf[idx].num_keys; k++) {
                unsigned char b[MAX_KEY];
                b64dec(search_conf[idx].api_keys[k], b, sizeof(b));
                int slen = (int)strlen((char*)b);
                const char *mark = (k == search_conf[idx].active_key) ? " *" : "  ";
                if (slen <= 8)
                    printf("  %s%d%s %s****\n", (k == search_conf[idx].active_key) ? GC : "", k+1, RS, mark);
                else
                    printf("  %s%d%s %s****…%s\n", (k == search_conf[idx].active_key) ? GC : "", k+1, RS, mark, (char*)b + slen - 4);
            }
            printf("输入 Key 编号切换 (或回车取消)> "); fflush(stdout);
            char *ka = read_line();
            if (ka && *ka) {
                int kn = atoi(ka) - 1;
                if (kn >= 0 && kn < search_conf[idx].num_keys) {
                    search_conf[idx].active_key = kn;
                    printf("%s[=] 已切换到 Key #%d%s\n", GC, kn+1, RS);
                    modified = 1;
                } else {
                    printf("%s[!] 无效编号%s\n", YL, RS);
                }
            }
            free(ka);
            continue;
        }
        else if (!strcmp(input, "/searchcustom")) {
            free(input);
            char *arg = PEND_ARG;
            if (!arg) {
                printf("请输入自定义搜索 API 地址> "); fflush(stdout);
                arg = read_line();
            }
            if (arg && *arg) {
                snprintf(search_conf[NSEARCHPROV - 1].api_base, sizeof(search_conf[NSEARCHPROV - 1].api_base), "%s", arg);
                search_conf[NSEARCHPROV - 1].enabled = 1;
                current_search_provider = NSEARCHPROV - 1;
                printf("%s[✓] 自定义搜索 API 已设置，已自动切换到 custom%s\n", GC, RS);
                modified = 1;
            }
            free(arg); PEND_ARG = NULL;
            continue;
        }

        /* === 通用命令 === */
        else if (!strcmp(input, "/system")) {
            free(input);
            printf("系统提示词 [%s]> ", SYSTEM_PROMPT); fflush(stdout);
            char *in = read_line();
            if (in) { snprintf(SYSTEM_PROMPT, sizeof(SYSTEM_PROMPT), "%s", in ? in : ""); printf("%s[✓] 系统提示词已更新%s\n", GC, RS); modified = 1; }
            free(in); continue;
        }
        else if (!strncmp(input, "/ca", 3)) {
            free(input);
            char *arg = PEND_ARG;
            if (!arg) {
                printf("输入 CA 证书路径 (或直接回车清除)> "); fflush(stdout);
                arg = read_line();
            }
            if (arg && *arg) {
                snprintf(CA_BUNDLE, sizeof(CA_BUNDLE), "%s", arg);
                printf("%s[✓] CA 证书路径已设置为: %s%s\n", GC, CA_BUNDLE, RS);
                modified = 1;
            } else {
                CA_BUNDLE[0] = 0;
                printf("%s[✓] 已清除 CA 证书，将使用 -k 跳过验证%s\n", GC, RS);
                modified = 1;
            }
            free(arg); PEND_ARG = NULL;
            continue;
        }
        else if (!strcmp(input, "/conf")) { free(input); show_conf(); continue; }
        else if (!strcmp(input, "/confs")) { free(input); show_all_search_confs(); continue; }
        else if (!strcmp(input, "/tools")) {
            free(input);
            char *in = PEND_ARG ? PEND_ARG : read_line();
            if (in) {
                if (!strcmp(in, "on")) { TOOLS_ENABLED = 1; if (g_toolcache) { free(g_toolcache); g_toolcache = NULL; } printf("%s[✓] 工具已开启%s\n", GC, RS); modified = 1; }
                else { TOOLS_ENABLED = 0; if (g_toolcache) { free(g_toolcache); g_toolcache = NULL; } printf("%s[✓] 工具已关闭%s\n", GC, RS); modified = 1; }
            }
            free(in); PEND_ARG = NULL; continue;
        }
        else if (!strncmp(input, "/think", 6)) {
            free(input);
            char *in = PEND_ARG ? PEND_ARG : read_line();
            if (in) { THINK = (!strcmp(in, "off") || !strcmp(in, "0")) ? 0 : 1; printf("%s思考: %s%s\n", GC, THINK ? "on" : "off", RS); modified = 1; }
            free(in); PEND_ARG = NULL; continue;
        }
        else if (!strncmp(input, "/showthink", 10)) {
            free(input);
            char *in = PEND_ARG ? PEND_ARG : read_line();
            if (in) { SHOWTHINK = (!strcmp(in, "off") || !strcmp(in, "0")) ? 0 : 1; printf("%s显示思考: %s%s\n", GC, SHOWTHINK ? "on" : "off", RS); modified = 1; }
            free(in); PEND_ARG = NULL; continue;
        }

        /* === 普通对话 === */
        if (current_provider < 0) { printf("%s[!] 未选择 AI 提供商, 请先 /set%s\n", YL, RS); free(input); continue; }
        if (prov_conf[current_provider].num_keys == 0) { printf("%s[!] 未填 AI Key, 请 /key 设置%s\n", YL, RS); free(input); continue; }
        if (!prov_conf[current_provider].api_base[0]) { printf("%s[!] 未填 AI 服务地址, 请 /provider 设置%s\n", YL, RS); free(input); continue; }
        do_chat(input);
        free(input);
    }
    if (input) free(input);
    return 0;
}