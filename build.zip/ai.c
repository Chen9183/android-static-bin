/*
 * ai.c — 纯 C 单二进制 AI 对话客户端 (arm64 Android)
 * 内嵌 curl + jq，通过 memfd_create+execveat 从内存执行，零临时文件
 * 内置多个 AI 服务提供商，无配置时数字选择
 *
 * 构建:
 *   ld -r -b binary -o curl_embed.o curl
 *   ld -r -b binary -o jq_embed.o jq
 *   aarch64-linux-musl-gcc -static -O2 -o ai ai.c curl_embed.o jq_embed.o
 */
#define _GNU_SOURCE
#define __USE_GNU
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdarg.h>
#include <errno.h>
#include <sys/syscall.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <ctype.h>
#include <signal.h>
#include <termios.h>

extern const unsigned char _binary_curl_start[];
extern const unsigned char _binary_curl_end[];
extern const unsigned char _binary_jq_start[];
extern const unsigned char _binary_jq_end[];
extern const unsigned char _binary_toybox_start[];
extern const unsigned char _binary_toybox_end[];

#define CONF_FILE "ai.conf"
#define HIST_MAX 20

/* 流式中断: 回答时 Ctrl+C 置位, 不退出程序 */
volatile sig_atomic_t g_interrupt = 0;
volatile sig_atomic_t g_in_request = 0;
int g_stream_interrupted = 0;   /* 本次流式是否被 Ctrl+C 中断 */

#define GC "\033[32m"
#define CY "\033[36m"
#define YL "\033[33m"
#define MG "\033[35m"
#define RS "\033[0m"

/* 内置 AI 服务提供商 (统一走 OpenAI 兼容 /chat/completions) */
typedef struct {
    const char *name;
    const char *base;    /* 已含 API 版本前缀，程序拼 /chat/completions */
    const char *model;
} Provider;

static Provider providers[] = {
    {"OpenAI (gpt-4o-mini)",          "https://api.openai.com/v1",                                            "gpt-4o-mini"},
    {"DeepSeek (deepseek-chat)",      "https://api.deepseek.com/v1",                                          "deepseek-chat"},
    {"Kimi/Moonshot (v1-8k)",         "https://api.moonshot.cn/v1",                                           "moonshot-v1-8k"},
    {"Gemini (gemini-2.0-flash)",     "https://generativelanguage.googleapis.com/v1beta/openai",              "gemini-2.0-flash"},
    {"Claude/Anthropic (claude-3-haiku)", "https://api.anthropic.com/v1",                                    "claude-3-haiku-20240307"},
    {"通义千问/阿里 (qwen-turbo)",    "https://dashscope.aliyuncs.com/compatible-mode/v1",                     "qwen-turbo"},
    {"GLM/智谱 (glm-4-flash)",        "https://open.bigmodel.cn/api/paas/v4",                                 "glm-4-flash"},
    {"Groq (llama-3.3-70b)",          "https://api.groq.com/openai/v1",                                       "llama-3.3-70b-versatile"},
    {"Mistral (mistral-small)",       "https://api.mistral.ai/v1",                                            "mistral-small-latest"},
    {"自定义 (手动输入地址/模型)",    "",                                                                     ""},
};
#define NPROV ((int)(sizeof(providers)/sizeof(providers[0])))

/* 前向声明 (定义在下方) */
static char *read_line(void);
static char *jq_query(const char *filter, const char *json);

static char API_BASE[512]  = "";
static char API_KEY[512]   = "";
static char MODEL[128]     = "";
static char SYSTEM_PROMPT[1024] = "你是一个乐于助人的助手.请简洁而明了的输出";
static int  PROVIDER_IDX   = -1;
static int  THINK = 1;
static int  SHOWTHINK = 1;
static int  TOOLS_ENABLED = 1;   /* 工具开关: /tools on|off */
static char *PEND_ARG = NULL;   /* /cmd arg 一行式时暂存参数 */
static char *g_toolcache = NULL;      /* 工具说明文本缓存(模块级以支持开关重置) */
static char g_cut_name[128]={0}, g_cut_args[512]={0};   /* 上次被截断工具, 支持第二次给全量 */


typedef struct { char role[16]; char *content; } Msg;
static Msg hist[HIST_MAX];
static int hist_n = 0;

static int extract_json_val(const char *str, const char *key, char *buf, size_t bufsz);

static long sc_memfd_create(const char *name, unsigned int flags){
    return syscall(SYS_memfd_create, name, flags);
}

/* 通用: 从内存执行内嵌二进制, 可选注入 stdin, 捕获 stdout
 * argv 以 NULL 结尾; stdin_data 可为 NULL(不注入)
 * 返回 stdout 字节数, -1 失败; *out 需 free */
static long exec_embedded(const unsigned char *bs, const unsigned char *be,
                          const char *arg0, char **argv,
                          const char *stdin_data, ssize_t stdin_len, char **out){
    size_t cap = 65536, len = 0;
    char *buf = malloc(cap);
    int inpipe[2]= {-1,-1}, outpipe[2]= {-1,-1};
    if(!buf) return -1;

    if(pipe(outpipe)!=0){ free(buf); return -1; }
    if(stdin_data){
        if(pipe(inpipe)!=0){ close(outpipe[0]); close(outpipe[1]); free(buf); return -1; }
    }

    long fd = sc_memfd_create(arg0, 0);
    if(fd < 0){ close(outpipe[0]); close(outpipe[1]); if(stdin_data){close(inpipe[0]);close(inpipe[1]);} free(buf); return -1; }
    {
        size_t sz=(size_t)(be-bs), off=0;
        while(off<sz){
            ssize_t w=write((int)fd, bs+off, sz-off);
            if(w<=0){ close((int)fd); close(outpipe[0]);close(outpipe[1]); if(stdin_data){close(inpipe[0]);close(inpipe[1]);} free(buf); return -1; }
            off+=(size_t)w;
        }
    }

    pid_t pid = fork();
    if(pid<0){ close((int)fd); close(outpipe[0]);close(outpipe[1]); if(stdin_data){close(inpipe[0]);close(inpipe[1]);} free(buf); return -1; }

    if(pid==0){
        /* 子进程 */
        if(stdin_data){ dup2(inpipe[0],0); close(inpipe[0]); close(inpipe[1]); }
        else { int devnull=open("/dev/null",O_RDONLY); if(devnull>=0){ dup2(devnull,0); close(devnull);} }
        dup2(outpipe[1],1);
        dup2(outpipe[1],2);
        close(outpipe[0]); close(outpipe[1]);
        char *nargv[64];
        int i,n=0;
        nargv[n++]=(char*)arg0;
        for(i=0; argv && argv[i] && n<62; i++) nargv[n++]=argv[i];
        nargv[n]=NULL;
        const char *envp[] = {
            "PATH=/system/bin:/data/bin:/usr/bin:/bin",
            "HOME=/data/local/tmp",
            "SSL_CERT_FILE=",
            "LANG=C", "LC_ALL=C", NULL
        };
        syscall(SYS_execveat, (int)fd, "", nargv, envp, AT_EMPTY_PATH);
        _exit(127);
    }

    /* 父进程: 注入 stdin, 读 stdout */
    if(stdin_data){
        close(inpipe[0]);
        ssize_t total=0;
        while(total < stdin_len){
            ssize_t w=write(inpipe[1], stdin_data+total, stdin_len-total);
            if(w<=0) break;
            total+=w;
        }
        close(inpipe[1]);
    }
    close(outpipe[1]);
    {
        ssize_t r;
        while((r=read(outpipe[0], buf+len, cap-len-1))>0){
            len+=r;
            if(len+4096>=cap){ cap*=2; char *nb=realloc(buf,cap); if(!nb){ close(outpipe[0]); close((int)fd); while(waitpid(pid,NULL,0)!=-1){} free(buf); return -1;} buf=nb; }
        }
    }
    close(outpipe[0]);
    close((int)fd);
    while(waitpid(pid, NULL, 0) != -1){}
    buf[len]=0;
    *out=buf;
    return (long)len;
}

#define exec_curl(argv,out)  exec_embedded(_binary_curl_start,_binary_curl_end,"curl",(argv),NULL,0,(out))
#define exec_jq_stdin(argv,json,out) exec_embedded(_binary_jq_start,_binary_jq_end,"jq",(argv),(json),(ssize_t)strlen(json),(out))

#define exec_toybox_sh(argv,out) exec_embedded(_binary_toybox_start,_binary_toybox_end,"toybox",(argv),NULL,0,(out))

/* 从 JSON 对象串里按 key 提取字符串值 (复用 extract_json_val 定义之后的封装;
   这里假定 extract_json_val 在后面, 所以只声明, 工具调用时才用) */
/* 带超时+截断的 shell 执行: 用内嵌 toybox sh -c cmd, 返回 stdout(malloc), 失败NULL */
static char *run_shell_timed(const char *cmd, long timeout_ms, long out_cap){
    char *argv[]={"sh","-c",(char*)cmd,NULL};
    char *raw=NULL;
    long n = exec_toybox_sh(argv,&raw);
    if(n<0 || !raw) return NULL;
    if(out_cap>0 && n>(long)out_cap){ raw[out_cap-1]=0; }
    return raw;
}

/* 用内置 curl 生成的 system prompt 提示信息里常用的几个工具: time/date */
static char *tool_time_now(void){
    char *argv[]={"date","+%Y-%m-%d %H:%M:%S %Z (Asia/Shanghai)",NULL};
    char *raw=NULL;
    if(exec_toybox_sh(argv,&raw)<0 || !raw){ if(raw)free(raw); return strdup("(无法读取本地时间)"); }
    /* 去掉末尾换行 */
    size_t l=strlen(raw); while(l && (raw[l-1]=='\n'||raw[l-1]=='\r')) raw[--l]=0;
    char *r=strdup(raw); free(raw);
    return r?r:strdup("(时间错误)");
}

/* 转义最小的 HTML 实体解码用于标题/摘要显示 */
static void html_decode(char *s){
    char *r=s, *w=s;
    while(*r){ if(*r=='&'){ if(!strncmp(r,"&amp;",5)){*w++='&';r+=5;continue;} if(!strncmp(r,"&lt;",4)){*w++='<';r+=4;continue;} if(!strncmp(r,"&gt;",4)){*w++='>';r+=4;continue;} if(!strncmp(r,"&quot;",6)){*w++='"';r+=6;continue;} if(!strncmp(r,"&#39;",5)){*w++='\'';r+=5;continue;} if(!strncmp(r,"&nbsp;",6)){*w++=' ';r+=6;continue;} } *w++=*r++; }
    *w=0;
}
/* 去掉一段里的所有 HTML 标签 */
static void strip_tags(char *s){
    char *r=s,*w=s; int in=0;
    while(*r){ if(*r=='<'){ in=1; r++; continue; } if(*r=='>'){ in=0; r++; continue; } if(!in){ *w++=*r; } r++; }
    *w=0;
    /* 压缩多余空白 */
    char *a=s,*b=s; int spc=0;
    while(*a){ if(*a==' '||*a=='\t'||*a=='\n'||*a=='\r'){ if(!spc){*b++=' '; spc=1;} } else { spc=0; *b++=*a; } a++; }
    *b=0;
    while(b>s && (*(b-1)==' ')){ *(--b)=0; }
}
static void strip_spaces(char *s){ /* 字段内清理 */ }

/* bing 搜索: 用内置 curl 抓 cn.bing.com, 解析出前几条 标题|URL|摘要 */
/* 简单 URL 编码(空格->+, 保留字母数字和部分符号) */
static void urlencode(const char *in, char *out, size_t outsz){
    size_t o=0;
    for(const char*p=in;*p && o+4<outsz;p++){
        unsigned char c=(unsigned char)*p;
        if((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='-'||c=='_'||c=='.'||c=='~'){ out[o++]=c; }
        else if(c==' '){ out[o++]='+'; }
        else { out[o++]='%'; const char*h="0123456789ABCDEF"; out[o++]=h[(c>>4)&15]; out[o++]=h[c&15]; }
    }
    out[o]=0;
}
static char *tool_bing_search(const char *q){
    char cookie[400];
    snprintf(cookie,sizeof(cookie),
        "SRCHHPGUSR=SRCHLANG=zh-Hans&SRCHD=AF=NOFORM&SRCHUID=V=2&GUID=&dmemc=1; _EDGE_S=mkt=zh-cn");
    char url[2048];
    { char qe[1400]; urlencode(q, qe, sizeof(qe)); snprintf(url,sizeof(url),
        "https://cn.bing.com/search?setlang=zh-CN&q=%s", qe); }
    char *ard[]={"-s","-L","-m","15",
                 "-A","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0 Safari/537.36 Edg/120.0",
                 "-H","Accept-Language: zh-CN,zh;q=0.9",
                 "-H","Accept: text/html,application/xhtml+xml",
                 "--cookie",cookie,
                 url,NULL};
    char *html=NULL;
    if(exec_curl(ard,&html)<0 || !html){ if(html)free(html); return strdup("(搜索失败: 无法访问必应搜索) "); }
    size_t hl=strlen(html);
    char *buf=malloc(hl+4096); if(!buf){ free(html); return strdup("(内存不足) "); }
    size_t bl=0; int cnt=0;
    const char *p=html;
    while(cnt<6){
        const char *li = strstr(p, "<li class=\"b_algo\"");
        if(!li) break;
        const char *lie = strstr(li, "</li>");
        if(!lie) break;
        const char *h2 = strstr(li, "<h2");
        char url[700]="", title[500]="";
        if(h2 && h2<lie){
            const char *href = strstr(h2, "href=\"");
            if(href && href<lie){ href+=6; const char *he=strchr(href,'"'); if(he && he<lie){ size_t u=he-href; if(u>680)u=680; memcpy(url,href,u); url[u]=0; } }
            const char *aclose = strstr(h2, "</a>");
            if(aclose && aclose<lie){ const char *nh2 = strchr(h2,'>'); if(nh2){ const char *t0=nh2+1; if(t0<aclose){ size_t t=aclose-t0; if(t>650)t=650; char*tmp=malloc(t+1); if(tmp){ memcpy(tmp,t0,t); tmp[t]=0; strip_tags(tmp); html_decode(tmp); strip_tags(tmp); snprintf(title,sizeof(title),"%s",tmp); free(tmp); } } } }
        }
        char snip[700]="";
        const char *cap = strstr(li, "b_caption");
        if(cap && cap<lie){
            const char *sp = strstr(cap, "<p");
            if(sp && sp<lie){ const char *sclose=strstr(sp,"</p>"); if(sclose && sclose<lie+6000){ const char *gt=strchr(sp,'>'); if(gt&&gt<sclose){ size_t t=sclose-gt-1; if(t>680)t=680; char*tmp=malloc(t+1); if(tmp){ memcpy(tmp,gt+1,t); tmp[t]=0; strip_tags(tmp); html_decode(tmp); strip_tags(tmp); snprintf(snip,sizeof(snip),"%s",tmp); free(tmp);} } } }
        }
        int used = snprintf(buf+bl, hl+4096-(size_t)bl,
                   "%d. %s%s%s%s%s\n",
                   cnt+1, title[0]?title:"(无标题)",
                   url[0]?"\n   链接: ":"", url,
                   snip[0]?"\n   摘要: ":"", snip);
        if(used>0 && (size_t)used < hl+4096-(size_t)bl) bl += (size_t)used;
        cnt++;
        p = lie + 5;
    }
    free(html);
    if(!bl){ free(buf); return strdup("(搜索无结果, 或页面被拦截) "); }
    char *out=realloc(buf, bl+1); if(!out){ free(buf); return strdup("(合并失败)"); }
    out[bl]=0;
    return out;
}
/* 用内置 curl 下载文件到本地路径 */
static char *tool_curl_download(const char *url, const char *path){
    char *argv[]={"-s","-L","--connect-timeout","15","-m","60",
                  "-o",(char*)path,(char*)url,NULL};
    char *out=NULL;
    long n = exec_curl(argv,&out);
    if(n<0 || !out){ if(out)free(out); return strdup("(下载失败: 无法访问该地址)"); }
    free(out);
    /* 验证文件大小 */
    char *argv2[]={"sh","-c",NULL,NULL};
    char szcmd[512]; snprintf(szcmd,sizeof(szcmd),"wc -c < '%s' 2>/dev/null", path);
    argv2[3]=szcmd;
    char *sz=NULL;
    if(exec_toybox_sh(argv2,&sz)<0 || !sz){ if(sz)free(sz); return strdup("(下载完成但无法读取大小)"); }
    size_t l=strlen(sz); while(l && (sz[l-1]<' ')) sz[--l]=0;
    char *r=malloc(strlen(path)+64); if(!r){free(sz); return strdup("(内存)"); }
    snprintf(r,strlen(path)+64,"(已下载到 %s, 大小 %s 字节)", path, sz[0]?sz:"?");
    free(sz);
    return r;
}

/* 工具分发: args_json 形如 {"cmd":"...","timeout":8000,...}; 返回结果字符串(malloc) */
static char *run_tool(const char *name, const char *args_json){
    char *res=NULL;
    if(!strcmp(name,"bing_search")){
        char q[1200]={0};
        /* 目标: {"query":"..."} 或 {"q":"..."} */
        extract_json_val(args_json,"\"query\":",q,sizeof(q));
        if(!q[0]) extract_json_val(args_json,"\"q\":",q,sizeof(q));
        if(!q[0]) strncpy(q,"(空查询)",sizeof(q)-1);
        res = tool_bing_search(q);
    }
    else if(!strcmp(name,"run_shell")){
        char cmd[4096]={0};
        extract_json_val(args_json,"\"cmd\":",cmd,sizeof(cmd));
        if(!cmd[0]){ return strdup("(run_shell 缺少 cmd 参数)"); }
        long ms=15000, cap=6000;
        char tv[64];
        if(extract_json_val(args_json,"\"timeout\":",tv,sizeof(tv))) ms=strtol(tv,NULL,10);
        char cv[64];
        if(extract_json_val(args_json,"\"timeout\":",cv,sizeof(cv))) cap=strtol(cv,NULL,10);
        res = run_shell_timed(cmd, ms, cap);
        if(!res) res = strdup("(命令执行失败) ");
    }
    else if(!strcmp(name,"curl_download")){
        char url[2048]={0}, path[1200]={0};
        extract_json_val(args_json,"\"url\":",url,sizeof(url));
        extract_json_val(args_json,"\"path\":",path,sizeof(path));
        if(!url[0]) return strdup("(curl_download 缺少 url) ");
        if(!path[0]) snprintf(path,sizeof(path),"%s","/data/local/tmp/ai_work/download.bin");
        res = tool_curl_download(url,path);
    }
    else if(!strcmp(name,"time_now")){
        res = tool_time_now();
    }
    else {
        char tmp[128]; snprintf(tmp,sizeof(tmp),"(未知工具: %s)", name);
        res = strdup(tmp);
    }
    return res;
}

/* ---------- 工具调用解析与执行 ----------
   协议(纯 ASCII): AI 需要联网/执行命令时, 在回复中输出:
     [[TOOL]] {"name":"工具名","args":{...}} [[/TOOL]]
   do_chat 检测到该标记即执行工具, 并把结果写回历史继续对话。*/
static char *build_tools_usage_text(void){
    return strdup(
        "你可以调用系统工具来增强能力(联网搜索/执行命令/下载文件/取时间)。"
        "当用户需要这些能力时, 不要编造数据, 而是输出一行工具调用。"
        "\n[硬性规则: 工具调用格式] 你必须严格遵守以下格式, 这是强制要求:\n"
        "1. 用 [[TOOL]] 和 [[/TOOL]] 包裹, 两者各占一行, 工具 JSON 放在中间单独一行:\n"
        "   [[TOOL]]\n"
        "   {\"name\":\"工具名\",\"args\":{...}}\n"
        "   [[/TOOL]]\n"
        "2. 工具 JSON 必须使用标准 JSON: 键和字符串用半角双引号(不要单引号、不要中文引号)、键值之间用英文冒号、相邻字段用英文逗号、键值两侧不要多余空格。\n"
        "3. 格式不标准(漏包裹符/用单引号/中文引号/多余空行/字段缺引号)会导致调用失败。\n"
        "4. 一次只调一个工具, 调用后立即继续你的回答, 不要自己模拟工具结果。\n"
        "5. args 必须为对象, 内部传该工具要求的参数键。\n"
        "可用工具(精确格式示例):\n"
        "- 联网搜索:  \"name\":\"bing_search\", args 传 {\"query\":\"搜索词\"}\n"
        "- 执行shell命令(root环境):  \"name\":\"run_shell\", args 传 {\"cmd\":\"命令\",\"timeout\":毫秒}\n"
        "- 下载文件:  \"name\":\"curl_download\", args 传 {\"url\":\"地址\",\"path\":\"保存路径\"}\n"
        "- 获取当前时间:  \"name\":\"time_now\", args 传 {} (空对象)\n"
    );
}

/* 在 content 中查找工具调用, 返回从 { 到匹配 } 的 JSON(malloc); 未找到返回 NULL */
/* 截断工具结果, 省 token; 同一工具+args 第二次调用给全量。 */
#define MAX_TOOL_RESULT 1200
static char *tool_result_trim(const char *name, const char *args, const char *r){
    if(!r) return NULL;
    size_t l = strlen(r);
    if(l <= MAX_TOOL_RESULT) return strdup(r);
    int repeat = g_cut_name[0] && name && !strcmp(name,g_cut_name)
                 && (!g_cut_args[0] || (args && !strcmp(args,g_cut_args)));
    if(repeat){
        g_cut_name[0]=0; g_cut_args[0]=0;
        return strdup(r);
    }
    if(name) snprintf(g_cut_name,sizeof(g_cut_name),"%s",name);
    if(args) snprintf(g_cut_args,sizeof(g_cut_args),"%s",args);
    char *out = malloc(MAX_TOOL_RESULT + 96);
    if(!out) return NULL;
    memcpy(out, r, MAX_TOOL_RESULT);
    snprintf(out + MAX_TOOL_RESULT, 96, "\n...(结果已截断 %zu 字节; 如需完整内容请再次调用本工具[第二次必给全量])", l);
    return out;
}

static int has_tool_marker(const char*c);   /* fwd */
static char *find_tool_call(const char *content){
    const char *op = NULL;
    if(content){
        static const char *mk[]={"[[TOOL]]","[[tool]]","[[Tool]]","[TOOL]","[tool]","(TOOL)","[[TOOL_CALL]]","[[TOOLCALL]]","<<TOOL>>",0};
        const char *best=NULL;
        for(int i=0;mk[i];i++){ const char*h=strstr(content,mk[i]); if(h && (!best || h<best)) best=h; }
        op = best;
    }
    const char *open_brace;
    if(op){
        open_brace = strchr(op, '{');
    } else {
        /* 无包裹标记: 仅当明显是工具调用(含已知工具名 + name: + args:) 才提取, 避免误执行普通文本 */
        if(!has_tool_marker(content)) return NULL;
        open_brace = strchr(content, '{');
    }
    if(!open_brace) return NULL;
    const char *cl = open_brace;
    int depth=0;
    while(*cl){ if(*cl=='{') depth++; else if(*cl=='}'){ depth--; if(depth==0){ cl++; break; } } cl++; }
    if(depth!=0) return NULL;
    size_t L = (size_t)(cl-open_brace);
    if(L<4 || L>4000) return NULL;
    char *t = malloc(L+1); if(!t) return NULL;
    memcpy(t, open_brace, L); t[L]=0;
    if(!op){
        /* 无包裹提取: 校验其中确有工具调用(name + args), 否则视为误判丢弃 */
        char nm[64];
        if(!extract_json_val(t, "\"name\":", nm, sizeof(nm)) || !nm[0]){
            free(t); return NULL;
        }
    }
    return t;
}

/* 解析 tool JSON 并执行, 返回结果串(malloc) */
static char *execute_tool_call(const char *tool_json){
    if(!TOOLS_ENABLED)
        return strdup("(工具已被 /tools off 禁用, 如需继续请先输入 /tools on)");
    char name[128]={0};
    extract_json_val(tool_json, "\"name\":", name, sizeof(name));
    if(!name[0]) return strdup("(工具解析失败: 无 name 字段)");
    char *args_json = NULL;
    const char *args = strstr(tool_json, "\"args\"");
    if(args){ const char *ab = strchr(args, '{'); if(ab){ const char *ae=ab; int d=0;
        while(*ae){ if(*ae=='{') d++; else if(*ae=='}'){ d--; if(d==0){ ae++; break; } } ae++; }
        if(d==0 && ae>ab){ args_json=malloc((size_t)(ae-ab)+1); if(args_json){ memcpy(args_json,ab,(size_t)(ae-ab)); args_json[ae-ab]=0; } }
    } }
    char *raw = run_tool(name, args_json?args_json:"{}");
    char *r = tool_result_trim(name, args_json?args_json:"", raw);
    free(raw);
    free(args_json);
    return r;
}

/* content 是否含工具调用标记 */
static int has_tool_marker(const char *c){
    /* 识别多种包裹变体, 兼容模型偶尔写错的大小写/括号 */
    static const char *mk[]={
        "[[TOOL]]","[[tool]]","[[Tool]]","[TOOL]","[tool]","(TOOL)","[[TOOL_CALL]]","[[TOOLCALL]]","<<TOOL>>",0};
    if(!c) return 0;
    for(int i=0;mk[i];i++) if(strstr(c,mk[i])) return 1;
    /* 宽松: 出现 {"name":"..."} 且与 args 且含 run_shell/bing_search/curl_download/time_now 之一 */
    if(strstr(c,"run_shell")||strstr(c,"bing_search")||strstr(c,"curl_download")||strstr(c,"\"name\":\"time_now\""))
        if(strstr(c,"\"name\":") && strstr(c,"\"args\":") ) return 1;
    return 0;
}
static int content_has_tool(const char *content){
    return has_tool_marker(content);
}



/* 用 jq 查询: filter 如 `.choices[0].message.content`, json 为完整响应
 * 返回动态字符串(已 -r 解转义), 失败返回 NULL */
static char *jq_query(const char *filter, const char *json){
    char *args[8];
    int n=0;
    args[n++]="-r";
    args[n++]=(char*)filter;
    args[n++]=NULL;
    char *out=NULL;
    long rc = exec_jq_stdin(args, json, &out);
    if(rc < 0){ free(out); return NULL; }
    /* 去掉尾部换行 */
    if(out && *out){
        char *p=out+strlen(out);
        while(p>out && (p[-1]=='\n'||p[-1]=='\r')) *--p=0;
    }
    return out;
}

/* ---------- HTTP POST (OpenAI 兼容) ---------- */
static int http_post_json(const char *url, const char *auth, const char *body, char **out){
    char *args[64];
    int n=0;
    args[n++]="-s";
    args[n++]="-S";
    args[n++]="-k";                       /* Android 无 CA 目录, 跳过证书校验 */
    args[n++]="--dns-servers";
    args[n++]="223.5.5.5,119.29.29.29,114.114.114.114,180.76.76.76,8.8.8.8,1.1.1.1";  /* Android 无 resolv.conf */
    args[n++]="--max-time";
    args[n++]="300";
    args[n++]="-X";
    args[n++]="POST";
    args[n++]="-H";
    {
        static char h1[700]; snprintf(h1,sizeof(h1),"Content-Type: application/json"); args[n++]=h1;
    }
    args[n++]="-H";
    {
        static char h2[700]; snprintf(h2,sizeof(h2),"Authorization: Bearer %s", auth); args[n++]=h2;
    }
    args[n++]="--data";
    args[n++]=(char*)body;
    args[n++]=(char*)url;
    args[n++]=NULL;

    char *resp=NULL;
    long len = exec_curl(args, &resp);
    if(len < 0){ *out=NULL; return -1; }
    *out = resp;
    return 0;
}

/* ---------- HTTP GET (拉取模型列表) ---------- */
static int http_get_json(const char *url, const char *auth, char **out){
    char *args[64];
    int n=0;
    args[n++]="-s";
    args[n++]="-S";
    args[n++]="-k";
    args[n++]="--dns-servers";
    args[n++]="223.5.5.5,119.29.29.29,114.114.114.114,180.76.76.76,8.8.8.8,1.1.1.1";
    args[n++]="--max-time";
    args[n++]="60";
    args[n++]="-H";
    {
        static char h2[700]; snprintf(h2,sizeof(h2),"Authorization: Bearer %s", auth); args[n++]=h2;
    }
    args[n++]=(char*)url;
    args[n++]=NULL;

    char *resp=NULL;
    long len = exec_curl(args, &resp);
    if(len < 0){ *out=NULL; return -1; }
    *out = resp;
    return 0;
}

/* ---------- 拉取并选择模型 (OpenAI 兼容 GET /models) ----------
 * 成功后写入全局 MODEL。auth 为 API KEY。 */
static int pick_model(const char *auth){
    if(!auth || !*auth){ printf("%s[!] 无 Key, 无法拉取模型列表%s\n", YL, RS); return -1; }

    char url[1024];
    size_t bl = strlen(API_BASE);
    if(bl && API_BASE[bl-1]=='/') snprintf(url,sizeof(url), "%smodels", API_BASE);
    else                            snprintf(url,sizeof(url), "%s/models", API_BASE);

    char *resp=NULL;
    printf("%s[拉取模型列表…]%s ", CY, RS); fflush(stdout);
    if(http_get_json(url, auth, &resp)!=0 || !resp){
        printf("\n%s[!] 拉取模型失败: %s%s\n", YL, strerror(errno), RS);
        free(resp); return -1;
    }
    printf("\n");

    char *err = jq_query(".error.message", resp);
    if(err && *err && strcmp(err,"null")){
        printf("%s[!] API错误: %s%s\n", YL, err, RS);
        free(err); free(resp); return -1;
    }
    free(err);

    char *list = jq_query(".data[].id", resp);
    if(!list || !*list){
        printf("%s[!] 未解析到模型.web原始:%.300s%s\n", YL, resp, RS);
        free(list); free(resp); return -1;
    }

    size_t cap=32, cnt=0;
    char **id = malloc(cap*sizeof(char*));
    if(!id){ free(list); free(resp); return -1; }
    char *tok = strtok(list, "\n");
    while(tok && cnt<64){
        if(cnt+1>=cap){ cap*=2; char**ni=realloc(id,cap*sizeof(char*)); if(!ni)break; id=ni; }
        id[cnt++]=strdup(tok);
        tok = strtok(NULL, "\n");
    }
    if(cnt==0){ printf("%s[!] 模型列表为空%s\n", YL, RS); free(list); free(resp); free(id); return -1; }

    printf("%s请选择模型 (共%d个):%s\n", CY, cnt, RS);
    int show = cnt<40?cnt:40;
    int i;
    for(i=0;i<show;i++) printf("  %s%d%s  %s\n", MG, i+1, RS, id[i]);
    if(cnt>show) printf("  ... 目前显示前 %d 个\n", show);
    printf("输入数字 [1-%d] (0=跳过)> ", cnt); fflush(stdout);
    char *in = read_line();
    if(in && *in){
        int sel = atoi(in)-1;
        if(sel>=0 && sel<cnt){
            snprintf(MODEL, sizeof(MODEL), "%s", id[sel]);
            printf("%s已选择模型: %s%s\n", GC, MODEL, RS);
        } else if(sel==-1){
            printf("%s[跳过, 保留当前: %s]%s\n", YL, *MODEL?MODEL:"-", RS);
        } else {
            printf("%s[!] 输入无效%s\n", YL, RS);
        }
    } else {
        printf("%s[跳过]%s\n", YL, RS);
    }
    free(in);
    for(i=0;i<cnt;i++) free(id[i]);
    free(id); free(list); free(resp);
    return 0;
}


/* ---------- JSON 字符串还原转义 ---------- */
static void json_unescape(const char *in, char *out, size_t outsz){
    size_t o=0;
    for(; *in && o+1<outsz; in++){
        if(*in=='\\'){
            in++;
            switch(*in){
                case 'n': out[o++]='\n'; break;
                case 'r': out[o++]='\r'; break;
                case 't': out[o++]='\t'; break;
                case 'b': out[o++]='\b'; break;
                case 'f': out[o++]='\f'; break;
                case '\\': out[o++]='\\'; break;
                case '"': out[o++]='"'; break;
                case '/': out[o++]='/'; break;
                case 'u':{
                    unsigned v=0; int k;
                    for(k=1;k<=4 && in[k];k++){
                        char c=in[k]; unsigned d=0;
                        if(c>='0'&&c<='9') d=c-'0';
                        else if(c>='a'&&c<='f') d=c-'a'+10;
                        else if(c>='A'&&c<='F') d=c-'A'+10;
                        else break;
                        v=(v<<4)|d;
                    }
                    if(k>4){ /* 基本多语言平面 BMP, 简单 UTF-8 编码 */
                        if(v<0x80) out[o++]=(char)v;
                        else if(v<0x800){ out[o++]=(char)(0xC0|(v>>6)); out[o++]=(char)(0x80|(v&0x3F)); }
                        else { out[o++]=(char)(0xE0|(v>>12)); out[o++]=(char)(0x80|((v>>6)&0x3F)); out[o++]=(char)(0x80|(v&0x3F)); }
                        in+=3; /* 跳过 \uXXXX 的 4 个字符 */
                    }
                    break;
                }
                default: out[o++]='\\'; break;
            }
        } else {
            out[o++]=*in;
        }
    }
    out[o]=0;
}

/* 从一行 SSE: 提取 key 对应的字符串值(JSON 形式, 含可能转义)。
 * 在 str 中找 `"key":"` 之后直到未转义引号为止的子串, 写入 buf。 */
static int extract_json_val(const char *str, const char *key, char *buf, size_t bufsz){
    /* 宽松版: 容忍 "name":"v" / "name" : "v" / name : v / name:'v' / name:v 等形态 */
    if(!str||!key||!buf||bufsz==0){ if(buf&&bufsz) buf[0]=0; return 0; }
    buf[0]=0;
    /* --- 从 key 剥离出纯字段名 --- */
    const char *kk=key;
    while(*kk==' '||*kk=='"') kk++;            /* 跳前导引号/空格 */
    const char *fstart=kk;
    while(*kk && *kk!='"' && *kk!=':' && *kk!=' ') kk++;
    size_t fnlen=(size_t)(kk-fstart);
    while(fnlen>0 && (fstart[fnlen-1]==' '||fstart[fnlen-1]=='"')) fnlen--;
    if(fnlen==0 || fnlen>120) return 0;
    /* --- 在 str 中定位字段名(要求其后->空白->:) --- */
    const char *p=str;
    while((p=strchr(p, fstart[0]))){
        if(strncmp(p, fstart, fnlen)!=0){ p++; continue; }
        /* 确认 p 前不是字母数字下划线(避免子串误匹配, 如 content 匹配 event后面的tent) */
        if(p>str){ char c0=p[-1]; if((c0>='a'&&c0<='z')||(c0>='A'&&c0<='Z')||(c0>='0'&&c0<='9')||c0=='_'){ p++; continue; } }
        const char *q=p+fnlen;
        if(*q=='"') q++;                 /* 跳闭合引号: "name" */
        while(*q==' '||*q=='\t') q++;
        if(*q==':'){
            q++;
            while(*q==' '||*q=='\t') q++;
            /* --- 解析值 --- */
            size_t o=0;
            if(*q=='"'){
                q++;
                while(*q && o+1<bufsz){
                    if(*q=='\\'){
                        q++;
                        if(*q=='n'){ buf[o++]='\n'; q++; }
                        else if(*q=='t'){ buf[o++]='\t'; q++; }
                        else if(*q=='r'){ buf[o++]='\r'; q++; }
                        else if(*q=='u'){ q++; /* 粗略: 跳4位hex */ if(*q)q++; if(*q)q++; if(*q)q++; if(*q)q++; }
                        else if(o+1<bufsz && *q){ buf[o++]=*q; q++; }
                    } else if(*q=='"'){
                        buf[o]=0; return 1;
                    } else {
                        buf[o++]=*q++;
                    }
                }
                buf[o]=0; return 1;
            } else if(*q=='\''){
                q++;
                while(*q && o+1<bufsz){
                    if(*q=='\\'){ if(o+2<bufsz){ buf[o++]=*q++; if(*q){buf[o++]=*q++;} } else break; }
                    else if(*q=='\''){ buf[o]=0; return 1; }
                    else { buf[o++]=*q++; }
                }
                buf[o]=0; return 1;
            } else {
                /* 裸 token: 到 , } 空白 为止 */
                while(*q && *q!=',' && *q!='}' && *q!=' ' && *q!='\t' && *q!='\n' && o+1<bufsz){
                    if(*q=='\\'){ if(o+2<bufsz){ buf[o++]=*q++; if(*q){buf[o++]=*q++;} } else break; }
                    else buf[o++]=*q++;
                }
                buf[o]=0; return 1;
            }
        }
        p++;
    }
    return 0;
}

static char *buf_append(char *b, size_t *len, size_t *cap, const char *s){
    size_t add = strlen(s);
    if(*len+add+1 >= *cap){ while(*len+add+1>=*cap) (*cap)*=2; char*n=realloc(b,*cap); if(!n) return b; b=n; }
    memcpy(b+*len, s, add); *len+=add; b[*len]=0;
    return b;
}

/* ---------- 流式对话: 请求 + 边收边打 + 返回累计正文 ----------
 * 返回 malloc 的正文(content), 失败返回 NULL。思考在 SHOWTHINK 时显示。
 */
static char *chat_stream(const char *url, const char *auth, const char *body){
    /* curl 参数: 启用流式 */
    char *args[64];
    int n=0;
    args[n++]="-s";
    args[n++]="-S";
    args[n++]="-k";
    args[n++]="--dns-servers";
    args[n++]="223.5.5.5,119.29.29.29,114.114.114.114,180.76.76.76,8.8.8.8,1.1.1.1";
    args[n++]="-N";                    /* 禁用缓冲, 实时输出 */
    args[n++]="--no-buffer";
    if(strstr(body,"\"stream\":true")){
        args[n++]="--max-time"; args[n++]="600";
    } else {
        args[n++]="--max-time"; args[n++]="300";
    }
    args[n++]="-X"; args[n++]="POST";
    args[n++]="-H";
    { static char h1[700]; snprintf(h1,sizeof(h1),"Content-Type: application/json"); args[n++]=h1; }
    args[n++]="-H";
    { static char h2[700]; snprintf(h2,sizeof(h2),"Authorization: Bearer %s", auth); args[n++]=h2; }
    args[n++]="--data"; args[n++]=(char*)body;
    args[n++]=(char*)url;
    args[n++]=NULL;

    /* memfd 子进程 */
    int outpipe[2];
    if(pipe(outpipe)!=0) return NULL;
    long fd = sc_memfd_create("curl", 0);
    if(fd < 0){ close(outpipe[0]); close(outpipe[1]); return NULL; }
    {
        const unsigned char *bs=_binary_curl_start, *be=_binary_curl_end;
        size_t sz=(size_t)(be-bs), off=0;
        while(off<sz){
            ssize_t w=write((int)fd, bs+off, sz-off);
            if(w<=0){ close((int)fd); close(outpipe[0]);close(outpipe[1]); return NULL; }
            off+=(size_t)w;
        }
    }
    pid_t pid = fork();
    if(pid<0){ close((int)fd); close(outpipe[0]);close(outpipe[1]); return NULL; }
    if(pid==0){
        int devnull=open("/dev/null",O_RDONLY); if(devnull>=0){ dup2(devnull,0); close(devnull);}
        dup2(outpipe[1],1);
        dup2(outpipe[1],2);
        close(outpipe[0]); close(outpipe[1]);
        char *nargv[64]; int i,c=0;
        nargv[c++]=(char*)"curl";
        for(i=0; args && args[i] && c<62; i++) nargv[c++]=args[i];
        nargv[c]=NULL;
        const char *envp[]={"PATH=/system/bin:/data/bin:/usr/bin:/bin","HOME=/data/local/tmp","SSL_CERT_FILE=","LANG=C","LC_ALL=C",NULL};
        syscall(SYS_execveat, (int)fd, "", nargv, envp, AT_EMPTY_PATH);
        _exit(127);
    }
    close(outpipe[1]);

    size_t linelen=0, linecap=8192;
    char *line=malloc(linecap); if(!line){ close(outpipe[0]); close((int)fd); while(waitpid(pid,NULL,0)!=-1){} return NULL; }
    size_t ccap=32768, clen=0;
    char *content=malloc(ccap); if(!content){ free(line); close(outpipe[0]); close((int)fd); while(waitpid(pid,NULL,0)!=-1){} return NULL;} content[0]=0;
    size_t scored=0;  /* 已打印内容的行累计, 用于判定 delta */
    int printed_any=0;
    int printing_content=0;

    /* 思考与正文的解析缓存 */
    char tmp[8192];
    char block_started=0;
    char rblock=0;   /* 是否正在积累思考 */
    char content_started=0; /* 正文是否已开始流式输出 */
    const char *spin="/-\\|"; int spin_i=0, spin_shown=0; /* 思考加载动画 */
    size_t rcap=32768, rlen=0;
    char *reason=malloc(rcap); if(!reason){ free(content); free(line); close(outpipe[0]); close((int)fd); while(waitpid(pid,NULL,0)!=-1){} return NULL;} reason[0]=0;

    ssize_t r; int interrupted=0;
    while(1){
        if(g_interrupt){ interrupted=1; break; }
        r=read(outpipe[0], tmp, sizeof(tmp));
        if(r<0){ if(errno==EINTR) continue; else break; }
        if(r==0) break;
        {
        size_t i;
        for(i=0;i<(size_t)r;i++){
            char ch = tmp[i];
            if(ch=='\n'){
                line[linelen]=0;
                /* 处理一行 SSE */
                if(strncmp(line,"data:",5)==0){
                    const char *js = line+5;
                    while(*js==' ') js++;
                    if(strncmp(js,"[DONE]",6)==0){ /* 流结束 */ }
                    else {
                        char v[8192];
                        /* 思考增量 */
                        if(extract_json_val(js,"\"reasoning_content\":",v,sizeof(v))){
                            char dec[8192]; json_unescape(v,dec,sizeof(dec));
                            /* JSON 空值字面量(null/空串/空对象/空数组)当作无思考 */
                            if(dec[0]=='n'&&strcmp(dec,"null")==0) dec[0]=0;
                            else if(dec[0]=='{'&&dec[1]=='}') dec[0]=0;
                            else if(dec[0]=='['&&dec[1]==']') dec[0]=0;
                            if(!rblock && SHOWTHINK && *dec){
                                /* 显示真正的思考内容前, 先清掉隐藏思考时的加载动画标 */
                                if(spin_shown){ printf("\r\x1b[K"); fflush(stdout); spin_shown=0; }
                                printf("%s┬─ 思考 %s\n",MG,RS); fflush(stdout);
                                rblock=1;
                            }
                            if(rblock && *dec && !content_started){
                                if(spin_shown){ printf("\r\x1b[K"); fflush(stdout); spin_shown=0; }
                                printf("%s%s",MG,dec); fflush(stdout);
                            }
                            else if(!content_started){
                                /* 隐藏思考: 显示动态加载动画 */
                                if(!spin_shown){
                                    printf("%s[思考中 ]%s",YL,RS); fflush(stdout);
                                    spin_shown=1;
                                } else {
                                    printf("\b%c", spin[spin_i++ & 3]); fflush(stdout);
                                }
                            }
                            {
                                char*du=strdup(dec);
                                if(du){ reason=buf_append(reason,&rlen,&rcap,du); free(du); }
                            }
                        }
                        /* 正文增量 */
                        if(extract_json_val(js,"\"content\":",v,sizeof(v))){
                            char dec[8192]; json_unescape(v,dec,sizeof(dec));
                            /* JSON 空值字面量(null/空串/空对象/空数组)当作无正文增量 */
                            if(dec[0]=='n'&&strcmp(dec,"null")==0) dec[0]=0;
                            else if(dec[0]=='{'&&dec[1]=='}') dec[0]=0;
                            else if(dec[0]=='['&&dec[1]==']') dec[0]=0;
                            if(*dec){
                                /* 首次正文: 清理spinner, 关闭思考块 */
                                if(spin_shown && !content_started){
                                    printf("\r\x1b[K"); fflush(stdout);
                                    spin_shown=0;
                                }
                                if(rblock && !content_started){
                                    printf("%s└─%s\n",MG,RS);
                                    rblock=0;
                                }
                                if(!content_started){
                                    printf("%sAI> %s",GC,RS); fflush(stdout);
                                    content_started=1;
                                }
                                printf("%s",dec); fflush(stdout);
                                printed_any=1;
                                char*du=strdup(dec);
                                if(du){ content=buf_append(content,&clen,&ccap,du); free(du); }
                            }
                        }
                    }
                }
                linelen=0;
            } else {
                if(linelen+1<linecap) line[linelen++]=ch;
            }
        }
    }
    }
    close(outpipe[0]);
    close((int)fd);
    if(interrupted){
        if(spin_shown){ printf("\r\x1b[K"); fflush(stdout); }
        printf("%s[已中断]%s\n", YL, RS);
        kill(pid, SIGKILL); close(outpipe[0]); close((int)fd);
        while(waitpid(pid, NULL, 0) != -1){}
        free(line); if(reason) free(reason); if(clen) free(content);
        g_stream_interrupted=1;
        return NULL;
    }
    while(waitpid(pid, NULL, 0) != -1){}
    if(spin_shown){ printf("\r\x1b[K"); fflush(stdout); }
    if(rblock) printf("%s└─%s\n",MG,RS);
    if(printed_any) printf("%s\n",RS);

    free(line);
    if(reason) free(reason);
    if(!clen){ free(content); return NULL; }
    return content;
}

/* ---------- 构造请求体 ---------- */
static char *json_escape(const char *s){
    size_t cap = strlen(s)*2 + 64, len=0;
    char *b = malloc(cap);
    if(!b) return NULL;
    while(*s){
        if(len+8>=cap){ cap*=2; char *nb=realloc(b,cap); if(!nb) return b; b=nb; }
        if(*s=='"'){ b[len++]='\\'; b[len++]='"'; }
        else if(*s=='\\'){ b[len++]='\\'; b[len++]='\\'; }
        else if(*s=='\n'){ b[len++]='\\'; b[len++]='n'; }
        else if(*s=='\r'){ b[len++]='\\'; b[len++]='r'; }
        else if(*s=='\t'){ b[len++]='\\'; b[len++]='t'; }
        else if((unsigned char)*s<0x20){ /* skip */ }
        else b[len++]=*s;
        s++;
    }
    b[len]=0;
    return b;
}

static char *build_body_tooled(const char *user_input){
    size_t cap = 262144, len=0;
    char *b = malloc(cap);
    if(!b) return NULL;
    b[0]=0;
#define APPEND(fmt, ...) do{ \
        for(;;){ int _r=snprintf(b+len, cap-len>0?cap-len:0, (fmt), ##__VA_ARGS__); \
                 if(_r<0){ break; } \
                 size_t need=(size_t)_r; \
                 if(len+need+1<=cap) break; \
                 cap*=2; char *_nb=realloc(b,cap); if(!_nb) goto fail; b=_nb; } \
        len=strlen(b); \
    }while(0)
#define APPENDS(sstr) do{ const char*_z=(sstr); if(_z){ size_t _zl=strlen(_z); \
        if(len+_zl+1>cap){ cap*=2; char*_nb=realloc(b,cap); if(!_nb) goto fail; b=_nb; } \
        memcpy(b+len,_z,_zl); len+=_zl; b[len]=0; } }while(0)

    APPEND("{\"model\":\"%s\",\"messages\":[", MODEL);

    {
        if(!g_toolcache) g_toolcache = build_tools_usage_text();
        char *sysall = NULL;
        if(TOOLS_ENABLED && g_toolcache){
            size_t nd = strlen(SYSTEM_PROMPT) + strlen(g_toolcache) + 64;
            sysall = malloc(nd);
            if(sysall) snprintf(sysall, nd, "%s\n\n[系统工具能力]\n%s", SYSTEM_PROMPT, g_toolcache);
        } else {
            sysall = strdup(SYSTEM_PROMPT);
        }
        char *sp = sysall? json_escape(sysall) : json_escape(SYSTEM_PROMPT);
        APPEND("{\"role\":\"system\",\"content\":\"%s\"}", sp?sp:"");
        free(sp); free(sysall);
    }

    int i;
    for(i=0;i<hist_n;i++){
        char *esc = json_escape(hist[i].content);
        APPEND(",{\"role\":\"%s\",\"content\":\"%s\"}", hist[i].role, esc?esc:"");
        free(esc);
    }
    char *ue = json_escape(user_input);
    APPEND(",{\"role\":\"user\",\"content\":\"%s\"}]", ue?ue:"");
    free(ue);
    APPEND(",\"thinking\":{\"type\":\"%s\"},\"stream\":true}", THINK?"enabled":"disabled");

    { const char *d = getenv("AI_DUMP_BODY");
      if(d && *d){ FILE*f=fopen("/data/local/tmp/ai_work/ai_cli/dbg_body.json","w");
        if(f){ fputs(b,f); fputc('\n',f); fclose(f); } } }
    return b;
fail:
    free(b); return NULL;
#undef APPENDS
#undef APPEND
}
static char *build_body(const char *user_input){
    size_t cap = 8192, len=0;
    char *b = malloc(cap);
    if(!b) return NULL;
    len += snprintf(b+len, cap-len, "{\"model\":\"%s\",\"messages\":[", MODEL);

    char *sp = json_escape(SYSTEM_PROMPT);
    len += snprintf(b+len, cap-len, "{\"role\":\"system\",\"content\":\"%s\"}", sp?sp:"");
    free(sp);

    int i;
    for(i=0;i<hist_n;i++){
        char *esc = json_escape(hist[i].content);
        if(len + strlen(esc) + 128 >= cap){ cap*=2; char *nb=realloc(b,cap); if(!nb){ free(esc); return b;} b=nb; }
        len += snprintf(b+len, cap-len, ",{\"role\":\"%s\",\"content\":\"%s\"}", hist[i].role, esc?esc:"");
        free(esc);
    }
    char *ue = json_escape(user_input);
    if(len + strlen(ue) + 128 >= cap){ cap*=2; char *nb=realloc(b,cap); if(!nb){ free(ue); return b;} b=nb; }
    len += snprintf(b+len, cap-len, ",{\"role\":\"user\",\"content\":\"%s\"}]", ue?ue:"");
    free(ue);
    len += snprintf(b+len, cap-len, ",\"thinking\":{\"type\":\"%s\"},\"stream\":true}", THINK?"enabled":"disabled");
    return b;
}

/* ---------- 历史 ---------- */
static void hist_add(const char *role, const char *content){
    if(hist_n >= HIST_MAX){
        free(hist[0].content);
        memmove(&hist[0], &hist[1], (HIST_MAX-1)*sizeof(Msg));
        hist_n = HIST_MAX-1;
    }
    hist[hist_n].role[0]=0;
    strncpy(hist[hist_n].role, role, sizeof(hist[hist_n].role)-1);
    hist[hist_n].content = strdup(content);
    hist_n++;
}

/* ---------- 配置读写 ---------- */
static void load_conf_if_exists(void){
    FILE *f = fopen(CONF_FILE, "r");
    if(!f) return;
    char line[1024];
    while(fgets(line, sizeof(line), f)){
        line[strcspn(line,"\r\n")]=0;
        if(!line[0]||line[0]=='#') continue;
        if(!strncmp(line,"api_base=",9)) snprintf(API_BASE,sizeof(API_BASE),"%s",line+9);
        else if(!strncmp(line,"api_key=",8)) snprintf(API_KEY,sizeof(API_KEY),"%s",line+8);
        else if(!strncmp(line,"model=",6)) snprintf(MODEL,sizeof(MODEL),"%s",line+6);
        else if(!strncmp(line,"system_prompt=",14)) snprintf(SYSTEM_PROMPT,sizeof(SYSTEM_PROMPT),"%s",line+14);
        else if(!strncmp(line,"think=",6)) THINK = (line[6]=='o' && line[7]=='n');
        else if(!strncmp(line,"showthink=",10)) SHOWTHINK = (line[10]=='o' && line[11]=='n');
        else if(!strncmp(line,"tools_enabled=",14)) TOOLS_ENABLED = (line[14]=='o' && line[15]=='n');
    }
    fclose(f);
}

static int save_conf(void){
    FILE *f = fopen(CONF_FILE, "w");
    if(!f) return -1;
    fprintf(f,"# AI CLI 配置 (由二进制 ai 保存)@Chen9183\n");
    fprintf(f,"api_base=%s\n",API_BASE);
    fprintf(f,"api_key=%s\n",API_KEY);
    fprintf(f,"model=%s\n",MODEL);
    fprintf(f,"system_prompt=%s\n",SYSTEM_PROMPT);
    fprintf(f,"think=%s\n",THINK?"on":"off");
    fprintf(f,"showthink=%s\n",SHOWTHINK?"on":"off");
    fprintf(f,"tools_enabled=%s\n",TOOLS_ENABLED?"on":"off");
    fclose(f);
    return 0;
}

static int known_cmd(const char*s){
    static const char*known[]={"/exit","/model","/key","/provider","/system","/conf","/new","/tools","/help","/h",0};
    for(int i=0;known[i];i++) if(!strcmp(s,known[i])) return 1;
    return 0;
}

static char *read_line_prompt(const char *prompt){
    if(PEND_ARG){ char*r=PEND_ARG; PEND_ARG=NULL; return r; }
    struct termios old,raw;
    tcgetattr(0,&old);
    raw=old;
    raw.c_lflag &= ~(ICANON|ECHO);   /* 保留 ISIG 以便 Ctrl+C 触发 SIGINT */
    raw.c_cc[VMIN]=1; raw.c_cc[VTIME]=0;
    tcsetattr(0,TCSANOW,&raw);

    printf("%s", prompt); fflush(stdout);

    char *buf=NULL; size_t cap=0,len=0; int pos=0;
    unsigned char ch; int eof=0;

    /* 整行重绘宏: \r 回首 + 清到行尾 + prompt+整行 + 光标移到pos(CSI右移) */
#define REDRAW() do{ \
    printf("\r\x1b[K%s%s", prompt, buf?buf:""); \
    for(int _i=0;_i<pos && (int)len>0;_i++) printf("\x1b[1C"); \
    fflush(stdout); \
}while(0)

    while(1){
        ssize_t got=read(0,&ch,1);
        if(got<0){
            if(errno==EINTR){
                pos=0; len=0; if(buf) buf[0]=0;
                REDRAW();
                continue;
            }
            eof=1; break;
        }
        if(got==0){ eof=1; break; }
        /* 方向键: ESC [ A/B/C/D */
        if(ch==27){
            unsigned char s1,s2;
            if(read(0,&s1,1)!=1){ eof=1; break; }
            if(s1=='[' && read(0,&s2,1)==1){
                if(s2=='D'){ /* 左移(按字符) */
                    if(pos>0){
                        int ks=pos-1; while(ks>0 && ((unsigned char)buf[ks]&0xC0)==0x80) ks--;
                        pos=ks;
                        REDRAW();
                    }
                } else if(s2=='C'){ /* 右移 */
                    if(pos<(int)len){
                        int k=pos+1; while(k<(int)len && ((unsigned char)buf[k]&0xC0)==0x80) k++;
                        pos=k;
                        REDRAW();
                    }
                }
            }
            continue;
        }
        if(ch=='\n'||ch=='\r') break;
        if(ch==3){
            pos=0; len=0; if(buf) buf[0]=0;
            REDRAW();
            continue;
        }
        if(ch==127||ch==8){
            if(pos>0){
                int ks=pos-1; while(ks>0 && ((unsigned char)buf[ks]&0xC0)==0x80) ks--;
                int d=pos-ks;
                if(pos==(int)len){
                    len-=d; pos-=d; if(buf) buf[len]=0;
                } else {
                    memmove(buf+ks, buf+pos, len-pos);
                    len-=d; buf[len]=0; pos=ks;
                }
                REDRAW();
            }
            continue;
        }
        if(len+2>=cap){ cap=cap?cap*2:256; char*nb=realloc(buf,cap); if(!nb){eof=1;break;} buf=nb; }
        if(pos==(int)len){
            buf[len++]=ch; pos=len; buf[len]=0;
        } else {
            memmove(buf+pos+1, buf+pos, len-pos);
            buf[pos]=ch; len++; pos++; buf[len]=0;
        }
        REDRAW();
    }
done:
    if(!eof){ printf("\r\x1b[K"); }
    tcsetattr(0,TCSANOW,&old);
    /* EOF 或未知 -> 返回 NULL, 上层据此退出(避免空行死循环) */
    if(eof && len==0){ free(buf); return NULL; }
    if(!buf) buf=strdup(""); else{ buf=realloc(buf,len+1); if(buf) buf[len]=0; }
    if(!buf) buf=strdup("");
#undef REDRAW
    return buf;
}

static char *read_line(void){ return read_line_prompt(""); }

/* ---------- 选择提供商(数字) ---------- */
static void pick_provider(void){
    int i;
    printf("%s请选择 AI 服务提供商:%s\n", CY, RS);
    for(i=0;i<NPROV;i++){
        printf("  %s%d%s  %s\n", MG, i+1, RS, providers[i].name);
    }
    printf("输入数字 [1-%d]> ", NPROV); fflush(stdout);
    char *in = read_line();
    if(in && *in){
        int sel = atoi(in)-1;
        if(sel>=0 && sel<NPROV){
            PROVIDER_IDX = sel;
            if(providers[sel].base[0]) snprintf(API_BASE,sizeof(API_BASE),"%s",providers[sel].base);
            if(providers[sel].model[0]) snprintf(MODEL,sizeof(MODEL),"%s",providers[sel].model);
            printf("%s已选择: %s%s\n", GC, providers[sel].name, RS);
        } else {
            printf("%s[!] 输入无效%s\n", YL, RS);
        }
    }
    free(in);
}

/* ---------- 向导: 选提供商 + 填 key + (自定义则填地址/模型) ---------- */
static void wizard(void){
    printf("%s=== AI 配置向导 ===%s\n", CY, RS);
    pick_provider();
    if(PROVIDER_IDX == NPROV-1){  /* 自定义: 需手动填地址 */
        if(!*API_BASE){
            printf("AI服务地址 (含 /v1)> "); fflush(stdout);
            char *in=read_line(); if(in&&*in) snprintf(API_BASE,sizeof(API_BASE),"%s",in); free(in);
        }
    }
    printf("API Key> "); fflush(stdout);
    char *in=read_line();
    if(in && *in) snprintf(API_KEY,sizeof(API_KEY),"%s",in);
    free(in);
    if(!*API_KEY){
        printf("%s[!] 未填 Key, 对话将失败。可用 /key 补填%s\n", YL, RS);
    } else if(PROVIDER_IDX != NPROV-1){
        /* 非自定义且有 Key: 拉取模型列表供选择 */
        if(pick_model(API_KEY)!=0 && !*MODEL){
            /* 拉取失败且无默认模型 -> 手动输入 */
            printf("模型名> "); fflush(stdout);
            char *mi=read_line(); if(mi&&*mi) snprintf(MODEL,sizeof(MODEL),"%s",mi); free(mi);
        }
    }
}

/* ---------- 一轮对话 ---------- */
static void do_chat(const char *input){
    char *body = build_body_tooled(input);
    if(!body){ printf("%s[!] 内存错误%s\n",YL,RS); return; }

    char url[1024];
    size_t bl = strlen(API_BASE);
    if(bl && API_BASE[bl-1]=='/'){ snprintf(url,sizeof(url),"%schat/completions", API_BASE); }
    else { snprintf(url,sizeof(url),"%s/chat/completions", API_BASE); }

    int turn=0;
    const int maxturn=6;
    int user_recorded=0;
    while(turn < maxturn){
        turn++;
        g_interrupt=0; g_stream_interrupted=0; g_in_request=1;
        printf("%s[流式…]%s ", CY, RS); fflush(stdout);
        char *content = chat_stream(url, API_KEY, body);
        free(body); body=NULL;
        g_in_request=0;

        if(g_stream_interrupted){
            free(content);
            printf("\n");
            return;
        }

        if(content && *content){
            if(content_has_tool(content)){
                char *tc = find_tool_call(content);
                if(tc){
                    printf("\n%s⟪调用工具…⟫%s ", CY, RS); fflush(stdout);
                    char *r = execute_tool_call(tc);
                    printf("[%s%d字节%s]\n", GC, r?(int)strlen(r):0, RS);
                    if(!user_recorded){ hist_add("user", input); user_recorded=1; }
                    if(r && *r){
                        char *msg = malloc(strlen(r)+40);
                        if(msg){ sprintf(msg,"(上面工具调用结果, 请基于回答)\n%s", r); hist_add("user", msg); free(msg); }
                    }
                    free(r); free(tc); free(content);
                    printf("%s[工具完成, 组织最终回答…]%s ", YL, RS); fflush(stdout);
                    body = build_body_tooled("");
                    if(!body){ printf("\n%s[!] 内存错误%s\n",YL,RS); return; }
                    continue; /* 再转一轮拿最终答案 */
                }
                if(!user_recorded){ hist_add("user", input); user_recorded=1; }
                /* 有标记但解析失败: 回显模型原话 + 明确纠错, 让模型下一轮修正, 避免静默重试致死循环 */
                hist_add("assistant", content);
                const char *emsg = "(检测到工具调用但格式无法解析。请严格按以下单行格式输出工具调用:\n"
                    "[[TOOL]] {\"name\":\"工具名\",\"args\":{...}} [[/TOOL]]\n"
                    "其中 name 必须是 run_shell / bing_search / curl_download / time_now 之一, args 必须是合法 JSON；并把上一轮你要问的内容重新附带一次。)\n";
                hist_add("user", emsg);
                free(content);
                body = build_body_tooled("");
                if(!body){ printf("\n%s[!] 内存错误%s\n",YL,RS); return; }
                continue;   /* 再给模型一次修正机会(仍受 maxturn 保护) */
            }
            if(!user_recorded){ hist_add("user", input); user_recorded=1; }
            hist_add("assistant", content);
            free(content);
            return;
        }
        free(content);

        /* ---- 非流式回退(流式无正文输出时)---- */
        if(!user_recorded){ hist_add("user", input); user_recorded=1; }
        body = build_body_tooled("");
        if(!body){ printf("\n%s[!] 内存错误%s\n",YL,RS); return; }
        printf("%s[回退非流式]%s ", YL, RS);
        char *resp=NULL;
        int rc = http_post_json(url, API_KEY, body, &resp);
        free(body); body=NULL;
        printf("\n");
        if(rc!=0 || !resp){
            printf("%s[!] 请求失败: %.200s%s\n", YL, strerror(errno), RS);
            return;
        }
        char *errmsg = jq_query("(.error.message // empty)", resp);
        if(errmsg && *errmsg){ printf("%s[!] API错误: %s%s\n", YL, errmsg, RS); free(errmsg); free(resp); return; }
        free(errmsg);
        if(SHOWTHINK){
            char *reason = jq_query(".choices[0].message.reasoning_content // empty", resp);
            if(reason && *reason){ printf("%s┬─ 思考 %s\n", MG, RS); printf("%s%s%s\n", MG, reason, RS); printf("%s└─%s\n", MG, RS); }
            free(reason);
        }
        char *content2 = jq_query(".choices[0].message.content", resp);
        if(!content2 || !*content2){
            printf("%s[!] 无法解析响应. 原始:%.300s%s\n", YL, resp, RS);
            free(content2); free(resp);
            /* 工具轮无内容则退出, 避免死循环 */
            if(content_has_tool(resp)){ free(resp); return; }
            return;
        }
        if(content_has_tool(content2)){
            char *tc2 = find_tool_call(content2);
            if(tc2){
                char *r = execute_tool_call(tc2);
                if(!user_recorded){ hist_add("user", input); user_recorded=1; }
                if(r && *r){ char *msg=malloc(strlen(r)+40); if(msg){ sprintf(msg,"(工具结果)\n%s",r); hist_add("user",msg); free(msg);} }
                free(r); free(tc2); free(content2); free(resp);
                body = build_body_tooled("");
                continue;
            }
            free(tc2);
        }
        printf("%sAI> %s%s\n", GC, content2, RS);
        if(!user_recorded){ hist_add("user", input); user_recorded=1; }
        hist_add("assistant", content2);
        free(content2); free(resp);
        return;
    }
    printf("%s[!] 工具循环达到上限, 停止%s\n", YL, RS);
}


static int is_deepseek(void){
    return (strstr(API_BASE, "deepseek") != NULL);
}

/* y/n 确认: 输入其他任意字符会重新询问 */
static int ask_yn(const char *msg){
    for(;;){
        printf("%s%s [y/N]: %s", YL, msg, RS); fflush(stdout);
        char *a=read_line();
        int r;
        if(!a){ r=0; }
        else if(a[0]=='y'||a[0]=='Y'){ r=1; }
        else if(a[0]==0 || a[0]=='n'||a[0]=='N'){ r=0; }
        else { free(a); printf("%s只能输入 y 或 n, 请重新输入.%s\n", YL, RS); continue; }
        free(a);
        return r;
    }
}

/* ---------- 帮助 ---------- */
static void help(void){
    printf(CY"══════════ AI CLI 终端对话工具 ══════════"RS"\n");
    printf(CY"  作者:  @​C​h​e​n​9​1​8​3  (github) & DeepSeek V4 Flash\n"RS);
    printf(CY"  DeepSeek V4 Flash 为当前驱动模型, 提供商/模型由 /conf 运行时决定\n"RS);
    printf(CY"  用法: %sai%s  或  %sai -h|--help|help%s  (命令行打印本帮助并退出)\n"RS, CY,RS, CY,RS);
    printf(GC"  -- 直接输入文字与 AI 对话, 支持多轮上下文 --\n"RS);
    printf("\n");
    printf(MG"[工具能力] 对话中 AI 可主动调用下列工具:\n"RS);
    printf("  bing_search     联网搜索   (输入含搜索/查资料相关内容)\n");
    printf("  run_shell       执行shell命令 (root 环境, 可带 timeout)\n");
    printf("  curl_download   下载文件到指定路径\n");
    printf("  time_now        获取当前时间\n");
    printf(CY"  工具结果会自动注入本轮供 AI 组织答案; 结果较大时被截断,\n    可要求 AI 再次调用工具获取完整内容。\n"RS);
    printf("\n");
    printf(MG"命令列表:"RS"\n");
    if(is_deepseek()){
        printf("  /think on|off        开启/关闭深度思考\n"
               "  /showthink on|off    显示/隐藏思考过程\n");
    }
    printf("  /model               切换模型\n"
           "  /key                 更新 API Key\n"
           "  /provider            重新选择提供商\n"
           "  /system              修改系统提示词\n"
           "  /conf                查看当前配置\n"
           "  /new                 开启新对话(保留配置)\n"
           "  /tools on|off        开启/关闭 AI 工具调用\n"
           "  /help | /h | help    显示本帮助\n"
           "  /exit                退出(按需保存配置)\n");
    printf("\n");
}
static void on_sigint(int s){ (void)s; if(g_in_request) g_interrupt=1; }

#ifndef TOOL_UNIT_TEST
int main(int argc, char **argv){
    (void)argc;(void)argv;
    setvbuf(stdout, NULL, _IONBF, 0);

    struct sigaction sa; memset(&sa,0,sizeof(sa));
    sa.sa_handler=on_sigint; sigemptyset(&sa.sa_mask);
    sigaction(SIGINT,&sa,NULL);

    int modified = 0;   /* 是否有配置改动 */
    load_conf_if_exists();

    /* 无 key 或未配置 -> 向导 */
    if(argc>1){
        const char *a=argv[1];
        if(!strcmp(a,"-h") || !strcmp(a,"--help") || !strcmp(a,"help") || !strcmp(a,"/h") || !strcmp(a,"-help")){
            help(); return 0;
        }
    }
    if(!*API_KEY || !*API_BASE){
        wizard();
        if(*API_KEY) modified = 1;   /* 向导配好后 /exit 询问保存 */

    }

    printf(GC"═══  AI 对话  (输入 /help 查看命令)  ═══"RS"\n");
    if(is_deepseek()){
        printf("  [提供商:%s%s"RS"  思考:%s%s"RS"  显示思考:%s%s"RS"]\n",
               CY, *API_BASE?API_BASE:"-", CY, THINK?"on":"off", CY, SHOWTHINK?"on":"off");
    } else {
        printf("  [提供商:%s%s"RS"]\n", CY, *API_BASE?API_BASE:"-");
    }
    printf("\n");

    int first=1;
    char *input;
    while(1){
        printf(GC"你> "RS); fflush(stdout);
        input=read_line();
        if(!input) break;
        /* 支持 /cmd arg 一行式: 命中已知命令且带空格则拆出参数给后续 read_line 消费 */
        if(input[0]=='/'){
            char *sp=strchr(input,' ');
            if(sp){
                char saved=*sp; *sp='\0';
                if(known_cmd(input)){ PEND_ARG=strdup(sp+1); }
                else *sp=saved;
            }
        }
        if(*input) printf(GC"你> %s"RS"\n", input);

        if(input[0]=='/' && input[1]==0){ free(input); continue; }

        if(!strcmp(input,"/exit")){
            if(modified){
                char q[256]; snprintf(q,sizeof(q),"配置有改动/未保存, 是否写入 %s?", CONF_FILE);
                if(ask_yn(q)){ if(save_conf()==0) printf("%s[✓] 配置已保存到 %s%s\n",GC,CONF_FILE,RS); }
            } else {
                printf("%s[配置无改动, 直接退出]%s\n", GC, RS);
            }
            free(input); input=NULL; break;
        }
        else if(input[0]=='/' && (strncmp(input,"/think",6)==0 || strncmp(input,"/showthink",10)==0)){
            if(!is_deepseek()){
                printf("%s[!] 当前提供商不支持思考(仅 DeepSeek 可用)%s\n", YL, RS);
                free(input); continue;
            }
            int st = (input[1]=='s');
            char *arg = input;
            if(st) arg += 10; else arg += 6;
            while(*arg==' ') arg++;
            if(!*arg){ /* 参数在下一行 */
                free(input);
                char *in=read_line();
                if(in && (!strcmp(in,"off") || !strcmp(in,"0"))){
                    if(st) SHOWTHINK=0; else THINK=0;
                } else {
                    if(st) SHOWTHINK=1; else THINK=1;
                }
                modified=1;
                if(st) printf("%s显示思考: %s%s\n",GC,SHOWTHINK?"on":"off",RS);
                else   printf("%s思考: %s%s\n",GC,THINK?"on":"off",RS);
                free(in); continue;
            } else {
                int val = (!strcmp(arg,"off") || !strcmp(arg,"0")) ? 0 : 1;
                if(st) SHOWTHINK=val; else THINK=val;
                modified=1;
                free(input);
                if(st) printf("%s显示思考: %s%s\n",GC,SHOWTHINK?"on":"off",RS);
                else   printf("%s思考: %s%s\n",GC,THINK?"on":"off",RS);
                continue;
            }
        }
        else if(!strcmp(input,"/model")){ free(input);
            if(PROVIDER_IDX != NPROV-1 && *API_KEY){
                if(pick_model(API_KEY)==0){ modified=1; continue; }
            }
            printf("模型名 (直接输入)> "); fflush(stdout);
            char*in=read_line(); if(in&&*in){ snprintf(MODEL,sizeof(MODEL),"%s",in); modified=1; } free(in); continue; }
        else if(!strcmp(input,"/key")){ free(input); printf("新 API Key> "); fflush(stdout); char*in=read_line(); if(in&&*in){ snprintf(API_KEY,sizeof(API_KEY),"%s",in); modified=1; printf("%s[✓] Key 已更新(退出时保存)%s\n",GC,RS);} free(in); continue; }
        else if(!strcmp(input,"/provider")){ free(input);
            pick_provider();
            if(PROVIDER_IDX == NPROV-1){
                printf("AI服务地址 (含 /v1)> "); fflush(stdout);
                char*ci=read_line(); if(ci&&*ci) snprintf(API_BASE,sizeof(API_BASE),"%s",ci); free(ci);
            }
            if(PROVIDER_IDX != NPROV-1 && *API_KEY){
                pick_model(API_KEY);
            }
            if(!is_deepseek()){ THINK=0; SHOWTHINK=0; }
            modified=1; continue; }
        else if(!strcmp(input,"/system")){
            free(input);
            printf("系统提示词 [%s]> ", SYSTEM_PROMPT); fflush(stdout);
            char*in=read_line();
            if(in){ snprintf(SYSTEM_PROMPT,sizeof(SYSTEM_PROMPT),"%s",in?in:""); modified=1; printf("%s[✓] 系统提示词已更新%s\n",GC,RS); }
            free(in); continue;
        }
        else if(!strcmp(input,"/conf")){
            free(input);
            printf("提供商: %s\n", *API_BASE?API_BASE:"-");
            printf("API Key: %s\n", *API_KEY?"****(已设置)":"(空)");
            printf("模型: %s\n", MODEL);
            printf("系统提示词: %s\n", SYSTEM_PROMPT);
            continue;
        }
        else if(!strcmp(input,"/new")){
            free(input);
            for(int i=0;i<hist_n;i++) free(hist[i].content);
            hist_n=0;
            printf("%s[已开启新对话(配置保留)]%s\n", GC, RS);
            continue;
        }
        else if(!strcmp(input,"/tools")){
            free(input);
            char*in=read_line(); if(in){
                if(!strcmp(in,"on")){ TOOLS_ENABLED=1; if(g_toolcache){ free(g_toolcache); g_toolcache=NULL; } modified=1; printf("%s[✓] 工具已开启%s\n",GC,RS); }
                else { TOOLS_ENABLED=0; if(g_toolcache){ free(g_toolcache); g_toolcache=NULL; } modified=1; printf("%s[✓] 工具已关闭%s\n",GC,RS); }
            } free(in); continue;
        }
        else if(!strcmp(input,"/help") || !strcmp(input,"/h") || !strcmp(input,"help")){ free(input); help(); continue; }

        /* 普通消息 */
        if(first){ printf("\n"); first=0; }
        if(!*API_KEY){ printf("%s[!] 未填 Key, 请在向导中填写或 /key%s\n",YL,RS); free(input); continue; }
        if(!*API_BASE){ printf("%s[!] 未填服务地址%s\n",YL,RS); free(input); continue; }
        do_chat(input);
        free(input);
    }
    free(input);
    return 0;
}

#endif /* TOOL_UNIT_TEST */

#ifdef TOOL_UNIT_TEST
int main(int argc, char **argv){
    (void)argc;(void)argv;
    printf("=== 工具系统单元测试 ===\n");
    const char *s1 = "回复 [[TOOL]] {\"name\":\"time_now\",\"args\":{}} [[/TOOL]] 继续";
    char *t = find_tool_call(s1);
    printf("[1] find_tool_call: %s\n", t?t:"(NULL)"); free(t);
    t = find_tool_call("[[TOOL]] {\"name\":\"run_shell\",\"args\":{\"cmd\":\"echo HI_TOOL\",\"timeout\":5000}} [[/TOOL]]");
    char *r = execute_tool_call(t);
    printf("[2] execute run_shell: %s\n", r?r:"(NULL)"); free(r); free(t);

    char *big = calloc(1,2560); memset(big,'A',2500);
    char *a = tool_result_trim("dump_test","{\"n\":1}", big);
    printf("[3] 首次大结果: len=%zu %s\n", strlen(a), strstr(a,"已截断")?"(已截断✓)":"外!");
    char *bt = tool_result_trim("dump_test","{\"n\":1}", big);
    printf("[4] 同工具同args二次: len=%zu %s\n", strlen(bt), strstr(bt,"已截断")?"外!应全量":"(全量✓)");
    char *c = tool_result_trim("dump_test","{\"n\":2}", big);
    printf("[5] 不同args再首: len=%zu %s\n", strlen(c), strstr(c,"已截断")?"(已截断✓)":"外!");
    free(a); free(bt); free(c); free(big);

    TOOLS_ENABLED=0;
    t = find_tool_call("[[TOOL]] {\"name\":\"run_shell\",\"args\":{}} [[/TOOL]]");
    char *d = execute_tool_call(t);
    printf("[6] 开关off execute: %s\n", d?d:"(NULL)"); free(d); free(t);

    TOOLS_ENABLED=1; if(g_toolcache){free(g_toolcache); g_toolcache=NULL;}
    char *body = build_body_tooled("hi");
    printf("[7] on含[系统工具能力]=%d 含bing=%d len=%d\n", strstr(body,"系统工具能力")!=0, strstr(body,"bing_search")!=0, body?(int)strlen(body):0);
    free(body);
    TOOLS_ENABLED=0; if(g_toolcache){free(g_toolcache); g_toolcache=NULL;}
    char *body2 = build_body_tooled("hi");
    printf("[8] off含[系统工具能力]=%d 含bing=%d tail=%d\n", strstr(body2,"系统工具能力")!=0, strstr(body2,"bing_search")!=0, body2 && body2[0] && strstr(body2,"\"stream\":true}")!=0);
    free(body2);

    /* --- 格式容错: extract_json_val 宽松解析(用 \" 转义, 避免 \x 吞 hex) --- */
    { char v[256];
      const char*t1="{\"name\":\"run_shell\",\"args\":{\"cmd\":\"echo H\"}}";
      printf("[9] 标准 name=%d cmd=%d expect1,1\n",
        extract_json_val(t1,"\"name\":",v,sizeof(v))&&!strcmp(v,"run_shell"),
        extract_json_val(t1,"\"cmd\":",v,sizeof(v))&&!strcmp(v,"echo H"));
      const char*t2="{ \"name\" : \"run_shell\" , \"args\" : { \"cmd\" : \"ls -la\" } }";
      printf("[10] 带空格 name=%d cmd=%d expect1,1\n",
        extract_json_val(t2,"\"name\":",v,sizeof(v))&&!strcmp(v,"run_shell"),
        extract_json_val(t2,"\"cmd\":",v,sizeof(v))&&!strcmp(v,"ls -la"));
      const char*t3="{ name:'run_shell' , args:{ cmd:'whoami' } }";
      printf("[11] 裸键单引 name=%d cmd=%d expect1,1\n",
        extract_json_val(t3,"\"name\":",v,sizeof(v))&&!strcmp(v,"run_shell"),
        extract_json_val(t3,"\"cmd\":",v,sizeof(v))&&!strcmp(v,"whoami"));
      const char*t4="{\"name\":\"time_now\",\"args\":{}}";
      extract_json_val(t4,"\"name\":",v,sizeof(v));
      printf("[13] args空 name=%d expect1 (val=%s)\n", !strcmp(v,"time_now"), v);
    }
    /* --- 多变体标记识别 --- */
    { const char*vs="{\"name\":\"time_now\",\"args\":{\"x\":1}}";
      const char*t1="回复 [TOOL] {\"name\":\"time_now\",\"args\":{}} [/TOOL] 结束";
      char*t=find_tool_call(t1);
      printf("[14] [TOOL]标记 has=%d find=%d expect1,1\n", content_has_tool(t1), t!=0);
      free(t);
      const char*t2="请用 (TOOL) {\"name\":\"time_now\",\"args\":{}} (TOOL) 工具";
      t=find_tool_call(t2);
      printf("[15] (TOOL)标记 find=%d expect1\n", t!=0); free(t);
      const char*t3="帮我执行 {\"name\":\"run_shell\",\"args\":{\"cmd\":\"echo NO_WRAP\"}} 谢谢";
      printf("[16] 无包裹但含工具JSON has=%d expect1\n", content_has_tool(t3));
      char*r=NULL; t=NULL;
      const char*t4="执行 {\"name\":\"run_shell\",\"args\":{\"cmd\":\"echo WRAPLESS\"}} 吧";
      /* 无包裹时应走宽松: 直接在整个串里找 { 后的 JSON 执行 */
      t=find_tool_call(t4);
      printf("[17] 无包裹 find_tool_call=%d expect1\n", t!=0);
      TOOLS_ENABLED=1;
      if(t){ r=execute_tool_call(t); printf("[18] 执行=%s expect WRAPLESS\n", r?r:"(NULL)"); free(r); free(t); }
    }
    printf("=== 完成 ===\n");
    return 0;
}
#endif
