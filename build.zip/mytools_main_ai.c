/* mytools - Multi-call Binary Toolbox
 *作者:@Chen9183(github)
 * help text embedded as help.txt via ld -r -b binary
 * Entry: main_entry() called from start.s
 */

typedef long s64;
#define O_CREAT  0100
#define O_TRUNC  01000
#define NULL 0
#define SYS_write 64
#define SYS_read 63
#define SYS_close 57
#define SYS_memfd_create 279
#define SYS_execveat 281
#define SYS_exit 93
#define SYS_readlinkat 78
#define SYS_unlinkat 35
#define SYS_symlinkat 36
#define SYS_wait4 260
#define SYS_fork 220
#define SYS_dup3 24
#define SYS_pipe2 59
#define AT_EMPTY_PATH 0x1000
#define AT_FDCWD (-100)
/* 新增系统调用号 */
#define SYS_openat     56
#define SYS_access     21
#define SYS_ftruncate  46
#define SYS_mmap       222
#define SYS_munmap     215
#define SYS_mprotect   226

/* 常量 */
#define PROT_READ      1
#define PROT_WRITE     2
#define PROT_EXEC      4
#define MAP_SHARED     0x01
#define O_TMPFILE      0x2004000   /* 2000000 | 4000 */
#define O_RDWR         2
#define O_CLOEXEC      0x80000
#define O_RDONLY 0
#define F_OK           0
#define MAP_FAILED ((void*)-1)

/* .noroot 文件路径（安卓 & Linux） */
#define MT_NOROOT_ANDROID "/data/local/tmp/.noroot"
#define MT_NOROOT_LINUX   "/var/tmp/mt/.noroot"

/* O_TMPFILE 所在目录 */
#define MT_TMPDIR_ANDROID "/data/local/tmp"
#define MT_TMPDIR_LINUX   "/var/tmp/mt"

/* 目录路径（用于 mkdir） */
#define MT_DIR_ANDROID    "/data/local/tmp"
#define MT_DIR_LINUX      "/var/tmp/mt"

/* 新增系统调用号 */
#define SYS_mkdir 83
/* 封装 unlinkat */
static s64 sc_unlinkat(s64 dirfd, const char *path, s64 flags) {
    register s64 x8 asm("x8") = SYS_unlinkat;
    register s64 x0 asm("x0") = dirfd;
    register s64 x1 asm("x1") = (s64)path;
    register s64 x2 asm("x2") = flags;
    asm volatile("svc #0" : "+r"(x0) : "r"(x1),"r"(x2),"r"(x8) : "memory");
    return x0;
}
/* mkdir 内联封装 */
static s64 sc_mkdir(const char *path, s64 mode) {
    register s64 x8 asm("x8") = SYS_mkdir;
    register s64 x0 asm("x0") = (s64)path;
    register s64 x1 asm("x1") = mode;
    asm volatile("svc #0" : "+r"(x0) : "r"(x1),"r"(x8) : "memory");
    return x0;
}
/* 内联汇编封装 */
static s64 sc_openat(s64 dirfd, const char *path, s64 flags, s64 mode) {
    register s64 x8 asm("x8") = SYS_openat;
    register s64 x0 asm("x0") = dirfd;
    register s64 x1 asm("x1") = (s64)path;
    register s64 x2 asm("x2") = flags;
    register s64 x3 asm("x3") = mode;
    asm volatile("svc #0" : "+r"(x0) : "r"(x1),"r"(x2),"r"(x3),"r"(x8) : "memory");
    return x0;
}
static s64 sc_access(const char *path, s64 mode) {
    register s64 x8 asm("x8") = SYS_access;
    register s64 x0 asm("x0") = (s64)path;
    register s64 x1 asm("x1") = mode;
    asm volatile("svc #0" : "+r"(x0) : "r"(x1),"r"(x8) : "memory");
    return x0;
}
static s64 sc_ftruncate(s64 fd, s64 len) {
    register s64 x8 asm("x8") = SYS_ftruncate;
    register s64 x0 asm("x0") = fd;
    register s64 x1 asm("x1") = len;
    asm volatile("svc #0" : "+r"(x0) : "r"(x1),"r"(x8) : "memory");
    return x0;
}
static void *sc_mmap(void *addr, s64 len, s64 prot, s64 flags, s64 fd, s64 off) {
    register s64 x8 asm("x8") = SYS_mmap;
    register s64 x0 asm("x0") = (s64)addr;
    register s64 x1 asm("x1") = len;
    register s64 x2 asm("x2") = prot;
    register s64 x3 asm("x3") = flags;
    register s64 x4 asm("x4") = fd;
    register s64 x5 asm("x5") = off;
    asm volatile("svc #0" : "+r"(x0) : "r"(x1),"r"(x2),"r"(x3),"r"(x4),"r"(x5),"r"(x8) : "memory");
    return (void*)x0;
}
static s64 sc_munmap(void *addr, s64 len) {
    register s64 x8 asm("x8") = SYS_munmap;
    register s64 x0 asm("x0") = (s64)addr;
    register s64 x1 asm("x1") = len;
    asm volatile("svc #0" : "+r"(x0) : "r"(x1),"r"(x8) : "memory");
    return x0;
}
static s64 sc_mprotect(void *addr, s64 len, s64 prot) {
    register s64 x8 asm("x8") = SYS_mprotect;
    register s64 x0 asm("x0") = (s64)addr;
    register s64 x1 asm("x1") = len;
    register s64 x2 asm("x2") = prot;
    asm volatile("svc #0" : "+r"(x0) : "r"(x1),"r"(x2),"r"(x8) : "memory");
    return x0;
}
/* ===== Embedded tool data ===== */
extern const unsigned char _binary_pi_start[], _binary_pi_end[];
extern const unsigned char _binary_gdb_start[], _binary_gdb_end[];
extern const unsigned char _binary_gdbserver_start[], _binary_gdbserver_end[];
extern const unsigned char _binary_ncdu_start[], _binary_ncdu_end[];
extern const unsigned char _binary_tmux_start[], _binary_tmux_end[];
extern const unsigned char _binary_sqlite3_start[], _binary_sqlite3_end[];
extern const unsigned char _binary_rclone_start[], _binary_rclone_end[];
extern const unsigned char _binary_asr_start[], _binary_asr_end[];
extern const unsigned char _binary_ocr_start[], _binary_ocr_end[];
extern const unsigned char _binary_ai_start[], _binary_ai_end[];
extern const unsigned char _binary_adb_start[], _binary_adb_end[];
extern const unsigned char _binary_bat_start[], _binary_bat_end[];
extern const unsigned char _binary_cryptsetup_start[], _binary_cryptsetup_end[];
extern const unsigned char _binary_curl_start[], _binary_curl_end[];
extern const unsigned char _binary_duf_start[], _binary_duf_end[];
extern const unsigned char _binary_fastboot_start[], _binary_fastboot_end[];
extern const unsigned char _binary_fd_start[], _binary_fd_end[];
extern const unsigned char _binary_git_start[], _binary_git_end[];
extern const unsigned char _binary_ffmpeg_start[], _binary_ffmpeg_end[];
extern const unsigned char _binary_ffprobe_start[], _binary_ffprobe_end[];
extern const unsigned char _binary_imgbox_start[], _binary_imgbox_end[];
extern const unsigned char _binary_magick_start[], _binary_magick_end[];
extern const unsigned char _binary_nano_start[], _binary_nano_end[];
extern const unsigned char _binary_vips_start[], _binary_vips_end[];
extern const unsigned char _binary_scp_start[], _binary_scp_end[];
extern const unsigned char _binary_sftp_start[], _binary_sftp_end[];
extern const unsigned char _binary_file_start[], _binary_file_end[];
extern const unsigned char _binary_e2fsck_start[], _binary_e2fsck_end[];
extern const unsigned char _binary_fsck_fat_start[], _binary_fsck_fat_end[];
extern const unsigned char _binary_mkfs_fat_start[], _binary_mkfs_fat_end[];
extern const unsigned char _binary_resize2fs_start[], _binary_resize2fs_end[];
extern const unsigned char _binary_tune2fs_start[], _binary_tune2fs_end[];
extern const unsigned char _binary_fzf_start[], _binary_fzf_end[];
extern const unsigned char _binary_gdisk_start[], _binary_gdisk_end[];
extern const unsigned char _binary_iperf3_start[], _binary_iperf3_end[];
extern const unsigned char _binary_jq_start[], _binary_jq_end[];
extern const unsigned char _binary_ln_start[], _binary_ln_end[];
extern const unsigned char _binary_lsblk_start[], _binary_lsblk_end[];
extern const unsigned char _binary_lz4_start[], _binary_lz4_end[];
extern const unsigned char _binary_openssl_start[], _binary_openssl_end[];
extern const unsigned char _binary_pv_start[], _binary_pv_end[];
extern const unsigned char _binary_rg_start[], _binary_rg_end[];
extern const unsigned char _binary_setup_start[], _binary_setup_end[];
extern const unsigned char _binary_smartctl_start[], _binary_smartctl_end[];
extern const unsigned char _binary_snake_start[], _binary_snake_end[];
extern const unsigned char _binary_sox_start[], _binary_sox_end[];
extern const unsigned char _binary_soxi_start[], _binary_soxi_end[];
extern const unsigned char _binary_ssh_start[], _binary_ssh_end[];
extern const unsigned char _binary_strace_start[], _binary_strace_end[];
extern const unsigned char _binary_tcpdump_start[], _binary_tcpdump_end[];
extern const unsigned char _binary_tetris_start[], _binary_tetris_end[];
extern const unsigned char _binary_tree_start[], _binary_tree_end[];
extern const unsigned char _binary_uchardet_start[], _binary_uchardet_end[];
extern const unsigned char _binary_vim_start[], _binary_vim_end[];
extern const unsigned char _binary_yq_start[], _binary_yq_end[];
extern const unsigned char _binary_zstd_start[], _binary_zstd_end[];
extern const unsigned char _binary_upx_start[], _binary_upx_end[];
extern const unsigned char _binary_busybox_start[], _binary_busybox_end[];
extern const unsigned char _binary_toybox_start[], _binary_toybox_end[];
extern const unsigned char _binary_coreutils_start[], _binary_coreutils_end[];
extern const unsigned char _binary_w3m_start[], _binary_w3m_end[];
extern const unsigned char _binary_runit_start[], _binary_runit_end[];
extern const unsigned char _binary_runit_init_start[], _binary_runit_init_end[];
extern const unsigned char _binary_runsv_start[], _binary_runsv_end[];
extern const unsigned char _binary_runsvchdir_start[], _binary_runsvchdir_end[];
extern const unsigned char _binary_runsvdir_start[], _binary_runsvdir_end[];
extern const unsigned char _binary_sv_start[], _binary_sv_end[];
extern const unsigned char _binary_svlogd_start[], _binary_svlogd_end[];
extern const unsigned char _binary_chpst_start[], _binary_chpst_end[];
extern const unsigned char _binary_utmpset_start[], _binary_utmpset_end[];

extern const unsigned char _binary_show_start[], _binary_show_end[];

/* ===== Embedded help text ===== */
extern const unsigned char _binary_help_txt_start[], _binary_help_txt_end[];
extern const unsigned char _binary_list_txt_start[], _binary_list_txt_end[];

typedef struct {
    const char *name;
    const unsigned char *start;
    const unsigned char *end;
} tool_t;

/* tools[] — alphabetical order */
static const tool_t tools[] = {
    {"pi",      _binary_pi_start,      _binary_pi_end},
    {"gdb",      _binary_gdb_start,      _binary_gdb_end},
    {"gdbserver",   _binary_gdbserver_start,   _binary_gdbserver_end},
    {"ncdu",      _binary_ncdu_start,      _binary_ncdu_end},
    {"tmux",      _binary_tmux_start,      _binary_tmux_end},
    {"sqlite3",   _binary_sqlite3_start,   _binary_sqlite3_end},
    {"rclone",    _binary_rclone_start,    _binary_rclone_end},
    {"asr",       _binary_asr_start,       _binary_asr_end},
    {"ocr",       _binary_ocr_start,       _binary_ocr_end},
    {"adb",       _binary_adb_start,       _binary_adb_end},
    {"ai",        _binary_ai_start,        _binary_ai_end},
    {"bat",       _binary_bat_start,       _binary_bat_end},
    {"chpst",     _binary_chpst_start,     _binary_chpst_end},
    {"coreutils", _binary_coreutils_start, _binary_coreutils_end},
    {"cryptsetup",_binary_cryptsetup_start,_binary_cryptsetup_end},
    {"curl",      _binary_curl_start,      _binary_curl_end},
    {"duf",       _binary_duf_start,       _binary_duf_end},
    {"e2fsck",    _binary_e2fsck_start,    _binary_e2fsck_end},
    {"fastboot",  _binary_fastboot_start,  _binary_fastboot_end},
    {"fd",        _binary_fd_start,        _binary_fd_end},
    {"ffmpeg",    _binary_ffmpeg_start,    _binary_ffmpeg_end},
    {"ffprobe",   _binary_ffprobe_start,   _binary_ffprobe_end},
    {"file",      _binary_file_start,      _binary_file_end},
    {"fsck.fat",  _binary_fsck_fat_start,  _binary_fsck_fat_end},
    {"fzf",       _binary_fzf_start,       _binary_fzf_end},
    {"gdisk",     _binary_gdisk_start,     _binary_gdisk_end},
    {"git",       _binary_git_start,       _binary_git_end},
    {"imgbox",    _binary_imgbox_start,    _binary_imgbox_end},
    {"iperf3",    _binary_iperf3_start,    _binary_iperf3_end},
    {"jq",        _binary_jq_start,        _binary_jq_end},
    {"ln",        _binary_ln_start,        _binary_ln_end},
    {"lsblk",     _binary_lsblk_start,     _binary_lsblk_end},
    {"lz4",       _binary_lz4_start,       _binary_lz4_end},
    {"magick",    _binary_magick_start,    _binary_magick_end},
    {"mkfs.fat",  _binary_mkfs_fat_start,  _binary_mkfs_fat_end},
    {"nano",      _binary_nano_start,      _binary_nano_end},
    {"openssl",   _binary_openssl_start,   _binary_openssl_end},
    {"pv",        _binary_pv_start,        _binary_pv_end},
    {"resize2fs", _binary_resize2fs_start, _binary_resize2fs_end},
    {"rg",        _binary_rg_start,        _binary_rg_end},
    {"runit",     _binary_runit_start,     _binary_runit_end},
    {"runit-init",_binary_runit_init_start,_binary_runit_init_end},
    {"runsv",     _binary_runsv_start,     _binary_runsv_end},
    {"runsvchdir",_binary_runsvchdir_start,_binary_runsvchdir_end},
    {"runsvdir",  _binary_runsvdir_start,  _binary_runsvdir_end},
    {"scp",       _binary_scp_start,       _binary_scp_end},
    {"show",      _binary_show_start,      _binary_show_end},
    {"setup",     _binary_setup_start,     _binary_setup_end},
    {"sftp",      _binary_sftp_start,      _binary_sftp_end},
    {"smartctl",  _binary_smartctl_start,  _binary_smartctl_end},
    {"snake",     _binary_snake_start,     _binary_snake_end},
    {"sox",       _binary_sox_start,       _binary_sox_end},
    {"soxi",      _binary_soxi_start,      _binary_soxi_end},
    {"ssh",       _binary_ssh_start,       _binary_ssh_end},
    {"strace",    _binary_strace_start,    _binary_strace_end},
    {"sv",        _binary_sv_start,        _binary_sv_end},
    {"svlogd",    _binary_svlogd_start,    _binary_svlogd_end},
    {"tcpdump",   _binary_tcpdump_start,   _binary_tcpdump_end},
    {"tetris",    _binary_tetris_start,    _binary_tetris_end},
    {"tune2fs",   _binary_tune2fs_start,   _binary_tune2fs_end},
    {"tree",      _binary_tree_start,      _binary_tree_end},
    {"uchardet",  _binary_uchardet_start,  _binary_uchardet_end},
    {"upx",       _binary_upx_start,       _binary_upx_end},
    {"utmpset",   _binary_utmpset_start,   _binary_utmpset_end},
    {"vim",       _binary_vim_start,       _binary_vim_end},
    {"vips",      _binary_vips_start,      _binary_vips_end},
    {"w3m",       _binary_w3m_start,       _binary_w3m_end},
    {"yq",        _binary_yq_start,        _binary_yq_end},
    {"zstd",      _binary_zstd_start,      _binary_zstd_end},
    {"busybox",   _binary_busybox_start,   _binary_busybox_end},
    {"toybox",    _binary_toybox_start,    _binary_toybox_end},
};
#define TOOL_COUNT (sizeof(tools)/sizeof(tools[0]))

/* ===== String utils ===== */
static s64 slen(const char *s) { s64 n=0; while(s[n]) n++; return n; }
static int seq(const char *a, const char *b) {
    if (!a || !b) return -1;
    while (*a && *a == *b) { a++; b++; }
    return (unsigned char)*a - (unsigned char)*b;
}
static const char *bn(const char *p) {
    const char *last = p;
    while (*p) { if (*p == 47) last = p + 1; p++; }
    return last;
}
static s64 dirn(char *dst, const char *path) {
    s64 i = 0, last_slash = -1;
    const char *p = path;
    while (*p) { if (*p == 47) last_slash = i; p++; i++; }
    if (last_slash <= 0) { dst[0] = 47; dst[1] = 0; return 1; }
    s64 j;
    for (j = 0; j < last_slash; j++) dst[j] = path[j];
    dst[j] = 0;
    return j;
}
static const tool_t *find_t(const char *name) {
    for (s64 i = 0; i < (s64)TOOL_COUNT; i++)
        if (seq(tools[i].name, name) == 0) return &tools[i];
    return (const tool_t *)0;
}

/* ===== Direct syscalls ===== */
static s64 sc_write(s64 fd, const char *buf, s64 len) {
    register s64 x8 asm("x8") = SYS_write;
    register s64 x0 asm("x0") = fd;
    register s64 x1 asm("x1") = (s64)buf;
    register s64 x2 asm("x2") = len;
    asm volatile("svc #0" : "+r"(x0) : "r"(x1),"r"(x2),"r"(x8) : "memory");
    return x0;
}
static s64 sc_read(s64 fd, char *buf, s64 len) {
    register s64 x8 asm("x8") = SYS_read;
    register s64 x0 asm("x0") = fd;
    register s64 x1 asm("x1") = (s64)buf;
    register s64 x2 asm("x2") = len;
    asm volatile("svc #0" : "+r"(x0) : "r"(x1),"r"(x2),"r"(x8) : "memory");
    return x0;
}
static void wr(s64 fd, const char *s, s64 len) { sc_write(fd, s, len); }
static void wrs(s64 fd, const char *s) { s64 n=0; while(s[n]) n++; wr(fd, s, n); }

static void ex(s64 code) {
    register s64 x8 asm("x8") = SYS_exit;
    register s64 x0 asm("x0") = code;
    asm volatile("svc #0" : : "r"(x0),"r"(x8) : "memory");
}

static s64 sc_dup3(s64 oldfd, s64 newfd, s64 flags) {
    register s64 x8 asm("x8") = SYS_dup3;
    register s64 x0 asm("x0") = oldfd;
    register s64 x1 asm("x1") = newfd;
    register s64 x2 asm("x2") = flags;
    asm volatile("svc #0" : "+r"(x0) : "r"(x1),"r"(x2),"r"(x8) : "memory");
    return x0;
}

static s64 sc_fork(void) {
    register s64 x8 asm("x8") = SYS_fork;
    register s64 x0 asm("x0") = 0;
    asm volatile("svc #0" : "+r"(x0) : "r"(x8) : "memory");
    return x0;
}

static s64 sc_wait4(s64 pid, int *status, s64 options, void *rusage) {
    register s64 x8 asm("x8") = SYS_wait4;
    register s64 x0 asm("x0") = pid;
    register s64 x1 asm("x1") = (s64)status;
    register s64 x2 asm("x2") = options;
    register s64 x3 asm("x3") = (s64)rusage;
    asm volatile("svc #0" : "+r"(x0) : "r"(x1),"r"(x2),"r"(x3),"r"(x8) : "memory");
    return x0;
}

static s64 sc_pipe2(int *fds, s64 flags) {
    register s64 x8 asm("x8") = SYS_pipe2;
    register s64 x0 asm("x0") = (s64)fds;
    register s64 x1 asm("x1") = flags;
    asm volatile("svc #0" : "+r"(x0) : "r"(x1),"r"(x8) : "memory");
    return x0;
}

static s64 sc_memfd_create(void) {
    register s64 x8 asm("x8") = SYS_memfd_create;
    register s64 x0 asm("x0") = (s64)"mt";
    register s64 x1 asm("x1") = 0;
    asm volatile("svc #0" : "+r"(x0) : "r"(x1),"r"(x8) : "memory");
    return x0;
}

static s64 sc_execveat(s64 fd, const char *path, char **argv, char **envp, s64 flag) {
    register s64 x8 asm("x8") = SYS_execveat;
    register s64 x0 asm("x0") = fd;
    register s64 x1 asm("x1") = (s64)path;
    register s64 x2 asm("x2") = (s64)argv;
    register s64 x3 asm("x3") = (s64)envp;
    register s64 x4 asm("x4") = flag;
    asm volatile("svc #0" : "+r"(x0) : "r"(x1),"r"(x2),"r"(x3),"r"(x4),"r"(x8) : "memory");
    return x0;
}

static s64 sc_close(s64 fd) {
    register s64 x8 asm("x8") = SYS_close;
    register s64 x0 asm("x0") = fd;
    asm volatile("svc #0" : : "r"(x0),"r"(x8) : "memory");
    return x0;
}

static void write_all(int fd, const unsigned char *b, s64 len) {
    while (len > 0) {
        s64 n = sc_write(fd, (const char *)b, len);
        if (n <= 0) return;
        b += n; len -= n;
    }
}

static s64 execmem(const tool_t *t, s64 argc, char **argv, char **envp) {
    s64 size = (s64)(t->end - t->start);
    s64 fd;
    int use_android = 0;

    sc_mkdir(MT_DIR_LINUX, 0755);

    int has_android = 0, has_linux = 0;
    int fd_tmp = sc_openat(AT_FDCWD, MT_NOROOT_ANDROID, O_RDONLY, 0);
    if (fd_tmp >= 0) { sc_close(fd_tmp); has_android = 1; }
    fd_tmp = sc_openat(AT_FDCWD, MT_NOROOT_LINUX, O_RDONLY, 0);
    if (fd_tmp >= 0) { sc_close(fd_tmp); has_linux = 1; }

    if (has_android || has_linux) {
        use_android = has_android ? 1 : 0;
    } else {
        /* 路径一：无 .noroot → memfd_create */
        fd = sc_memfd_create();
        if (fd < 0) {
            wrs(2, "mt: memfd_create failed\n");
            wrs(2, "mt: try 'touch " MT_NOROOT_ANDROID "' (for Android) or 'mkdir -p " MT_DIR_LINUX " && touch " MT_NOROOT_LINUX "' (for Linux) to use fallback\n");
            return 1;
        }
        write_all((int)fd, t->start, size);
        argv[0] = (char *)t->name;
        s64 ret = sc_execveat((int)fd, "", argv, envp, AT_EMPTY_PATH);
        sc_close(fd);
        if (ret < 0) {
            wrs(2, "mt: memfd execveat failed\n");
            wrs(2, "mt: try 'touch " MT_NOROOT_ANDROID "' (for Android) or 'mkdir -p " MT_DIR_LINUX " && touch " MT_NOROOT_LINUX "' (for Linux) to use fallback\n");
            return 1;
        }
        return 0;
    }

    /* 路径二：有 .noroot → 先尝试 O_TMPFILE */
    const char *tmpdir = use_android ? MT_TMPDIR_ANDROID : MT_TMPDIR_LINUX;
    fd = sc_openat(AT_FDCWD, tmpdir, O_TMPFILE | O_RDWR | O_CLOEXEC, 0700);
    if (fd >= 0) {
        /* O_TMPFILE 成功 → 匿名执行 */
        if (sc_ftruncate(fd, size) < 0) {
            sc_close(fd);
            wrs(2, "mt: ftruncate failed\n");
            wrs(2, "mt: This toolbox engine cannot work. Please download standalone static binaries from https://github.com/Chen9183/android-static-bin/releases (or other trusted sources) instead of using this toolbox.\n");
            return 1;
        }
        void *addr = sc_mmap(0, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
        if (addr == MAP_FAILED) {
            sc_close(fd);
            wrs(2, "mt: mmap RW failed\n");
            wrs(2, "mt: This toolbox engine cannot work. Please download standalone static binaries from https://github.com/Chen9183/android-static-bin/releases (or other trusted sources) instead of using this toolbox.\n");
            return 1;
        }
        unsigned char *dst = (unsigned char *)addr;
        const unsigned char *src = t->start;
        for (s64 i = 0; i < size; i++) dst[i] = src[i];

        if (sc_mprotect(addr, (size + 4095) & ~4095, PROT_READ | PROT_EXEC) < 0) {
            sc_munmap(addr, size);
            sc_close(fd);
            wrs(2, "mt: mprotect RX failed\n");
            wrs(2, "mt: This toolbox engine cannot work. Please download standalone static binaries from https://github.com/Chen9183/android-static-bin/releases (or other trusted sources) instead of using this toolbox.\n");
            return 1;
        }
        argv[0] = (char *)t->name;
        s64 ret = sc_execveat(fd, "", argv, envp, AT_EMPTY_PATH);
        sc_close(fd);
        if (ret < 0) {
            sc_munmap(addr, size);
            wrs(2, "mt: execveat on O_TMPFILE fd failed\n");
            wrs(2, "mt: This toolbox engine cannot work. Please download standalone static binaries from https://github.com/Chen9183/android-static-bin/releases (or other trusted sources) instead of using this toolbox.\n");
            return 1;
        }
        return 0;
    }

    /* 路径三：O_TMPFILE 失败 → 普通文件路径执行（保留文件，下次启动清理） */
    static const char *tmpfile = "/data/local/tmp/mt_exec";
    int tmp_fd = sc_openat(AT_FDCWD, tmpfile, O_RDWR | O_CREAT | O_TRUNC | O_CLOEXEC, 0700);
    if (tmp_fd < 0) {
        wrs(2, "mt: O_TMPFILE and fallback open both failed on "); wrs(2, tmpdir); wrs(2, "\n");
        wrs(2, "mt: This toolbox engine cannot work. Please download standalone static binaries from https://github.com/Chen9183/android-static-bin/releases (or other trusted sources) instead of using this toolbox.\n");
        return 1;
    }
    write_all(tmp_fd, t->start, size);
    sc_close(tmp_fd);
    argv[0] = (char *)t->name;
    s64 ret = sc_execveat(AT_FDCWD, tmpfile, argv, envp, 0);
    /* 如果路径执行也失败，删除临时文件并报错 */
    sc_unlinkat(AT_FDCWD, tmpfile, 0);
    wrs(2, "mt: execveat on path failed\n");
    wrs(2, "mt: This toolbox engine cannot work. Please download standalone static binaries from https://github.com/Chen9183/android-static-bin/releases (or other trusted sources) instead of using this toolbox.\n");
    return 1;
}

static const char *inames[] = {
    "sqlite3","rclone","asr","ocr","ai","adb","bat","chpst","coreutils","cryptsetup","curl","duf","e2fsck","fastboot","fd",
    "ffmpeg","ffprobe","file","fsck.fat","fzf","gdisk","git","imgbox","iperf3","jq","ln","mkfs.fat",
    "lsblk","lz4","magick","nano","openssl","pv","resize2fs","rg","runit","runit-init",
    "runsv","runsvchdir","runsvdir","scp","setup","sftp","show","smartctl","snake","sox",
    "soxi","ssh","strace","sv","svlogd","tcpdump","ncdu", "tmux","tetris","tune2fs","tree","uchardet","upx",
    "utmpset","vim","vips","w3m","yq","zstd","busybox","toybox","gdb","gdbserver",0};

static void do_install(const char *our_exe) {
    char target_dir[256];
    s64 nd = dirn(target_dir, our_exe);
    if (nd <= 0) { wrs(2, "mt: bad exe path\n"); return; }
    for (s64 i = 0; inames[i]; i++) {
        char ln[256]; s64 j = 0;
        for (s64 k = 0; k < nd; k++) ln[j++] = target_dir[k];
        ln[j++] = 47;
        const char *p = inames[i];
        while (*p) ln[j++] = *p++;
        ln[j] = 0;
        {
            register s64 x8 asm("x8") = SYS_unlinkat;
            register s64 x0 asm("x0") = AT_FDCWD;
            register s64 x1 asm("x1") = (s64)ln;
            register s64 x2 asm("x2") = 0;
            asm volatile("svc #0" : : "r"(x0),"r"(x1),"r"(x2),"r"(x8) : "memory");
        }
        {
            register s64 x8 asm("x8") = SYS_symlinkat;
            register s64 x0 asm("x0") = (s64)our_exe;
            register s64 x1 asm("x1") = AT_FDCWD;
            register s64 x2 asm("x2") = (s64)ln;
            asm volatile("svc #0" : : "r"(x0),"r"(x1),"r"(x2),"r"(x8) : "memory");
        }
        wrs(1, "  + "); wrs(1, ln + nd + 1); wrs(1, "\n");
    }
}
/* ===== Base64 decode (robust) ===== */
static s64 b64_decode(const char *in, unsigned char *out, s64 out_size) {
    static const char b64[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    static int idx[256];
    static int idx_init = 0;
    if (!idx_init) {
        idx_init = 1;
        for (int i = 0; i < 256; i++) idx[i] = -1;
        for (int i = 0; i < 64; i++) idx[(unsigned char)b64[i]] = i;
    }

    s64 in_len = 0;
    while (in[in_len]) in_len++;
    if (in_len % 4 != 0) return -1;

    s64 out_pos = 0;
    for (s64 i = 0; i < in_len; i += 4) {
        int v[4];
        int pad = 0;
        for (int j = 0; j < 4; j++) {
            unsigned char c = (unsigned char)in[i+j];
            if (c == '=') {
                v[j] = 0;
                pad++;
                if (j < 2) return -1;
            } else {
                int val = idx[c];
                if (val < 0) return -1;
                v[j] = val;
            }
        }
        if (pad > 2) return -1;

        if (out_pos < out_size) out[out_pos++] = (v[0] << 2) | (v[1] >> 4);
        if (pad < 2 && out_pos < out_size) out[out_pos++] = ((v[1] & 0x0F) << 4) | (v[2] >> 2);
        if (pad < 1 && out_pos < out_size) out[out_pos++] = ((v[2] & 0x03) << 6) | v[3];
    }
    return out_pos;
}
/* show_help: dump embedded help.txt, replacing placeholder with decoded author.
 * If placeholder not found → tampered, show warning. */
static int memeq(const unsigned char *a, const char *b, s64 n) {
    for (s64 i = 0; i < n; i++) if (a[i] != (unsigned char)b[i]) return 0;
    return 1;
}
static void show_help(void) {
    static const char *auth_b64 = "ZGVlcHNlZWsgdjQgZmxhc2ggJiBAQ2hlbjkxODMgKGdpdGh1Yik=";
    static const char *placeholder_b64 = "PT09PUFVVEhPUj09UExBQ0VIT0xERVI9PTM4PT1CWVRFUz09PT0=";
    static const char *warning_b64 = "4pqgIOatpOaWh+S7tuW3suiiq+evoeaUue+8geWPr+iDveWMheWQq+mjjumZqe+8jOivt+iBlOezu+WOn+S9nOiAheOAgihAQ2hlbjkxODMpKGdpdGh1Yik=";

    static char author[64];
    static char placeholder[64];
    static char warning[256];
    static int decoded = 0;
    static s64 author_len = 0, plen = 0, warn_len = 0;

    if (!decoded) {
        decoded = 1;
        s64 len;

        len = b64_decode(auth_b64, (unsigned char*)author, sizeof(author)-1);
        if (len < 0) {
            const char *fb = "@​Ch​en​91​83";
            while (*fb) author[author_len++] = *fb++;
        } else {
            author_len = len;
        }
        author[author_len] = 0;

        len = b64_decode(placeholder_b64, (unsigned char*)placeholder, sizeof(placeholder)-1);
        if (len < 0) {
            const char *fb = "====AUTHOR==PLACEHOLDER==38==BYTES====";
            while (*fb) placeholder[plen++] = *fb++;
        } else {
            plen = len;
        }
        placeholder[plen] = 0;

        len = b64_decode(warning_b64, (unsigned char*)warning, sizeof(warning)-1);
        if (len < 0) {
            const char *fb = "⚠ 此文件已被篡改！可能包含风险，请联系原作者。(@Ch​en​91​83)(github)";
            while (*fb) warning[warn_len++] = *fb++;
        } else {
            warn_len = len;
        }
        warning[warn_len] = 0;
    }

    const unsigned char *data = _binary_help_txt_start;
    s64 size = (s64)(_binary_help_txt_end - _binary_help_txt_start);
    s64 i = 0;
    s64 found = 0;

    while (i + plen <= size) {
        if (memeq(data + i, placeholder, plen)) {
            found++;
            if (i > 0) write_all(1, data, i);
            write_all(1, (const unsigned char *)author, author_len);
            data += i + plen;
            size -= i + plen;
            i = 0;
        } else {
            i++;
        }
    }

    if (found == 0) {
        write_all(1, (const unsigned char *)warning, warn_len);
    } else if (size > 0) {
        write_all(1, data, size);
    }
}
/* show_list: directly dump embedded list.txt to stdout */
static void show_list(void) {
    s64 size = (s64)(_binary_list_txt_end - _binary_list_txt_start);
    write_all(1, _binary_list_txt_start, size);
}

void main_entry(s64 argc, char **argv, char **envp) {
/* 清理上一次留下的临时文件（忽略错误） */
sc_unlinkat(AT_FDCWD, "/data/local/tmp/mt_exec", 0);
    const char *toolname = bn(argv[0]);

    if (seq(toolname, "mytools") == 0 || seq(toolname, "mt") == 0) {
        if (argc < 2) { show_help(); ex(0); }
        if (seq(argv[1], "install") == 0) { do_install(argv[0]); ex(0); }
        if (seq(argv[1], "help") == 0 || seq(argv[1], "-h") == 0 || seq(argv[1], "--help") == 0) { show_help(); ex(0); }
        if (seq(argv[1], "list") == 0 || seq(argv[1], "ls") == 0) { show_list(); ex(0); }
        argv++; argc--;
        toolname = bn(argv[0]);
    }

    /* Direct symlink execution */
    const tool_t *t = find_t(toolname);
    if (!t) {
        wrs(2, "mt: unknown tool '"); wrs(2, toolname); wrs(2, "'\n");
        wrs(2, "Run 'mytools help' or 'mytools list'\n");
        ex(1);
    }
    ex((int)execmem(t, argc, argv, envp));
}
