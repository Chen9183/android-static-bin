/* 
 * ln.c - minimal ln for mytools embedded tool
 * aarch64 pure syscall, glibc static, no dependencies
 */

typedef long s64;
#define SYS_write 64
#define SYS_exit 93
#define SYS_linkat 37
#define SYS_symlinkat 36
#define SYS_unlinkat 35
#define SYS_faccessat 48
#define SYS_fstatat 79
#define AT_FDCWD (-100)

static s64 sc_write(s64 fd, const char *buf, s64 len) {
    register s64 x8 asm("x8") = SYS_write;
    register s64 x0 asm("x0") = fd; 
    register s64 x1 asm("x1") = (s64)buf;
    register s64 x2 asm("x2") = len;
    asm volatile("svc #0" : "+r"(x0) : "r"(x1),"r"(x2),"r"(x8) : "memory");
    return x0;
}
static void wr(s64 fd, const char *s, s64 len) { sc_write(fd, s, len); }
static void wrstr(s64 fd, const char *s) { s64 n=0; while(s[n]) n++; wr(fd, s, n); }
static void ex(s64 code) {
    register s64 x8 asm("x8") = SYS_exit;
    register s64 x0 asm("x0") = code;
    asm volatile("svc #0" : : "r"(x0),"r"(x8) : "memory");
}
static void die(const char *msg) { wrstr(2, msg); wr(2, "\n", 1); ex(1); }

static s64 sc_symlinkat(const char *target, const char *linkpath) {
    register s64 x8 asm("x8") = SYS_symlinkat;
    register s64 x0 asm("x0") = (s64)target;
    register s64 x1 asm("x1") = AT_FDCWD;
    register s64 x2 asm("x2") = (s64)linkpath;
    asm volatile("svc #0" : "+r"(x0) : "r"(x1),"r"(x2),"r"(x8) : "memory");
    return x0;
}
static s64 sc_linkat(const char *oldpath, const char *newpath) {
    register s64 x8 asm("x8") = SYS_linkat;
    register s64 x0 asm("x0") = AT_FDCWD;
    register s64 x1 asm("x1") = (s64)oldpath;
    register s64 x2 asm("x2") = AT_FDCWD;
    register s64 x3 asm("x3") = (s64)newpath;
    register s64 x4 asm("x4") = 0;
    asm volatile("svc #0" : "+r"(x0) : "r"(x1),"r"(x2),"r"(x3),"r"(x4),"r"(x8) : "memory");
    return x0;
}
static s64 sc_unlinkat(const char *path) {
    register s64 x8 asm("x8") = SYS_unlinkat;
    register s64 x0 asm("x0") = AT_FDCWD;
    register s64 x1 asm("x1") = (s64)path;
    register s64 x2 asm("x2") = 0;
    asm volatile("svc #0" : : "r"(x0),"r"(x1),"r"(x2),"r"(x8) : "memory");
    return x0;
}
static s64 sc_faccessat(const char *path) {
    register s64 x8 asm("x8") = SYS_faccessat;
    register s64 x0 asm("x0") = AT_FDCWD;
    register s64 x1 asm("x1") = (s64)path;
    register s64 x2 asm("x2") = 0;
    register s64 x3 asm("x3") = 0;
    asm volatile("svc #0" : "+r"(x0) : "r"(x1),"r"(x2),"r"(x3),"r"(x8) : "memory");
    return x0;
}
static s64 sc_fstatat(const char *path, void *buf) {
    register s64 x8 asm("x8") = SYS_fstatat;
    register s64 x0 asm("x0") = AT_FDCWD;
    register s64 x1 asm("x1") = (s64)path;
    register s64 x2 asm("x2") = (s64)buf;
    register s64 x3 asm("x3") = 0;
    asm volatile("svc #0" : "+r"(x0) : "r"(x1),"r"(x2),"r"(x3),"r"(x8) : "memory");
    return x0;
}

struct stat_s { s64 st_dev; s64 st_ino; unsigned st_mode; 
    unsigned st_nlink; unsigned st_uid; unsigned st_gid;
    s64 st_rdev; s64 st_size; s64 st_blksize; s64 st_blocks;
    s64 st_atim_sec; s64 st_atim_nsec;
    s64 st_mtim_sec; s64 st_mtim_nsec;
    s64 st_ctim_sec; s64 st_ctim_nsec;
};
#define S_ISDIR(m) (((m) & 0170000) == 0040000)

static s64 slen(const char *s) { s64 n=0; while(s[n]) n++; return n; }
static int seq(const char *a, const char *b) {
    while (*a && *a == *b) { a++; b++; }
    return (unsigned char)*a - (unsigned char)*b;
}
static s64 concat(char *dst, s64 dsz, const char *dir, const char *name) {
    s64 i = 0;
    while (*dir && i < dsz-1) dst[i++] = *dir++;
    if (i > 0 && dst[i-1] != 47) dst[i++] = 47;
    while (*name && i < dsz-1) dst[i++] = *name++;
    dst[i] = 0;
    return i;
}
static const char *bn(const char *p) {
    const char *last = p;
    while (*p) { if (*p == 47) last = p + 1; p++; }
    return last;
}

void ln_main(s64 argc, char **argv) {
    int symbolic = 0;
    int force = 0;
    int verbose = 0;
    
    int i = 1;
    while (i < argc && argv[i][0] == '-') {
        const char *p = argv[i] + 1;
        while (*p) {
            if (*p == 's') symbolic = 1;
            else if (*p == 'f') force = 1;
            else if (*p == 'v') verbose = 1;
            else { wrstr(2, "ln: unknown option -"); wr(2, p, 1); wrstr(2, "\n"); ex(1); }
            p++;
        }
        i++;
    }
    
    int remaining = argc - i;
    if (remaining < 2) die("ln: missing operand");
    
    char **files = argv + i;
    int nfiles = remaining;
    const char *last = files[nfiles - 1];
    
    struct stat_s st;
    int is_dir = 0;
    if (nfiles > 2) {
        is_dir = 1;
    } else if (nfiles == 2) {
        if (sc_fstatat(last, &st) == 0 && S_ISDIR(st.st_mode))
            is_dir = 1;
    }
    
    int nsrc = is_dir ? nfiles - 1 : 1;
    
    for (int si = 0; si < nsrc; si++) {
        const char *src = files[si];
        char linkname[512];
        const char *link = 0;
        
        if (is_dir) {
            concat(linkname, 510, last, bn(src));
            link = linkname;
        } else if (nfiles == 2) {
            link = files[1];
        }
        
        if (force && sc_faccessat(link) == 0) {
            sc_unlinkat(link);
        }
        
        s64 ret;
        if (symbolic) {
            ret = sc_symlinkat(src, link);
        } else {
            ret = sc_linkat(src, link);
        }
        
        if (ret != 0) {
            if (symbolic) wrstr(2, "ln: failed to create symlink '");
            else wrstr(2, "ln: failed to create hardlink '");
            wrstr(2, link); wrstr(2, "'\n");
            ex(1);
        }
        
        if (verbose && symbolic) {
            wrstr(1, "  + "); wrstr(1, link); wrstr(1, " -> "); wrstr(1, src); wr(1, "\n", 1);
        }
    }
}
