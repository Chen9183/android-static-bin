#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <grp.h>
#include <fcntl.h>
#include <limits.h>

#define TARGET_UID 2000
#define TARGET_GID 2000
#define TARGET_CONTEXT "u:r:shell:s0"

static void set_identity(void) {
    if (setgroups(0, NULL) != 0) {
        perror("setgroups");
    }
    if (setresgid(TARGET_GID, TARGET_GID, TARGET_GID) != 0) {
        perror("setresgid");
        exit(1);
    }
    if (setresuid(TARGET_UID, TARGET_UID, TARGET_UID) != 0) {
        perror("setresuid");
        exit(1);
    }
}

static int set_exec_selinux_context(const char *context) {
    int fd = open("/proc/self/attr/exec", O_WRONLY);
    if (fd < 0) {
        perror("open /proc/self/attr/exec");
        return -1;
    }
    size_t len = strlen(context);
    if (write(fd, context, len) != (ssize_t)len) {
        perror("write /proc/self/attr/exec");
        close(fd);
        return -1;
    }
    close(fd);
    return 0;
}

static const char *find_shell(void) {
    const char *env_shell = getenv("SHELL");
    if (env_shell && env_shell[0] == '/' && access(env_shell, X_OK) == 0) {
        return env_shell;
    }
    static const char *candidates[] = {
        "/system/bin/sh",
        "/bin/sh",
        "/usr/bin/sh",
        "/data/data/com.termux/files/usr/bin/sh",
        "/vendor/bin/sh",
        NULL
    };
    for (int i = 0; candidates[i]; i++) {
        if (access(candidates[i], X_OK) == 0) {
            return candidates[i];
        }
    }
    return NULL;
}

static char *shell_quote(const char *s) {
    size_t len = strlen(s);
    size_t cap = len + 2 + 1;
    for (size_t i = 0; i < len; i++) {
        if (s[i] == '\'') cap += 4;
    }
    char *out = malloc(cap);
    if (!out) return NULL;

    char *p = out;
    *p++ = '\'';
    for (size_t i = 0; i < len; i++) {
        if (s[i] == '\'') {
            memcpy(p, "'\\''", 4);
            p += 4;
        } else {
            *p++ = s[i];
        }
    }
    *p++ = '\'';
    *p = '\0';
    return out;
}

int main(int argc, char **argv) {
    set_identity();

    // 设置 exec 上下文
    if (set_exec_selinux_context(TARGET_CONTEXT) != 0) {
        fprintf(stderr, "警告：无法设置 exec SELinux 上下文到 %s，继承当前上下文\n", TARGET_CONTEXT);
    }

    const char *shell = find_shell();
    if (!shell) {
        fprintf(stderr, "错误：未找到可用的 sh\n");
        return 1;
    }

    if (argc == 1) {
        execl(shell, "sh", (char *)NULL);
        perror("execl sh");
        return 1;
    }

    // 构造命令字符串
    char *command = NULL;
    if (argc == 2) {
        command = strdup(argv[1]);
    } else {
        size_t cap = 1024;
        command = malloc(cap);
        if (!command) return 1;
        command[0] = '\0';
        size_t cmd_len = 0;

        for (int i = 1; i < argc; i++) {
            char *q = shell_quote(argv[i]);
            if (!q) {
                free(command);
                return 1;
            }
            size_t qlen = strlen(q);
            if (cmd_len + qlen + 2 > cap) {
                cap = (cmd_len + qlen + 2) * 2;
                char *new_cmd = realloc(command, cap);
                if (!new_cmd) {
                    free(q);
                    free(command);
                    return 1;
                }
                command = new_cmd;
            }
            if (i > 1) {
                strcat(command, " ");
                cmd_len++;
            }
            strcat(command, q);
            cmd_len += qlen;
            free(q);
        }
    }

    if (!command) return 1;

    char *shell_argv[] = { (char *)shell, "-c", command, NULL };
    execv(shell, shell_argv);
    perror("execv sh");
    free(command);
    return 1;
}