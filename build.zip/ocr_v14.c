// ocr — zero-dependency single-file OCR (修正版)
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <stdint.h>
#include <errno.h>

extern const unsigned char _binary_emb_toybox_start[], _binary_emb_toybox_end[];
extern const unsigned char _binary_ocr_payload_tar_start[], _binary_ocr_payload_tar_end[];

static const char *auth_b64 = "ZGVlcHNlZWsgdjQgZmxhc2ggJiBAQ2hlbjkxODMgKGdpdGh1Yik=";

static void b64_decode(char *out, size_t *out_len, const char *in) {
    static int T[256];
    static int init_done = 0;
    if (!init_done) {
        init_done = 1;
        T['A']=0;T['B']=1;T['C']=2;T['D']=3;T['E']=4;T['F']=5;T['G']=6;T['H']=7;T['I']=8;T['J']=9;
        T['K']=10;T['L']=11;T['M']=12;T['N']=13;T['O']=14;T['P']=15;T['Q']=16;T['R']=17;T['S']=18;T['T']=19;
        T['U']=20;T['V']=21;T['W']=22;T['X']=23;T['Y']=24;T['Z']=25;
        T['a']=26;T['b']=27;T['c']=28;T['d']=29;T['e']=30;T['f']=31;T['g']=32;T['h']=33;T['i']=34;T['j']=35;
        T['k']=36;T['l']=37;T['m']=38;T['n']=39;T['o']=40;T['p']=41;T['q']=42;T['r']=43;T['s']=44;T['t']=45;
        T['u']=46;T['v']=47;T['w']=48;T['x']=49;T['y']=50;T['z']=51;
        T['0']=52;T['1']=53;T['2']=54;T['3']=55;T['4']=56;T['5']=57;T['6']=58;T['7']=59;T['8']=60;T['9']=61;
        T['+']=62;T['/']=63;
    }
    size_t len = 0;
    for (size_t i = 0; in[i] && in[i] != '='; i += 4) {
        uint32_t v = (T[(unsigned char)in[i]] << 18) | (T[(unsigned char)in[i+1]] << 12);
        if (in[i+2] != '=') v |= (T[(unsigned char)in[i+2]] << 6);
        if (in[i+3] != '=') v |= T[(unsigned char)in[i+3]];
        out[len++] = (v >> 16) & 0xFF;
        if (len < *out_len && in[i+2] != '=') out[len++] = (v >> 8) & 0xFF;
        if (len < *out_len && in[i+3] != '=') out[len++] = v & 0xFF;
    }
    *out_len = len;
}

static int w_all(int fd, const void *b, size_t n) {
    const char *p = b;
    size_t total = 0;
    while (total < n) {
        ssize_t w = write(fd, p + total, n - total);
        if (w <= 0) return -1;
        total += w;
    }
    return 0;
}

static int f_write(const char *path, const void *d, size_t n, int mode) {
    int fd = open(path, O_WRONLY|O_CREAT|O_TRUNC, mode);
    if (fd < 0) return -1;
    int r = w_all(fd, d, n);
    close(fd);
    return r;
}

// 删除目录（调用 toybox，如果不可用则 fallback 到系统 rm）
static void rm_rf_toybox(const char *toybox, const char *path) {
    if (!toybox || !path) return;
    pid_t p = fork();
    if (p == 0) {
        execl(toybox, "toybox", "rm", "-rf", path, NULL);
        _exit(1);
    }
    if (p > 0) {
        int st;
        while (waitpid(p, &st, 0) == -1 && errno == EINTR);
    }
}

static int run_cmd(char *av[], char *ep[]) {
    pid_t p = fork();
    if (p == 0) { execve(av[0], av, ep); _exit(127); }
    if (p < 0) return -1;
    int s;
    while (waitpid(p, &s, 0) == -1 && errno == EINTR);
    return WIFEXITED(s) ? WEXITSTATUS(s) : -1;
}

static void show_help(const char *prog) {
    char author[128]; size_t al = sizeof(author);
    b64_decode(author, &al, auth_b64);
    author[al] = '\0';
    fprintf(stderr,
        "ocr - optical character recognition (Tesseract 5.3.0, self-contained)\n"
        "Author: %s\n"
        "\n"
        "Usage: %s <image> [output.txt]\n"
        "\n"
        "  %s --help  or  %s -h    show this help\n"
        "\n"
        "Arguments:\n"
        "  <image>       input image file (PNG, JPEG, TIFF, BMP, WebP, GIF)\n"
        "  [output.txt]  optional output text file (default: stdout)\n"
        "\n"
        "Supported languages: eng + chi_sim (English + Simplified Chinese)\n"
        "Engine: Tesseract OCR 5.3.0 LSTM (embedded)\n"
        "Total binary size: ~85 MB (payload: tessdata + libs + ld-linux)\n"
        "\n"
        "Examples:\n"
        "  %s screenshot.png\n"
        "  %s photo.jpg text.txt\n",
        author, prog, prog, prog, prog, prog);
}

// 全局变量用于 atexit 清理
static char g_tmp_dir[320] = {0};
static char g_toybox_path[320] = {0};

static void cleanup(void) {
    if (g_tmp_dir[0] != '\0' && g_toybox_path[0] != '\0') {
        rm_rf_toybox(g_toybox_path, g_tmp_dir);
    } else if (g_tmp_dir[0] != '\0') {
        // 降级使用系统 rm
        char cmd[512];
        snprintf(cmd, sizeof(cmd), "rm -rf %s", g_tmp_dir);
        system(cmd);
    }
}

int main(int argc, char **argv) {
    if (argc < 2 || !strcmp(argv[1], "--help") || !strcmp(argv[1], "-h")) {
        show_help(argv[0]);
        return (argc < 2) ? 1 : 0;
    }

    // 检查 /tmp 可用性
    if (access("/tmp", W_OK | X_OK) != 0) {
        fprintf(stderr, "Fatal: /tmp is not writable or executable.\n");
        return 1;
    }

    // 创建安全临时目录
    char tmp_template[] = "/tmp/ocr_XXXXXX";
    char *tmp_dir = mkdtemp(tmp_template);
    if (!tmp_dir) {
        perror("mkdtemp");
        return 2;
    }
    strncpy(g_tmp_dir, tmp_dir, sizeof(g_tmp_dir) - 1);
    g_tmp_dir[sizeof(g_tmp_dir) - 1] = '\0';

    // 生成路径
    char toybox_path[320], payload_path[320], tesseract_path[384];
    char lib_dir[320], tessdata_prefix[384];
    char output_dir[320], output_file[384];
    snprintf(toybox_path, sizeof(toybox_path), "%s/toybox", g_tmp_dir);
    snprintf(payload_path, sizeof(payload_path), "%s/payload.tar", g_tmp_dir);
    snprintf(tesseract_path, sizeof(tesseract_path), "%s/bin/tesseract", g_tmp_dir);
    snprintf(lib_dir, sizeof(lib_dir), "%s/lib", g_tmp_dir);
    snprintf(tessdata_prefix, sizeof(tessdata_prefix), "TESSDATA_PREFIX=%s/tessdata", g_tmp_dir);
    snprintf(output_dir, sizeof(output_dir), "%s/output", g_tmp_dir);
    snprintf(output_file, sizeof(output_file), "%s/out.txt", output_dir);  // 统一临时输出

    // 保存 toybox 路径用于清理
    strncpy(g_toybox_path, toybox_path, sizeof(g_toybox_path) - 1);
    g_toybox_path[sizeof(g_toybox_path) - 1] = '\0';
    atexit(cleanup);

    // 创建必要目录
    mkdir(g_tmp_dir, 0700);
    char bin_dir[320]; snprintf(bin_dir, sizeof(bin_dir), "%s/bin", g_tmp_dir);
    mkdir(bin_dir, 0700);
    mkdir(output_dir, 0700);   // 确保输出目录存在

    // 写入 toybox
    size_t tbsz = _binary_emb_toybox_end - _binary_emb_toybox_start;
    if (f_write(toybox_path, _binary_emb_toybox_start, tbsz, 0755) != 0) {
        fprintf(stderr, "Failed to write toybox\n");
        return 3;
    }

    // 写入 payload.tar
    size_t tsz = _binary_ocr_payload_tar_end - _binary_ocr_payload_tar_start;
    fprintf(stderr, "Extracting (%zu MB)...\n", tsz / (1024*1024));
    if (f_write(payload_path, _binary_ocr_payload_tar_start, tsz, 0600) != 0) {
        fprintf(stderr, "Failed to write payload\n");
        return 4;
    }

    // 解压 tar
    {
        char *av[] = {toybox_path, (char*)"tar", (char*)"xf", payload_path, (char*)"-C", g_tmp_dir, NULL};
        int r = run_cmd(av, NULL);
        unlink(payload_path);
        if (r != 0) {
            fprintf(stderr, "Tar extraction failed (code %d)\n", r);
            return 5;
        }
    }

    // 准备运行 tesseract
    // 确定输出文件名：tesseract 会自动添加 .txt，所以我们传不带 .txt 的基底
    char output_base[320];
    snprintf(output_base, sizeof(output_base), "%s/out", output_dir);  // 不带 .txt

    // 参数：ld-linux --library-path lib_dir tesseract 输入 输出 -l eng+chi_sim
    char *av[] = {
        (char*)"/tmp/ocr_XXXXXX/lib/ld-linux-aarch64.so.1", // 实际路径会被替换
        (char*)"--library-path", lib_dir,
        tesseract_path,
        argv[1],
        output_base,
        (char*)"-l", (char*)"eng+chi_sim",
        NULL
    };
    // 修正 ld-linux 路径为实际路径（因为上面模板未展开）
    // 我们已经在代码中生成 ld_path，但 av[0] 是临时写死的，需要替换
    // 所以我们重新构造 av，使用实际的 ld 路径
    char ld_path[384];
    snprintf(ld_path, sizeof(ld_path), "%s/lib/ld-linux-aarch64.so.1", g_tmp_dir);
    char *av2[] = {
        ld_path,
        (char*)"--library-path", lib_dir,
        tesseract_path,
        argv[1],
        output_base,
        (char*)"-l", (char*)"eng+chi_sim",
        NULL
    };
    char *ep[] = {tessdata_prefix, NULL};

    fprintf(stderr, "Running OCR...\n");
    int rc = run_cmd(av2, ep);

    // 输出结果
    char result_file[384];
    snprintf(result_file, sizeof(result_file), "%s.txt", output_base); // out.txt
    if (rc == 0) {
        if (argc >= 3) {
            // 复制到用户指定文件
            int sfd = open(result_file, O_RDONLY);
            if (sfd >= 0) {
                int dfd = open(argv[2], O_WRONLY|O_CREAT|O_TRUNC, 0644);
                if (dfd >= 0) {
                    char buf[65536];
                    ssize_t n;
                    while ((n = read(sfd, buf, sizeof(buf))) > 0)
                        w_all(dfd, buf, n);
                    close(dfd);
                    fprintf(stderr, "Done -> %s\n", argv[2]);
                } else {
                    perror("open output file");
                    rc = 6;
                }
                close(sfd);
            } else {
                fprintf(stderr, "ERROR: OCR output missing\n");
                rc = 7;
            }
        } else {
            // 输出到 stdout
            int sfd = open(result_file, O_RDONLY);
            if (sfd >= 0) {
                char buf[65536];
                ssize_t n;
                while ((n = read(sfd, buf, sizeof(buf))) > 0)
                    fwrite(buf, 1, n, stdout);
                close(sfd);
                fprintf(stderr, "\nDone (stdout)\n");
            } else {
                fprintf(stderr, "ERROR: OCR output missing\n");
                rc = 7;
            }
        }
    } else {
        fprintf(stderr, "Tesseract failed (code %d)\n", rc);
    }

    // atexit 会自动清理临时目录，不需要手动调用 rm_rf
    return rc;
}